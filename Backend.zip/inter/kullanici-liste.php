<?php include('header.php');
$durum =  $ayarSorgu[1];?>

<div class="content-wrapper">

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/datatables-buttons/buttons.flash.min.js"></script>
<script>
$(function () {
$("#example1").DataTable({
"responsive": true, "lengthChange": true, "autoWidth": true,
"buttons": ["copy", "csv", "excel", "pdf", "print"]
}).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
});
</script>



<section class="content"><div class="row"><div class="col-md-12"><div class="card card-primary card-outline">



<?php if($_GET["i"]=="TRkullanici"){ ;?>

<div class="content-header"><div class="container-fluid"><div class="row mb-2">
<div class="col-sm-6"><h1 class="m-0">Kayıtlı Kullanıcı Listesi</h1></div>
<div class="col-sm-6"><a href="kullanici-liste.php?i=TRkullaniciekle" class="btn btn-success" style="background-color:green">Kullanıcı Ekle +</a></div></div></div></div>

<div class="row" style="margin-top:-50px"><div class="col-sm-12"><section class="panel">
<table id="example1" class="table table-bordered table-striped">
<thead class="thead-dark"><tr><th style="width:1%">#</th><th>Şehir</th><th>İlçe</th><th>Kullanıcı</th><th>Email</th><th>Durum</th><th>Üyelik Tarihi</th><th>İşlem</th></tr></thead><tbody>
<?php $p=1;
if(empty($_GET['p']))$p=1;
else $p=$_GET['p'];
$maximum=12;
$limitbasla=($p-1)*$maximum;
$limitbitir=$maximum;
$sorguurunler=read("SELECT * FROM uyeler LIMIT $limitbasla,$limitbitir", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) {  ?>
<tr><td><?php echo $sonucurunler['id']?></td>
<td><?php echo $sonucurunler['il']?></td>
<td><?php echo $sonucurunler['ilce']?></td>
<td><?php echo $sonucurunler['adsoyad']?></td>
<td><?php echo $sonucurunler['email']?></td>
<td><?php echo $sonucurunler['durum']?></td>
<td><?php echo $sonucurunler['tarih']?></td>

<td style="width:10%"><a class="btn btn-info" style="background-color:green" href="kullanici-liste.php?i=TRkullaniciduzenle&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-edit icon-white"></i></a> 
<a class="btn btn-default" style="background-color:#333;color:white" href="kullanici-liste.php?i=TRkullanicisil&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-trash icon-white"></i></a></td>
</tr></tbody><?php } ?>
<ul class="pagination" style="margin:17px">
<?php $sorgukategoriurunsayisi= read("SELECT COUNT(id) as sayi FROM uyeler", 1, []); 
$sayi=0;
foreach ($sorgukategoriurunsayisi[1] as $sonuckategoriurunsayisi) {
$sayi=$sonuckategoriurunsayisi['sayi']; }
if($sayi>$maximum)
$sayi=$sayi/$maximum+1;
else $sayi=0;
for($j=1;$j<$sayi;$j++)
{ if($p==$j){echo '<li><a class="page-numbers" href="kullanici-liste.php?i=TRkullanici'.$id.'&p='.$j.'">'.$j.'</a></li>'; }
else {echo '<li><a class="page-numbers" href="kullanici-liste.php?i=TRkullanici'.$id.'&p='.$j.'">'.$j.'</a></li>'; } } ?></ul></table></section></div></div><?php }?>
<!----------------------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------------------->
<?php if($_GET["i"]=="TRkullaniciekle"){ ;?>
<div class="row" style="margin-top:-25px"><div class="col-sm-12"><br>
<center><h2>Yeni Kullanıcı Ekle</h2></center>
<form action="kullanici-liste.php?i=TRkullanicieklendi" method="post" enctype="multipart/form-data" style="margin:30px">

<div class="row"><div class="form-group col-6"><input type="text" class="form-control" name="adsoyad" placeholder="Ad-Soyad"></div>
<div class="form-group col-6"><input type="text" class="form-control" name="email" placeholder="E-Mail Adresi"></div></div>

<div class="row"><div class="form-group col-6"><input class="form-control" placeholder="Şifre" type='text' name="sifre"/> </div>
<div class="form-group col-6"><input class="form-control" type='text' placeholder="Şifre Tekrarı"  name="sifre"/></div></div>

<div class="row"><div class="form-group col-6"><input class="form-control" type="text" name="onyazi" placeholder="Üye Hakkında Kısa Ön Yazı"></div>
<div class="form-group col-6"><input class="form-control" type="text" name="telefon" placeholder="İletişim Numarası"></div></div>

<div class="row"><div class="col-lg-4 col-md-4"><div><label style="font-weight:900">Aktif / Pasif</label>
<select class="form-control" name="durum">
<option value="Aktif" class="form-control" selected>Aktif Et</option>
<option value="Pasif" class="form-control">Pasif Et</option>
</select>       </div></div>		

<div class="form-group col-4"><label style="font-weight:900">Şehir ?</label><input class="form-control" type="text" name="il" placeholder="Şehir ?"></div>

<div class="form-group col-4"><label style="font-weight:900">İlçe ?</label><input class="form-control" type="text" name="ilce" placeholder="İlçe ?"></div></div>

<div class="row"><div class="form-group col-9"><label style="font-weight:900">Üye Hakkında</label><input style="height:70px" type="text" class="form-control" name="hakkinda"></div>	

<div class="col-3"><label style="font-weight:900">Avatar : </label><br><br>
<input type="file" class="form-control" name="avatar"></div>
</div>

<input name="TRkullaniciekle" type="hidden" value="ekle" />

<hr><button type="submit" name="uyeol" class="btn btn-success btn-block" style="color:white">Kullanıcı Ekle</button>
<input name="tarih" type="hidden" value="<?php echo date("j-m-Y"); ?>"> 
</div></div><?php }?>


<?php if($_GET["i"]=="TRkullanicieklendi"){?>
<?php if($_POST['TRkullaniciekle']){
$klasor="../logo";	

$depo = "../logo/";
$a = rand(0, 100000000000);
$b = "$a.webp";
$neresi = $depo . basename($b);
if (@move_uploaded_file($_FILES['avatar']['tmp_name'], $neresi)) {

$adder = read("INSERT INTO uyeler (`adsoyad`,`email`,`sifre`,`tarih`,`il`,`ilce`,`hakkinda`,`telefon`,`onyazi`,`durum`,`avatar`)
VALUES('$_POST[adsoyad]','$_POST[email]','$_POST[sifre]','$_POST[tarih]','$_POST[il]','$_POST[ilce]','$_POST[hakkinda]','$_POST[telefon]','$_POST[onyazi]','$_POST[durum]','$b')", 0, []); }

if($adder[0]>0){
	header("Location:kullanici-liste.php?i=TRkullanici&q=success");
}else{
		header("Location:kullanici-liste.php?i=TRkullanici&q=danger");

}
} ?><?php } ?></form>	

<!----------------------------------------------------------------------------------------------------------------------------------->
<!------------------------------------------------------------------------------------------------------------------------------------>


<?php if($_GET["i"]=="TRkullaniciduzenle"){?>
<div class="col-md-12"><center><strong>Kullanıcı Bilgileri Güncelle</strong> </center><hr>
<?php if ($_POST) {
$klasor="../logo/";	

$id			=	$_POST['id'];
$adsoyad	=	$_POST['adsoyad'];
$email		=	$_POST['email'];
$sifre		=	$_POST['sifre'];
$il		    =	$_POST['il'];
$ilce		=	$_POST['ilce'];
$hakkinda		=	$_POST['hakkinda'];
$telefon	=	$_POST['telefon'];
$onyazi	=	$_POST['onyazi'];
$durum		=	$_POST['durum'];

$depo = "../logo/";
$a = rand(0, 100000000000);
$b = "$a.webp";
$neresi = $depo . basename($b);
if (@move_uploaded_file($_FILES['avatar']['tmp_name'], $neresi)) {

$sorguurunler = read("UPDATE uyeler set adsoyad='$adsoyad', email='$email', sifre='$sifre', il='$il',ilce='$ilce', hakkinda='$hakkinda', telefon='$telefon', onyazi='$onyazi',durum='$durum',avatar='$b' where id='$id'", 1, []);
} else {
$updater = read("UPDATE uyeler set adsoyad='$adsoyad', email='$email', sifre='$sifre', il='$il',ilce='$ilce', hakkinda='$hakkinda', telefon='$telefon', onyazi='$onyazi',durum='$durum' where id='$id'", 0, []);
}
	
if($sorguurunler[0]>0){
	header("Location:kullanici-liste.php?i=TRkullanici&q=success");

}else{
	header("Location:kullanici-liste.php?i=TRkullanici&q=danger");

}

} else if (!empty($_GET['id'])) {

$id = $_GET['id'];
$sorgu2 = read("SELECT * FROM uyeler WHERE id='$id'", 0, []);
$statu = $sorgu2[1];		?>

<form style="margin:30px" action="kullanici-liste.php?i=TRkullaniciduzenle&id=<?php echo $statu['id'];?>" method="post" class="form-horizontal" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo $statu['id'];?>" />

<div class="row"><div class="col-lg-6 col-md-6"><div><label style="font-weight:900">Kullanıcı Adı</label>
<input type="text" name="adsoyad" value="<?php echo $statu['adsoyad']; ?>" class="form-control"></div></div>
<div class="form-group col-6"><label style="font-weight:900">E-Mail hakkinda</label>
<input type="text" required="required" class="form-control" name="email" value="<?php echo $statu['email']; ?>"></div>	</div>

<div class="row"><div class="col-lg-6 col-md-6"><div><label style="font-weight:900">Aktif / Pasif</label>
<select class="form-control" name="durum">
<option class="form-control"><?php echo $statu['durum']?></option>
<option value="Aktif" class="form-control">Aktif Et</option>
<option value="Pasif" class="form-control">Pasif Et</option>		</select>       </div></div>	

<div class="form-group col-6"><label style="font-weight:900">Şifre</label>
<input class="form-control" type='password' id='test-input' name="sifre" value="<?php echo $statu['sifre']; ?>"/> 
<i type='button' id='check' class="fa fa-eye" style="position:absolute;margin-top:-25px;margin-left:90%"></i></div>			</div>

<div class="row">
<div class="form-group col-6"><label style="font-weight:900">İletişim Numarası</label><input class="form-control" type="text" name="telefon" value="<?php echo $statu['telefon']; ?>"></div>
<div class="form-grou col-6"><label style="font-weight:900">Ön Yazı</label><input class="form-control" type="text" name="onyazi" value="<?php echo $statu['onyazi']; ?>"></div>
</div>

<div class="row"><div class="form-group col-6"><label style="font-weight:900">Şehir ?</label><input class="form-control" type="text" name="il" value="<?php echo $statu['il']; ?>"></div>

<div class="form-group col-6"><label style="font-weight:900">İlçe ?</label><input class="form-control" type="text" name="ilce" value="<?php echo $statu['ilce']; ?>"></div></div>

<div class="row"><div class="form-group col-12"><label style="font-weight:900">Üye Hakkında</label><input style="height:70px" type="text" class="form-control" name="hakkinda" value="<?php echo $statu['hakkinda']; ?>"></div>		</div>

<div class="col-md-3"><img src="../logo/<?php echo $statu['avatar'];?>" style="width:150px;height:150px" /><br><br></div>
<label style="font-weight:900"> Kategori Reklam Görseli ( 250px X 350px / Dikey )</label>
<input type="file" name="avatar" id="logo" id="fileField" style="width:100%"/><hr>

<div class="col-lg-6 col-md-6"><hr><br>
<input class="btn btn-success btn-block btn-lg font-sm" type="submit" name="update" value="BİLGİLERİ GÜNCELLE"/></div><hr></div>

</form></div><?php } } ?>

<!------------------------------------------------------------------------------------------------------------------------------------>
<!------------------------------------------------------------------------------------------------------------------------------------>



<script type='text/javascript'>
$(document).ready(function() {
$('#check').click(function() {
if ($('#test-input').attr('type') == 'text') {
$('#test-input').attr('type', 'password');
} else {
$('#test-input').attr('type', 'text');
}
});
});
</script>




<?php if (isset($_GET['i'])) {
if ($_GET['i'] == "TRkullanicisil") {
$updater = read("delete from uyeler where id='$_GET[id]'", 1, []);
if ($updater[0] > 0) {
header("Location:" . $_SERVER['HTTP_REFERER']);
} else {
header("Location:" . $_SERVER['HTTP_REFERER']);
}}}?>

 
</div></div></div></section></div><?php include('footer.php');?>
