<!DOCTYPE html>
<html lang="tr">
<?php

function herAlert($info)
{
    $title = "";
    $icon = "";
    if ($info == "danger") {
        $icon = "error";
        $title = "Hata";
        $text = "Giriş Başarısız.";
    } else if ($info == "warning") {
        $icon = "warning";
        $title = "Uyarı";
        $text = "Eksik bilgi girişi.";
    } else if ($info == "yetki") {
        $icon = "error";
        $title = "Uyarı";
        $text = "Yetkiniz yok.";
    } else if ($info == "success") {
        $icon = "success";
        $title = "Bilgi";
        $text = "Çıkış başarılı.";
    }

    echo '<script>herAlert("' . $icon . '","' . $title . '","' . $text . '")</script>';
}
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Yönetim Paneli</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
    <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<body class="login-img3-body" style="background-image:url(../logo/arka.jpg);">

    <script>
        function herAlert(icon1, title1, text1) {
            Swal.fire({
                icon: icon1,
                title: title1,
                text: text1

            })
        }
    </script>

    <?php
    if (isset($_GET['q'])) {
        if ($_GET['q'] != "") {
            herAlert($_GET['q']);
        }
    }
    ?>
    <div class="row" style="margin-left:35%;margin-right:20%;margin-top:20%;margin-bottom:20%">
        <center>
            <h1 style="width:100%;color:#2ed5c8">Site Yönetimine Giriş Yapın</h1><br>
            <form action="islem.php" method="post">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="form-group"><i class="fa fa-asterisk" style="color:red"></i>&nbsp;&nbsp;<label style="color:#2ed5c8;font-weight:900">&nbsp;&nbsp;E-Mail Adresiniz</label>
                            <input type="text" class="form-control" name="email" required="required">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="form-group"><i class="fa fa-asterisk" style="color:red"></i>&nbsp;&nbsp;<label style="color:#2ed5c8;font-weight:900">&nbsp;&nbsp;Kullanıcı Şifreniz</label>
                            <input type="password" class="form-control" name="password" required="required">
                        </div>
                    </div>
                </div>
                <input class="btn btn-block btn-lg col-md-12" style="width:100%;background-color:#2ed5c8;color:#fff" type="submit" name="login" value="Giriş Yap" />
            </form>
        </center>
    </div>
</body>

</html>