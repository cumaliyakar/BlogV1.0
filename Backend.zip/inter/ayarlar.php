<?php include('header.php');
$durum =  $ayarSorgu[1];?>

    <div class="content-wrapper">

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary card-outline">

<?php if ($_GET["i"] == "ayarlar") { ?>
<center><b><h3>Web Site Ayarlarını Güncelle</h3></center>

<?php if ($_POST) {
$klasor = "../logo/";
$idd = $_POST["idd"];
$password        =    $_POST['password'];
$email           =    $_POST['email'];
$emaill          =    $_POST['emaill'];
$firma           =    $_POST['firma'];
$baslik          =    $_POST['baslik'];
$detay           =    $_POST['detay'];
$anahtar         =    $_POST['anahtar'];
$telefon         =    $_POST['telefon'];
$whatsapp        =    $_POST['whatsapp'];
$adres           =    $_POST['adres'];
$sehir           =    $_POST['sehir'];
$ilce            =    $_POST['ilce'];
$facebook        =    $_POST['facebook'];
$twitter         =    $_POST['twitter'];
$linkedin        =    $_POST['linkedin'];
$instagram       =    $_POST['instagram'];
$youtube         =    $_POST['youtube'];
$harita          =    $_POST['harita'];

$logo = "";
if (!empty($_FILES['anaresim']['name'])) {
$uret = array("as", "rt", "ty", "yu", "fg");
$uzanti = substr($_FILES['anaresim']['name'], -4, 4);
$sayi_tut = rand(1, 10000);
$yeni_ad = $uret[rand(0, 4)] . $uret[rand(0, 4)] . $uret[rand(0, 4)] . $sayi_tut . $uzanti;
move_uploaded_file($_FILES['anaresim']['tmp_name'], $klasor . "/" . $yeni_ad);
$logo = "../logo/" . $yeni_ad;}

$ikon = "";
if (!empty($_FILES['babaresim']['name'])) {
$uret = array("as", "rt", "ty", "yu", "fg");
$uzanti = substr($_FILES['babaresim']['name'], -4, 4);
$sayi_tut = rand(1, 10000);
$yeni_ad = $uret[rand(0, 4)] . $uret[rand(0, 4)] . $uret[rand(0, 4)] . $sayi_tut . $uzanti;
move_uploaded_file($_FILES['babaresim']['tmp_name'], $klasor . "/" . $yeni_ad);
$ikon = "../logo/" . $yeni_ad;}

$querystring = "UPDATE ayarlar SET password='$password', email='$email',emaill='$emaill', firma='$firma',baslik='$baslik', detay='$detay', anahtar='$anahtar', telefon='$telefon' ,whatsapp='$whatsapp',adres='$adres', sehir='$sehir', ilce='$ilce', facebook='$facebook' ,twitter='$twitter' ,linkedin='$linkedin',instagram='$instagram',youtube='$youtube',harita='$harita'";

if (!empty($logo)) {
$querystring = $querystring . ",logo='$logo'";}

if (!empty($ikon)) {
$querystring = $querystring . ",ikon='$ikon'";}

$ayarKaydet = read($querystring . "Where id =?", 0, [$idd]);
if ($ayarKaydet[0] > 0) {
$_SESSION['Yonetici'] = $_POST['email'];
header("Location:ayarlar.php?i=ayarlar&id=1&q=success");
} else {
header("Location:ayarlar.php?i=ayarlar&id=1&q=danger");}
} else if (!empty($_GET['id'])) {
$id = $_GET['id'];
$ayarsorgu = read("SELECT * FROM ayarlar Where id =?", 0, [$id]);

$sonucurunozellik = $ayarsorgu[1];
if ($ayarsorgu[0] > 0) {
$password        =    $sonucurunozellik['password'];
$email            =    $sonucurunozellik['email'];
$emaill            =    $sonucurunozellik['emaill'];
$firma            =    $sonucurunozellik['firma'];
$baslik            =    $sonucurunozellik['baslik'];
$detay            =    $sonucurunozellik['detay'];
$anahtar        =    $sonucurunozellik['anahtar'];
$telefon        =    $sonucurunozellik['telefon'];
$whatsapp            =    $sonucurunozellik['whatsapp'];
$adres            =    $sonucurunozellik['adres'];
$sehir            =    $sonucurunozellik['sehir'];
$ilce            =    $sonucurunozellik['ilce'];
$facebook        =    $sonucurunozellik['facebook'];
$twitter        =    $sonucurunozellik['twitter'];
$linkedin        =    $sonucurunozellik['linkedin'];
$instagram        =    $sonucurunozellik['instagram'];
$youtube        =    $sonucurunozellik['youtube'];      }
$harita        =    $sonucurunozellik['harita'];      }
$urundata = $ayarsorgu[1]; ?>

<form method="post" name="form1" enctype="multipart/form-data" style="margin:30px">
<input type="hidden" name="idd" class="form-control" value="<?php echo $urundata['id']; ?>">
<div class="row">
<div class="col-md-6">
<div class="form-group"><label>Admin E-Mail</label>
<input type="text" class="form-control" name="email" value="<?php echo $urundata['email']; ?>">
</div>
</div>
<div class="col-md-6">
<div class="form-group"><label>Admin Kullanıcı Şifre</label>
<input type="text" class="form-control" name="password" value="<?php echo $urundata['password']; ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group"><label> Site Başlığı </label>
<input type="text" class="form-control" name="baslik" value="<?php echo $urundata['baslik']; ?>">
</div>
</div>
<div class="col-md-6">
<div class="form-group"><label>Site Sahibi/Firma</label>
<input type="text" class="form-control" name="firma" value="<?php echo $urundata['firma']; ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group"><label>İletişim Telefon</label>
<input type="text" class="form-control" name="telefon" placeholder="Başında +90 olmadan yazınız. Örn : 0505...." value="<?php echo $urundata['telefon']; ?>">
</div>
</div>
<div class="col-md-6">
<div class="form-group"><label>Site E-Mail</label>
<input type="text" class="form-control" name="emaill" value="<?php echo $urundata['emaill']; ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group"><label>Whatsapp No</label>
<input type="text" class="form-control" name="whatsapp" placeholder="Başında +90 olmadan yazınız. Örn : 0505...." value="<?php echo $urundata['whatsapp']; ?>">
</div>
</div>
<div class="col-md-6">
<div class="form-group"><label>Youtube Url </label>
<input type="text" class="form-control" name="youtube" placeholder="Direkt Hesap URL'sini kopyalayıp buraya yapıştırın" value="<?php echo $urundata['youtube']; ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group"><label> Facebook Url</label>
<input type="text" class="form-control" name="facebook" placeholder="Direkt Hesap URL'sini kopyalayıp buraya yapıştırın" value="<?php echo $urundata['facebook']; ?>">
</div>
</div>
<div class="col-md-6">
<div class="form-group"><label>Twitter Url</label>
<input type="text" class="form-control" name="twitter" placeholder="Direkt Hesap URL'sini kopyalayıp buraya yapıştırın" value="<?php echo $urundata['twitter']; ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group"><label> İnstagram Url</label>
<input type="text" class="form-control" name="instagram" placeholder="Direkt Hesap URL'sini kopyalayıp buraya yapıştırın" value="<?php echo $urundata['instagram']; ?>">
</div>
</div>
<div class="col-md-6">
<div class="form-group"><label> Linkedin Url</label>
<input type="text" class="form-control" name="linkedin" placeholder="Direkt Hesap URL'sini kopyalayıp buraya yapıştırın" value="<?php echo $urundata['linkedin']; ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group"><label>Şehir</label>
<input type="text" class="form-control" name="sehir" value="<?php echo $urundata['sehir']; ?>">
</div>
</div>
<div class="col-md-6">
<div class="form-group"><label>İlçe</label>
<input type="text" class="form-control" name="ilce" value="<?php echo $urundata['ilce']; ?>">
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group"><label>Adres #1</label>
<textarea name="adres" type="text" placeholder="adresinizi yazınız. Örn: Ankara Mah. Ankara Cad. Ankara Sok. Ankara Apt. No:1881" rows="4" style="width:100%"><?php echo $urundata['adres']; ?></textarea>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group"><label>Anahtar Kelimeler</label>
<textarea name="anahtar" type="text" placeholder="Aralarına virgül koyarak, kelime kelime yazınız. Örn : website , site, yazılım,firma,üretim vs..." rows="4" style="width:100%"><?php echo $urundata['anahtar']; ?></textarea>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group"><label>WebSite Açıklama</label>
<textarea name="detay" type="text" placeholder="Max 150 kelime yazınız.SEO için. Örn: İthalat ve ihracat yapan firmayız. vs..." rows="4" style="width:100%"><?php echo $urundata['detay']; ?></textarea>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group"><label>İşletme Haritası</label>
<textarea name="harita" type="text" placeholder="maps.google.com adresine gidin,adresinizi bulun,PAYLAŞ butonuna tıklayıp HARİTA YERLEŞTİRME yazan yere tıklayıp HTMLyi KOPYALA yazan yere tıklayıp buraya ekleyip yapıştırın.SONRASINDA  width='600' yazan yeri  width='100%' şeklinde değiştiriniz." rows="4" style="width:100%"><?php echo $urundata['harita']; ?></textarea>
</div>
</div>
</div>
<div class="row">
<div class="col-md-5">
<div class="form-group"><label>WebSite Logo (100px X 100px)</label>
<img src="../logo/<?php echo $urundata['logo']; ?>" style="width:200px;height:100px">
<input type="file" name="anaresim" id="anaresim" />
</div>
</div>
<div class="col-md-5">
<div class="form-group"><label>WebSite ÜST İkon (100px X 100px)</label>
<img src="../logo/<?php echo $urundata['ikon']; ?>" style="width:100px;height:100px">
<input type="file" name="babaresim" id="babaresim" onChange="preview(this)" />
</div>
</div>
<div class="col-md-2"><br><input name="TRayarguncelle" class="btn btn-success btn-block btn-lg font-sm" type="submit" value="GÜNCELLE" /></div>
</div><br>
</form><?php } ?>
                                <!---->
                                <!---->
                                <!----><br><br>
                                <hr><br><br>
                               
                         
       




                    </div>
                </div>
            </div>
        </section>
    </div><?php include('footer.php'); ?>