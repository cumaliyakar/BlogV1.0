<?php use Phppot\CountryState;?>
<?php include('header.php');
$durum =  $ayarSorgu[1];?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" type="text/javascript"></script>

<?php require_once __DIR__ . '/anakategori.php';
$countryState = new CountryState();
$countryResult = $countryState->getAllCountry();
?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" type="text/javascript"></script>

<script>

function getState(val) {
$("#loader").show();
$.ajax({
type: "POST",
url: "altkategori.php",
data:'ana_key='+val,
success: function(data){
$("#alt-list").html(data);
$("#loader").hide();
}
});
}
</script>


<div class="content-wrapper"><div class="content-header"><div class="container-fluid"><div class="row mb-2">
<div class="col-sm-12">

<a href="kategori.php?i=katust" class="w3-button w3-medium w3-green pull-left">Üst Kategoriler</a>
<a href="kategori.php?i=katustekle" class="w3-button w3-medium w3-green pull-right">Üst Kategori Ekle +</a>
<a href="kategori.php?i=katalt" class="w3-button w3-medium w3-blue pull-left">Alt Kategoriler</a>
<a href="kategori.php?i=kataltekle" class="w3-button w3-medium w3-blue pull-right">Alt Kategori Ekle +</a>
</div></div></div></div>

<section class="content"><div class="row">


<div class="col-md-12"><div class="card card-primary card-outline">
<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->
<?php if($_GET["i"]=="katust"){ ?><div class="container-fluid"><div class="row"><div class="col-12">
<table id="example1" class="table table-bordered table-striped">
<thead class="thead-dark"><tr><th style="width:1%">#</th><th>Ana Kategori Adı</th><th style="width:21%">İşlem</th></tr></thead>
<?php $p=1;
if(empty($_GET['p']))$p=1;
else $p=$_GET['p'];
$maximum=100;
$limitbasla=($p-1)*$maximum;
$limitbitir=$maximum;
$sorgusalonler=read("SELECT * FROM anakategori ORDER BY ana_id DESC LIMIT $limitbasla,$limitbitir", 1, []);
foreach ($sorgusalonler[1] as $sonucsalonler) { ?>
<tr><td><?php echo $sonucsalonler['ana_id'];?></td>
<td><?php echo $sonucsalonler['ana_title'];?></td>
<td class="pull-right"><a class="btn btn-info" href="kategori.php?i=katustduzenle&id=<?php echo $sonucsalonler['ana_id'];?>"><i class="fa fa-edit" style="color:white"></i> &nbsp;Düzenle </a> &nbsp;&nbsp;
<a class="btn btn-danger" href="kategori.php?i=katustsil&id=<?php echo $sonucsalonler['ana_id'];?>"><i class="fa fa-trash" style="color:white"></i>&nbsp;Sil </a>			</td></tr><?php } ?></table></div></div><?php }?>
<!-------------------------------------------------------------------------------------------------------------->

<?php if (isset($_GET["i"])) {
if ($_GET["i"] == "katustduzenle") { 
$id=$_GET['id'];
$sorguurunozellik=read("SELECT * FROM anakategori WHERE ana_id='$id'", 1, []);
foreach ($sorguurunozellik[1] as $urundata);?>

<form action="kategori.php?i=katustduzenle" method="post" name="form1" enctype="multipart/form-data" style="margin:30px">
<input type="hidden" name="id" class="form-control" value="<?php echo $urundata['ana_id'];?>">
<input type="hidden" name="ana_key" class="form-control" value="<?php echo $urundata['ana_id'];?>">

<div class="row">
<div class="form-group col-md-6"><label style="font-weight:900"><h3>Kategori Adı : </h3> </label>
<input type="text" name="ana_title" class="form-control" value="<?php echo $urundata['ana_title'];?>"></div>
	
<div class="col-md-6">
<br><br><input class="btn btn-success" type="submit" name="update" value="GÜNCELLE" /></div> 			</div>	</form>		 
</div>
<?php if (isset($_POST['update'])) {
$id=$_POST["id"];
$ana_title = $_POST['ana_title'];
$ana_id = $_POST['ana_key'];

$updater = read("UPDATE anakategori SET ana_title='$ana_title',ana_key='$ana_id' where ana_id='$id'", 0, []);

if ($updater[0] > 0) {
header("Location:kategori.php?i=katust&q=success");
} else {
header("Location:kategori.php?i=katust&q=danger");
}

}}}?>
<!-------------------------------------------------------------------------------------------------------------->

<?php if($_GET["i"]=="katustekle"){ ?>
<?php if($_POST){
$ana_title = $_POST['ana_title'];
$ana_id = $_POST['ana_key'];

$sorguurunekle=read("INSERT INTO anakategori (ana_title,ana_key) 
VALUES('$ana_title','$ana_id')", 0, []);

echo'<script language="javascript">alert("Bilgiler Başarıyla Tamamlandı.");</script><script language="javascript">window.location="kategori.php?i=katust";</script></center>'; }else { ?>

<div class="container-fluid"><div class="row"><div class="col-12"><div class="messages-headline"><h4>Yeni Ana Kategori Ekle</h4><br></div>

<form method="post" enctype="multipart/form-data">
<div class="row"><div class="col-md-6"><h3> Kategori Adı : </h3><br>
<input type="text" name="ana_title" class="form-control"></div>

<?php $sorgusalonler=read("SELECT * FROM anakategori order by ana_id desc limit 1", 1, []);
foreach ($sorgusalonler[1] as $sonucsalonler) { ?>
<input name="ana_key" type="hidden" value="<?php echo $sonucsalonler['ana_id']+1;?>" /><?php }?>

<div class="col-md-6"><br><br><br><button type="submit" class="btn btn-success" style="width:100px">EKLE</button> 
</form></div>		</div>								<?php } ?></div></div></div><?php } ?>
<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->


<!-------------------------------------------------------------------------------------------------------------->
<?php if($_GET["i"]=="katalt"){ ?><div class="container-fluid"><div class="row"><div class="col-12">
<table id="example1" class="table table-bordered table-striped">
<thead class="thead-dark"><tr><th style="width:1%">#</th><th>Alt Kategori Adı</th><th style="width:21%">İşlem</th></tr></thead>
<?php $p=1;
if(empty($_GET['p']))$p=1;
else $p=$_GET['p'];
$maximum=100;
$limitbasla=($p-1)*$maximum;
$limitbitir=$maximum;
$sorgusalonler=read("SELECT * FROM altkategori ORDER BY alt_id DESC LIMIT $limitbasla,$limitbitir", 1, []);
foreach ($sorgusalonler[1] as $sonucsalonler) { ?>
<tr><td><?php echo $sonucsalonler['alt_id'];?></td>
<td><?php echo $sonucsalonler['alt_title'];?></td>
<td class="pull-right"><a class="btn btn-info" href="kategori.php?i=kataltduzenle&id=<?php echo $sonucsalonler['alt_id'];?>"><i class="fa fa-edit" style="color:white"></i> &nbsp;Düzenle </a> &nbsp;&nbsp;
<a class="btn btn-danger" href="kategori.php?i=kataltsil&id=<?php echo $sonucsalonler['alt_id'];?>"><i class="fa fa-trash" style="color:white"></i>&nbsp;Sil </a>			</td></tr><?php } ?></table></div></div><?php }?>
<!-------------------------------------------------------------------------------------------------------------->
<?php if (isset($_GET["i"])) {
if ($_GET["i"] == "kataltduzenle") { 
$id=$_GET['id'];
$sorguurunozellik=read("SELECT * FROM altkategori WHERE alt_id='$id'", 1, []);
foreach ($sorguurunozellik[1] as $urundata);?>

<form action="kategori.php?i=kataltduzenle" method="post" name="form1" enctype="multipart/form-data" style="margin:30px">

<input type="hidden" name="id" class="form-control" value="<?php echo $urundata['alt_id'];?>">
<input type="hidden" name="alt_key" class="form-control" value="<?php echo $urundata['alt_id'];?>">

<div class="row"><div class="col-md-6"><label style="font-weight:900"><h3>Kategori Adı : </h3> </label>
<input type="text" name="alt_title" class="form-control" value="<?php echo $urundata['alt_title'];?>"></div>
	
<div class="col-md-3"><div class="form-group"><label style="font-weight:900"><h3> Üst Kategori Adı : </h3></label>
<select name="alt_ustkey" class="form-control" onChange="getState(this.value);">

<?php foreach ($countryResult as $country) { ?>
<option <?= ($urundata['alt_ustkey']==$country['ana_key'])?"selected":"" ?> value="<?php echo $country["ana_key"]; ?>"><?php echo $country["ana_title"]; ?></option>
<?php } ?></select></div></div> 

<div class="col-md-3"><br><br><input class="col-md-6 btn btn-success btn-block" type="submit" name="update" value="GÜNCELLE" /></div>
</div>			</form>

<?php if (isset($_POST['update'])) {
$id=$_POST["id"];
$alt_title = $_POST['alt_title'];
$alt_id = $_POST['alt_key'];
$alt_ustkey = $_POST['alt_ustkey'];

$updater = read("UPDATE altkategori SET alt_title='$alt_title',alt_key='$alt_id',alt_ustkey='$alt_ustkey' where alt_id='$id'", 0, []);

if ($updater[0] > 0) {
header("Location:kategori.php?i=katalt&q=success");
} else {
header("Location:kategori.php?i=katalt&q=danger");
}
}}}?>
<!-------------------------------------------------------------------------------------------------------------->
<?php if($_GET["i"]=="kataltekle"){ ?>
<?php if($_POST){
$alt_title = $_POST['alt_title'];
$alt_key = $_POST['alt_key'];
$alt_ustkey = $_POST['alt_ustkey'];

$sorguurunekle=read("INSERT INTO altkategori (alt_title,alt_key,alt_ustkey) 
VALUES('$alt_title','$alt_key','$alt_ustkey')", 0, []); 

echo'<script language="javascript">alert("Bilgiler Başarıyla Tamamlandı.");</script><script language="javascript">window.location="kategori.php?i=katalt";</script></center>'; }else { ?>

<div class="container-fluid"><div class="row"><div class="col-12"><div class="messages-headline"><h4>Yeni Alt Kategori Ekle</h4><br></div>

<form method="post" enctype="multipart/form-data">
<div class="row"><div class="col-md-6"><h3> Kategori Adı : </h3><br>
<input type="text" name="alt_title" class="form-control"></div>

<div class="col-md-3"><div class="form-group"><h3>Ana Kategori Adı : </h3><br>
<select name="alt_ustkey" class="form-control" onChange="getState(this.value);">
<option>Ana Kategori Seçiniz</option>
<?php foreach ($countryResult as $country) { ?>
<option value="<?php echo $country["ana_key"]; ?>"><?php echo $country["ana_title"]; ?></option>
<?php } ?></select></div></div>

<?php $sorgusalonler=read("SELECT * FROM altkategori order by alt_id desc limit 1", 1, []);
foreach ($sorgusalonler[1] as $sonucsalonler) { ?>
<input name="alt_key" type="hidden" value="<?php echo $sonucsalonler['alt_key']+1;?>" /><?php }?>

<div class="col-md-3"><br><br><br>
<button type="submit" class="btn btn-success" style="width:100%;margin-left:10px">EKLE</button> </form><br><br></div>		</div>								
<?php } ?></div></div></div><?php } ?>
<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->




<!-------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------->

<script src="plugins/jquery/jquery.min.js"></script>
<script>
$(function () {
$("#example1").DataTable({
"responsive": true, "lengthChange": true, "autoWidth": true,
"buttons": ["copy", "csv", "excel", "pdf", "print"]
}).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
});
</script>


<script src="plugins/datatables-buttons/buttons.flash.min.js"></script>


<?php if (isset($_GET['i'])) {
if ($_GET['i'] == "kataltsil") {
$updater = read("delete from altkategori where alt_id='$_GET[id]'", 1, []);
if ($updater[0] > 0) {
header("Location:" . $_SERVER['HTTP_REFERER']);
} else {
header("Location:" . $_SERVER['HTTP_REFERER']);
}}}?>

<?php if (isset($_GET['i'])) {
if ($_GET['i'] == "katustsil") {
$updater = read("delete from anakategori where ana_id='$_GET[id]'", 1, []);
if ($updater[0] > 0) {
header("Location:" . $_SERVER['HTTP_REFERER']);
} else {
header("Location:" . $_SERVER['HTTP_REFERER']);
}}}?>

</div></div></div></section></div></div></div></div></div><?php include('footer.php');?>


