<?php ob_start();
include('../baglan.php');
function herAlert($info)
{
$title = "";
$icon = "";
if ($info == "success") {
$icon = "success";
$title = "Bilgi";
$text = "Başarılı";
} else if ($info == "danger") {
$icon = "error";
$title = "Hata";
$text = "Beklenmeyen bir hata oluştu.";
} else if ($info == "warning") {
$icon = "warning";
$title = "Uyarı";
$text = "Eksik bilgi girişi.";
} else if ($info == "filter") {
$icon = "error";
$title = "Uyarı";
$text = "Yetkisiz bilgi girişi.";
}

echo '<script>herAlert("' . $icon . '","' . $title . '","' . $text . '")</script>';
}
session_start();

?>
<?php
if (isset($_SESSION['Yonetici'])) {
$ayarSorgu = read("SELECT * FROM ayarlar Where email =?", 0, [$_SESSION['Yonetici']]);
if ($ayarSorgu[0] > 0) {
} else {
header("Location:index.php?q=yetki");
}
} else {
header("Location:index.php?q=yetki");
}

$durum = $ayarSorgu[1];

if ($durum) { ?>

<!DOCTYPE html>
<html lang="tr">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
$statu = $durum; ?>

<title><?php echo $statu['baslik']; ?> Yönetim Paneli</title>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="shortcut icon" href="../resim/<?php echo $statu['ikon']; ?>" />

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
<link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
<link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
<link rel="stylesheet" href="dist/css/adminlte.min.css">
<link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
<link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="plugins/jquery/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
@media(max-width:767px) {
.hidden-mobile {
display: none;
}
}

@media(min-width:768px) {
.hidden-desktop {
display: none;
}
}
</style>
</head>
<style type="text/css">
@media print {
#printbtn {
display: none;
}
}
</style>
<style>
.butoncuk {
border: 2px solid gray;
color: gray;
background-color: white;
padding: 7px 10px;
border-radius: 8px;
font-size: 20px;
font-weight: bold;
}
</style>

<body class="hold-transition sidebar-mini layout-fixed">


<script>
function herAlert(icon1, title1, text1) {
Swal.fire({
icon: icon1,
title: title1,
text: text1

})
}
</script>

<?php
if (isset($_GET['q'])) {
if ($_GET['q'] != "") {
herAlert($_GET['q']);
}
}
?>


<div class="wrapper">

<nav class="main-header navbar navbar-expand navbar-white navbar-light">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
</li>
</ul>

<ul class="navbar-nav ml-auto">
<li class="nav-item"><a class="btn btn-info" href="anasayfa.php" target="_self" role="button" style="margin-right:20px">Panel Anasayfa <i class="fa fa-home"></i></a></li>

<li class="nav-item"><a class="btn btn-success" href="../index.php" target="_blank" role="button" style="margin-right:20px"> Siteye Git <i class="fa fa-globe"></i></a></li>

<li class="nav-item"><a class="btn btn-danger" href="cikis.php" role="button">ÇIKIŞ <i class="fa fa-sign-out-alt"></i></a></li>
<li class="nav-item"><a class="nav-link" data-widget="fullscreen" href="#" role="button"><i class="fas fa-expand-arrows-alt"></i></a></li>
<li class="nav-item"><a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
<i class="fas fa-th-large"></i></a></li>
</ul>
</nav> <?php include('menu.php');
} ?>