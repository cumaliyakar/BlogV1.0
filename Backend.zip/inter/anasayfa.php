<?php include('header.php'); ?>
<?php if ($durum) { ?>

<div class="content-wrapper"><div class="content-header"><div class="container-fluid"><div class="row mb-2">
<div class="col-sm-6"><h1 class="m-0">Sayın ; <span style="color:green"><?php echo $durum['firma'];?></span> Hoşgeldiniz</h1></div>
<div class="col-sm-6 hidden-mobile"><ol class="breadcrumb float-sm-right"><li class="breadcrumb-item"><a href="index.php">Anasayfa</a></li>
</ol></div></div></div></div>






<section class="content connectedSortable">
<div class="container-fluid">
<div class="row">



<!----------------------------------------------------------------------------------------------------------------------->
<div class="col-lg-3 col-6">
<div class="small-box bg-orange">
<div class="inner" style="color:#fff">
<?php $bilgi = read("SELECT COUNT(*) as sayi FROM mesaj", 0, []);
if ($bilgi[0] > 0) { ?> 
<h3><?php echo $bilgi[1]['sayi']; ?></h3>
<p>Adet Kayıtlı Mesaj</p><?php } ?>
</div>
<div class="icon"><i class="far fa-envelope"></i></div><a href="#" class="small-box-footer">
<center>
<p>
<a href="mesaj.php?i=TRmesaj" class="small-box-footer" style="color:#fff">Tüm Mesajlar</a>
&nbsp;&nbsp;<i class="fa fa-arrow-right fa-xs" style="color:#fff"></i>
</p>
</center>
</a>
</div>
</div>
<!----------------------------------------------------------------------------------------------------------------------->
<div class="col-lg-3 col-6">
<div class="small-box bg-indigo">
<div class="inner" style="color:#fff">
<?php
$bilgi = read("SELECT COUNT(*) as sayi FROM blog", 0, []);

if ($bilgi[0] > 0) {
?> <h3><?php echo $bilgi[1]['sayi']; ?></h3>
<p>Adet Kayıtlı Blog</p><?php } ?>
</div>
<div class="icon"><i class="fa fa-newspaper"></i></div><a href="#" class="small-box-footer">
<center>
<p>
<a href="blog.php?i=blog" class="small-box-footer" style="color:#fff">Tüm Bloglar</a>
&nbsp;&nbsp;<i class="fa fa-arrow-right fa-xs" style="color:#fff"></i>
</p>
</center>
</a>
</div>
</div>
<!----------------------------------------------------------------------------------------------------------------------->
<div class="col-lg-3 col-6">
<div class="small-box bg-teal">
<div class="inner" style="color:#fff">
<?php
$bilgi = read("SELECT COUNT(*) as sayi FROM reklam", 0, []);

if ($bilgi[0] > 0) {
?> <h3><?php echo $bilgi[1]['sayi']; ?></h3>
<p>Adet Kayıtlı Reklam</p><?php } ?>
</div>
<div class="icon"><i class="fa fa-images"></i></div><a href="#" class="small-box-footer">
<center>
<p>
<a href="reklam.php?i=reklamhepsi" class="small-box-footer" style="color:#fff">Tüm Reklamlar</a>
&nbsp;&nbsp;<i class="fa fa-arrow-right fa-xs" style="color:#fff"></i>
</p>
</center>
</a>
</div>
</div>
<!----------------------------------------------------------------------------------------------------------------------->
<div class="col-lg-3 col-6">
<div class="small-box bg-green">
<div class="inner" style="color:#fff">
<?php
$bilgi = read("SELECT COUNT(*) as sayi FROM uyeler", 0, []);

if ($bilgi[0] > 0) {
?> <h3><?php echo $bilgi[1]['sayi']; ?></h3>
<p>Adet Kayıtlı Üye</p><?php } ?>
</div>
<div class="icon"><i class="fa fa-user-plus"></i></div><a href="#" class="small-box-footer">
<center>
<p>
<a href="kullanici-liste.php?i=TRkullanici" class="small-box-footer" style="color:#fff">Tüm Üyeler</a>
&nbsp;&nbsp;<i class="fa fa-arrow-right fa-xs" style="color:#fff"></i>
</p>
</center>
</a>
</div>
</div>
<!----------------------------------------------------------------------------------------------------------------------->



<!----------------------------------------------------------------------------------------------------------------------->
<div class="col-lg-3 col-6">
<div class="small-box bg-pink">
<div class="inner" style="color:#fff">
<?php
$bilgi = read("SELECT COUNT(*) as sayi FROM abone", 0, []);

if ($bilgi[0] > 0) {
?> <h3><?php echo $bilgi[1]['sayi']; ?></h3>
<p>Adet Kayıtlı Abone</p><?php } ?>
</div>
<div class="icon"><i class="fa fa-thumps-up"></i></div><a href="#" class="small-box-footer">
<center>
<p>
<a href="abone.php?i=TRabone" class="small-box-footer" style="color:#fff">Tüm Aboneler</a>
&nbsp;&nbsp;<i class="fa fa-arrow-right fa-xs" style="color:#fff"></i>
</p>
</center>
</a>
</div>
</div>
<!----------------------------------------------------------------------------------------------------------------------->
<div class="col-lg-3 col-6">
<div class="small-box bg-red">
<div class="inner" style="color:#fff">
<?php
$bilgi = read("SELECT COUNT(*) as sayi FROM uyeler", 0, []);

if ($bilgi[0] > 0) {
?> <h3><?php echo $bilgi[1]['sayi']; ?></h3>
<p>Adet Kayıtlı Ürün</p><?php } ?>
</div>
<div class="icon"><i class="fa fa-tags"></i></div><a href="#" class="small-box-footer">
<center>
<p>
<a href="urunler.php?i=TRurun" class="small-box-footer" style="color:#fff">Tüm Ürünler</a>
&nbsp;&nbsp;<i class="fa fa-arrow-right fa-xs" style="color:#fff"></i>
</p>
</center>
</a>
</div>
</div>
<!----------------------------------------------------------------------------------------------------------------------->
<div class="col-lg-3 col-6">
<div class="small-box bg-blue">
<div class="inner" style="color:#fff">
<?php
$bilgi = read("SELECT COUNT(*) as sayi FROM yorum", 0, []);

if ($bilgi[0] > 0) {
?> <h3><?php echo $bilgi[1]['sayi']; ?></h3>
<p>Adet Kayıtlı Yorum</p><?php } ?>
</div>
<div class="icon"><i class="fa fa-comments"></i></div><a href="#" class="small-box-footer">
<center>
<p>
<a href="yorum.php?i=yorumhepsi" class="small-box-footer" style="color:#fff">Tüm Yorumlar</a>
&nbsp;&nbsp;<i class="fa fa-arrow-right fa-xs" style="color:#fff"></i>
</p>
</center>
</a>
</div>
</div>
<!----------------------------------------------------------------------------------------------------------------------->
<div class="col-lg-3 col-6">
<div class="small-box bg-orange">
<div class="inner" style="color:#fff">
<?php
$bilgi = read("SELECT COUNT(*) as sayi FROM sayfa", 0, []);

if ($bilgi[0] > 0) {
?> <h3><?php echo $bilgi[1]['sayi']; ?></h3>
<p>Adet Kayıtlı Sayfa</p><?php } ?>
</div>
<div class="icon"><i class="fa fa-file"></i></div><a href="#" class="small-box-footer">
<center>
<p>
<a href="sayfa.php?i=sayfahepsi" class="small-box-footer" style="color:#fff">Tüm Sayfalar</a>
&nbsp;&nbsp;<i class="fa fa-arrow-right fa-xs" style="color:#fff"></i>
</p>
</center>
</a>
</div>
</div>
<!----------------------------------------------------------------------------------------------------------------------->


<!----------------------------------------------------------------------------------------------------------------------->
</div>
</div>
</section>





<div class="row">

<section class="col-lg-12 connectedSortable">
<div class="card">
<div class="card-header">
<h3 class="card-title"><i class="ion ion-clipboard mr-1"></i>&nbsp;&nbsp;Site Trafiği</h3>
</div>
<div class="card-body">
<ul class="todo-list" data-widget="todo-list">

<?php echo "<table id='customers'><tr>
<td style='width:5%'><i class='fa fa-globe fa-spin'><i></td><td>Aktif Ziyaretçi</td><td style='width:5%'>";
#---Aktif Ziyaretçi Sayısı--------------------------------------------------------------------
$online = read("SELECT ip FROM online", 1, []);

$aktifkac = $online[0];
echo $aktifkac;
#---Aktif Ziyaretçi Sayısı--------------------------------------------------------------------			
echo "</td></tr><tr><td><i class='fa fa-running'><i></td><td>Dün Tekil</td><td><hr>";
#---Dün Tekil Toplam Kaç Kişi Girmiş----------------------------------------------------------
@$baslat  = date("Y-m-d");
@$year    = substr($baslat, 0, 4);
@$month   = substr($baslat, 5, 2);
@$day     = substr($baslat, 8, 2);
@$bitis   = date("Y-m-d", mktime(0, 0, 0, $month, $day - 1, $year));

$sorgula = read("SELECT tarih FROM ziyaret where tarih=?", 1, [$bitis]);

$dunku = $sorgula[0];
echo $dunku;
#---Dün Tekil Toplam Kaç Kişi Girmiş----------------------------------------------------------		
echo "</td></tr><tr><td><i class='fa fa-user'><i></td><td>Bugün Tekil</td><td><hr>";
#---Bugün Tekil Toplam Kaç Kişi Girmiş--------------------------------------------------------			
$bugunku = read("SELECT tarih FROM ziyaret where tarih=?", 1, [date("Y-m-d")]);

echo $bugunku[0];
#---Bugün Tekil Toplam Kaç Kişi Girmiş--------------------------------------------------------			
echo "</font></td></tr><tr><td><i class='fa fa-users'><i></td><td>Toplam Tekil</td><td><hr>";
#---Toplam Tekil Kaç Kişi Girmiş--------------------------------------------------------------			
$toplamZiyaret = read("SELECT * FROM ziyaret ", 1, []);

echo $toplamZiyaret[0];
#---Toplam Tekil Kaç Kişi Girmiş--------------------------------------------------------------			
echo "</td></tr></table><br>"; ?>

</ul>
</div>
</div>
</section>









</div></div></section></div><?php include('footer.php'); ?><?php } else { ?>    </html> <?php } ?>