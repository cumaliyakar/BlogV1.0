<?php use Phppot\CountryState;
include('header.php');?>
<?php if($_POST['login']){
$_SESSION['email']=$_POST["email"];
$_SESSION['password']=$_POST["password"];}
$kontrol = mysql_query("select * from ayarlar where email='$_SESSION[email]' and password='$_SESSION[password]'");
$durum = mysql_fetch_array($kontrol);
if ($durum) { ?>

<div class="content-wrapper"><div class="content-header"><div class="container-fluid"><div class="row mb-2">
<div class="col-sm-6"><h1 class="m-0">Kayıtlı Ürün Listesi</h1></div>
<div class="col-sm-6"><ol class="breadcrumb float-sm-right"><li class="breadcrumb-item"><a href="anasayfa.php">Anasayfa</a></li>
</ol></div></div></div></div>


<section class="content"><div class="row"><div class="col-md-12"><div class="card card-primary card-outline">

<?php if($_GET["i"]=="TRurun"){ ;?>
<div class="card-body"><table id="example1" class="table table-bordered table-striped">

<thead><tr><th style="width:1%">#</th><th style="width:10%">Görsel</th><th>Ürün Başlığı</th><th>Fiyat</th><th>Kod</th><th>İşlem</th></tr></thead><tbody>
<?php $p=1;
if(empty($_GET['p']))$p=1;
else $p=$_GET['p'];
$maximum=1000;
$limitbasla=($p-1)*$maximum;
$limitbitir=$maximum;
$sorguurunler=mysql_query("SELECT * FROM urun where dil='TR' ORDER BY id asc LIMIT $limitbasla,$limitbitir");
while($sonucurunler=mysql_fetch_array($sorguurunler)){ ?>
<tr><td><?php echo $sonucurunler['id']?></td><td><div class="w3-dropdown-hover">
<img src="<?php echo $sonucurunler['anaresimurl']?>" alt="<?php echo $sonucurunler['baslik']?>" style="width:84px;height:42px">
<div class="w3-dropdown-content" style="width:300px"><br>
<img src="<?php echo $sonucurunler['anaresimurl']?>" alt="<?php echo $sonucurunler['baslik']?>" style="width:100%;height:250px"></div></div></td>
<td><?php echo $sonucurunler['baslik']?></td>
<td><?php echo $sonucurunler['birimfiyat']?> <?php echo $sonucurunler['para']?></td>
<td><?php echo $sonucurunler['kod']?></td>

<td style="width:12%"><a class="btn btn-info" href="urunler.php?i=TRurun-duzenle&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-edit icon-white"></i></a> 
<a class="btn btn-info" href="urunler.php?i=TRurunsil&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-trash"></i></a></td>
</tr><?php } ?>	</tbody></table></div></div></div></div>

<div class="card-footer p-0"><div class="mailbox-controls"><div class="float-right"><div class="card-tools">
<ul class="pagination pagination-sm"><?php $sorgukategoriurunsayisi= mysql_query("SELECT COUNT(id) as sayi FROM urun where dil='TR' "); 
$sayi=0;
while($sonuckategoriurunsayisi=mysql_fetch_array($sorgukategoriurunsayisi)){ 
$sayi=$sonuckategoriurunsayisi['sayi']; }
if($sayi>$maximum)
$sayi=$sayi/$maximum+1;
else $sayi=0;
for($j=1;$j<$sayi;$j++)
{ if($p==$j){echo '<li class="page-item"><a class="page-link" href="urunler.php?i=TRurun&id='.$id.'&p='.$j.'">'.$j.'</a></li>'; }
else {echo '<li class="page-item"><a class="page-link" href="urunler.php?i=TRurun&id='.$id.'&p='.$j.'">'.$j.'</a></li>'; } } ?>	
</ul></div>		</div></div></div><?php } ?>
<!------------------------------------------------------------------------------------------------------------------------------------><!------------------------------------------------------------------------------------------------------------------------------------>
<?php if($_GET["i"]=="ENGurun"){ ;?>
<div class="card-body"><table id="example1" class="table table-bordered table-striped">

<thead><tr><th style="width:1%">#</th><th style="width:10%">Görsel</th><th>Ürün Başlığı</th><th>Fiyat</th><th>Kod</th><th>İşlem</th></tr></thead><tbody>
<?php $p=1;
if(empty($_GET['p']))$p=1;
else $p=$_GET['p'];
$maximum=1000;
$limitbasla=($p-1)*$maximum;
$limitbitir=$maximum;
$sorguurunler=mysql_query("SELECT * FROM urun where dil='ENG' ORDER BY id asc LIMIT $limitbasla,$limitbitir");
while($sonucurunler=mysql_fetch_array($sorguurunler)){ ?>
<tr><td><?php echo $sonucurunler['id']?></td><td><div class="w3-dropdown-hover">
<img src="<?php echo $sonucurunler['anaresimurl']?>" alt="<?php echo $sonucurunler['baslik']?>" style="width:84px;height:42px">
<div class="w3-dropdown-content" style="width:300px"><br>
<img src="<?php echo $sonucurunler['anaresimurl']?>" alt="<?php echo $sonucurunler['baslik']?>" style="width:100%;height:250px"></div></div></td>
<td><?php echo $sonucurunler['baslik']?></td>
<td><?php echo $sonucurunler['birimfiyat']?> <?php echo $sonucurunler['para']?></td>
<td><?php echo $sonucurunler['kod']?></td>

<td style="width:12%"><a class="btn btn-info" href="urunler.php?i=ENGurun-duzenle&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-edit icon-white"></i></a> 
<a class="btn btn-info" href="urunler.php?i=ENGurunsil&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-trash"></i></a></td>
</tr><?php } ?>	</tbody></table></div></div></div></div>

<div class="card-footer p-0"><div class="mailbox-controls"><div class="float-right"><div class="card-tools">
<ul class="pagination pagination-sm"><?php $sorgukategoriurunsayisi= mysql_query("SELECT COUNT(id) as sayi FROM urun where dil='ENG' "); 
$sayi=0;
while($sonuckategoriurunsayisi=mysql_fetch_array($sorgukategoriurunsayisi)){ 
$sayi=$sonuckategoriurunsayisi['sayi']; }
if($sayi>$maximum)
$sayi=$sayi/$maximum+1;
else $sayi=0;
for($j=1;$j<$sayi;$j++)
{ if($p==$j){echo '<li class="page-item"><a class="page-link" href="urunler.php?i=ENGurun&id='.$id.'&p='.$j.'">'.$j.'</a></li>'; }
else {echo '<li class="page-item"><a class="page-link" href="urunler.php?i=ENGurun&id='.$id.'&p='.$j.'">'.$j.'</a></li>'; } } ?>	
</ul></div>		</div></div></div><?php } ?>
<!------------------------------------------------------------------------------------------------------------------------------------><!------------------------------------------------------------------------------------------------------------------------------------>
<?php if($_GET["i"]=="DEurun"){ ;?>
<div class="card-body"><table id="example1" class="table table-bordered table-striped">

<thead><tr><th style="width:1%">#</th><th style="width:10%">Görsel</th><th>Ürün Başlığı</th><th>Fiyat</th><th>Kod</th><th>İşlem</th></tr></thead><tbody>
<?php $p=1;
if(empty($_GET['p']))$p=1;
else $p=$_GET['p'];
$maximum=1000;
$limitbasla=($p-1)*$maximum;
$limitbitir=$maximum;
$sorguurunler=mysql_query("SELECT * FROM urun where dil='DE' ORDER BY id asc LIMIT $limitbasla,$limitbitir");
while($sonucurunler=mysql_fetch_array($sorguurunler)){ ?>
<tr><td><?php echo $sonucurunler['id']?></td><td><div class="w3-dropdown-hover">
<img src="<?php echo $sonucurunler['anaresimurl']?>" alt="<?php echo $sonucurunler['baslik']?>" style="width:84px;height:42px">
<div class="w3-dropdown-content" style="width:300px"><br>
<img src="<?php echo $sonucurunler['anaresimurl']?>" alt="<?php echo $sonucurunler['baslik']?>" style="width:100%;height:250px"></div></div></td>
<td><?php echo $sonucurunler['baslik']?></td>
<td><?php echo $sonucurunler['birimfiyat']?> <?php echo $sonucurunler['para']?></td>
<td><?php echo $sonucurunler['kod']?></td>

<td style="width:12%"><a class="btn btn-info" href="urunler.php?i=DEurun-duzenle&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-edit icon-white"></i></a> 
<a class="btn btn-info" href="urunler.php?i=DEurunsil&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-trash"></i></a></td>
</tr><?php } ?>	</tbody></table></div></div></div></div>

<div class="card-footer p-0"><div class="mailbox-controls"><div class="float-right"><div class="card-tools">
<ul class="pagination pagination-sm"><?php $sorgukategoriurunsayisi= mysql_query("SELECT COUNT(id) as sayi FROM urun where dil='DE' "); 
$sayi=0;
while($sonuckategoriurunsayisi=mysql_fetch_array($sorgukategoriurunsayisi)){ 
$sayi=$sonuckategoriurunsayisi['sayi']; }
if($sayi>$maximum)
$sayi=$sayi/$maximum+1;
else $sayi=0;
for($j=1;$j<$sayi;$j++)
{ if($p==$j){echo '<li class="page-item"><a class="page-link" href="urunler.php?i=DEurun&id='.$id.'&p='.$j.'">'.$j.'</a></li>'; }
else {echo '<li class="page-item"><a class="page-link" href="urunler.php?i=DEurun&id='.$id.'&p='.$j.'">'.$j.'</a></li>'; } } ?>	
</ul></div>		</div></div></div><?php } ?>
<!------------------------------------------------------------------------------------------------------------------------------------><?php require_once __DIR__ . '/ustkat.php';
$countryState = new CountryState();
$countryResult = $countryState->getAllCountry();
$categoryResult = $countryState->getAllCatogry(); ?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" type="text/javascript"></script>

<script>
function getState(val) {
$("#loader").show();
$.ajax({
type: "POST",
url: "altkat.php",
data:'kategori_id='+val,
success: function(data){
$("#state-list").html(data);
$("#loader").hide();
}
});
}
</script> <!------------------------------------------------------------------------------------------------------------------------------------>

<script src="plugins/jquery/jquery.min.js"></script>
<script>
$(function () {
$("#example1").DataTable({
"responsive": true, "lengthChange": true, "autoWidth": true,
"buttons": ["copy", "csv", "excel", "pdf", "print"]
}).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
});
</script>
<script src="plugins/datatables-buttons/buttons.flash.min.js"></script>


<?php if($_GET["i"]=="TRurunekle"){?>
<?php if($_POST){
$klasor="../resim";	
$baslik=mysql_real_escape_string($_POST["baslik"]);
$aciklama=mysql_real_escape_string($_POST["aciklama"]);;
$kategori=mysql_real_escape_string($_POST["kategori"]);
$altkategori=mysql_real_escape_string($_POST["altkategori"]);
$koliebat=mysql_real_escape_string($_POST["koliebat"]);
$urunebat=mysql_real_escape_string($_POST["urunebat"]);
$birimadet=mysql_real_escape_string($_POST["birimadet"]);
$urunhacim=mysql_real_escape_string($_POST["urunhacim"]);
$kolihacim=mysql_real_escape_string($_POST["kolihacim"]);
$urunagirlik=mysql_real_escape_string($_POST["urunagirlik"]);
$koliagirlik=mysql_real_escape_string($_POST["koliagirlik"]);
$kod=mysql_real_escape_string($_POST["kod"]);
$marka=mysql_real_escape_string($_POST["marka"]);
$depozito=mysql_real_escape_string($_POST["depozito"]);
$dil=mysql_real_escape_string($_POST["dil"]);
$birimfiyat=mysql_real_escape_string($_POST["birimfiyat"]);
$koliadet=mysql_real_escape_string($_POST["koliadet"]);
$para=mysql_real_escape_string($_POST["para"]);
$secim=mysql_real_escape_string($_POST["secim"]);

$anaresimurl="";
if(!empty($_FILES['anaresim']['name'])){ 
$uret=array("cu","ma","li","ya","kar");
$uzanti=substr($_FILES['anaresim']['name'],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['anaresim']['tmp_name'],$klasor."/".$yeni_ad); 
$anaresimurl="../resim/".$yeni_ad;} 

$sorguurunekle=mysql_query("INSERT INTO urun (baslik,aciklama,kategori,altkategori,urunebat,koliebat,birimadet,urunhacim,kolihacim,urunagirlik,koliagirlik,kod,depozito,marka,dil,birimfiyat,koliadet,para,secim,anaresimurl) 
VALUES('$baslik','$aciklama','$kategori','$altkategori','$urunebat','$koliebat','$birimadet','$urunhacim','$kolihacim','$urunagirlik','$koliagirlik','$kod','$depozito','$marka','$dil','$birimfiyat','$koliadet','$para','$secim','$anaresimurl')") or die(mysql_error());

$soruguurunID=mysql_query("SELECT ID FROM urun ORDER BY ID DESC LIMIT 1");
$dataID=mysql_fetch_assoc($soruguurunID);
$productid=$dataID['ID'];
try{
$values = $_POST['altkategori'];
foreach ($values as $a){
$sorgucatekle=mysql_query("INSERT INTO urunkategoriler (kategoriID,yaziID) VALUES('$a','$productid')");}
}catch(Exception $istisna){}

$dosya_isim_sayi=count($_FILES['resim']['name']); 
for($i=0;$i<$dosya_isim_sayi;$i++){ 
if(!empty($_FILES['resim']['name'][$i])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['resim']['name'][$i],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i],$klasor."/".$yeni_ad); 
$url="../resim/".$yeni_ad;
$sorgu2=mysql_query("INSERT INTO market_resimler (marketilanid,yol) VALUES('$productid','$url')"); } }
	
echo'<script language="javascript">alert("Ürün Ekleme Başarıyla Tamamlandı.");</script><script language="javascript">window.location="urunler.php?i=TRurun";</script></center>';
 }else { ?>

<form method="post" name="form1" enctype="multipart/form-data" style="padding:30px">
<input type="hidden" name="dil" value="TR">

<div class="row"><div class="col-md-3"><div class="form-group"><label> Ürün Başlığı</label>
<input type="text" class="form-control" name="baslik"> </div></div>



<div class="col-md-3"><div class="form-group"><label>Ana Kategori Seçiniz</label>
<select name="kategori"  class="form-control"  onChange="getState(this.value);"><option>Kategori Seçiniz</option>
<?php foreach ($countryResult as $country) { ?><option value="<?php echo $country["kategori_id"]; ?>">
<?php echo $country["kategori_adi"]; ?></option><?php } ?></select></div></div>

<div class="col-md-3"><div class="form-group"><label>Alt Kategori Seçiniz</label>
<select name="altkategori[]" id="state-list" class="form-control"  onChange="getDistrict(this.value);">  </select></div></div>  


<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Nerede Yayımlansın ?</label>
<select name="secim" class="form-control">
<option value="serisonu">Bitti Bitiyor</option><option value="indirimli">Aldın Aldın</option>
<option value="dusukstok">Gitti Gidiyor</option><option value="outlet">Outlet Ürünler</option><option value="anasayfa">Anasayfa</option></select></div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Ürün Ebatı</label>
<input type="text" class="form-control" name="urunebat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Hacmi</label>
<input type="text" class="form-control" name="urunhacim" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Fiyatı</label>
<input type="text" class="form-control" name="birimfiyat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Para Birimi</label>
<input type="text" class="form-control" name="para" placeholder="Örneğin :  TL , € , $"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Ağırlığı</label>
<input type="text" class="form-control" name="urunagirlik" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Depozito</label>
<input type="text" class="form-control" name="depozito" placeholder="Örneğin : 3 €"> </div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Koli Ebatı</label>
<input type="text" class="form-control" name="koliebat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Hacmi</label>
<input type="text" class="form-control" name="kolihacim" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Ağırlığı</label>
<input type="text" class="form-control" name="koliagirlik" placeholder="Sadece Rakam Yazınız"> </div></div>		
<div class="col-md-2"><div class="form-group"><label>Koli İçi Adeti / Stok</label>
<input type="text" class="form-control" name="koliadet" placeholder="Sadece Rakam Yazınız"></div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Kodu</label>
<input type="text" class="form-control" name="kod" value="<?php echo $urundata['kod'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Markası</label>
<input type="text" class="form-control" name="marka" value="<?php echo $urundata['marka'];?>"> </div></div>	
</div>

<label class="control-label">Ürün Açıklaması</label><textarea name="aciklama" id="summernote"></textarea>

<hr><div class="form-group"><label class="control-label">Ana Resim Seç <small>(önizlemelerde gözükecek olan resim)</small></label>
<div class="col-sm-12"><input type="file" name="anaresim" id="anaresim" class="form-control" multiple/><br/></div></div>

<div class="form-group"><label class="control-label">Diğer Resimleri Seç</label>
<div class="col-sm-12"><input type="file" name="resim[]" id="resim[]" class="form-control" multiple/><br/></div></div>

<input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Kaydet"/>
</form><br><hr><br><?php } } ?>
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<?php if($_GET["i"]=="DEurunekle"){?>
<?php if($_POST){
$klasor="../resim";	
$baslik=mysql_real_escape_string($_POST["baslik"]);
$aciklama=mysql_real_escape_string($_POST["aciklama"]);;
$kategori=mysql_real_escape_string($_POST["kategori"]);
$altkategori=mysql_real_escape_string($_POST["altkategori"]);
$koliebat=mysql_real_escape_string($_POST["koliebat"]);
$urunebat=mysql_real_escape_string($_POST["urunebat"]);
$birimadet=mysql_real_escape_string($_POST["birimadet"]);
$urunhacim=mysql_real_escape_string($_POST["urunhacim"]);
$kolihacim=mysql_real_escape_string($_POST["kolihacim"]);
$urunagirlik=mysql_real_escape_string($_POST["urunagirlik"]);
$koliagirlik=mysql_real_escape_string($_POST["koliagirlik"]);
$kod=mysql_real_escape_string($_POST["kod"]);
$marka=mysql_real_escape_string($_POST["marka"]);
$depozito=mysql_real_escape_string($_POST["depozito"]);
$dil=mysql_real_escape_string($_POST["dil"]);
$birimfiyat=mysql_real_escape_string($_POST["birimfiyat"]);
$koliadet=mysql_real_escape_string($_POST["koliadet"]);
$para=mysql_real_escape_string($_POST["para"]);
$secim=mysql_real_escape_string($_POST["secim"]);

$anaresimurl="";
if(!empty($_FILES['anaresim']['name'])){ 
$uret=array("cu","ma","li","ya","kar");
$uzanti=substr($_FILES['anaresim']['name'],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['anaresim']['tmp_name'],$klasor."/".$yeni_ad); 
$anaresimurl="../resim/".$yeni_ad;} 

$sorguurunekle=mysql_query("INSERT INTO urun (baslik,aciklama,kategori,altkategori,urunebat,koliebat,birimadet,urunhacim,kolihacim,urunagirlik,koliagirlik,kod,depozito,marka,dil,birimfiyat,koliadet,para,secim,anaresimurl) 
VALUES('$baslik','$aciklama','$kategori','$altkategori','$urunebat','$koliebat','$birimadet','$urunhacim','$kolihacim','$urunagirlik','$koliagirlik','$kod','$depozito','$marka','$dil','$birimfiyat','$koliadet','$para','$secim','$anaresimurl')") or die(mysql_error());

$soruguurunID=mysql_query("SELECT ID FROM urun ORDER BY ID DESC LIMIT 1");
$dataID=mysql_fetch_assoc($soruguurunID);
$productid=$dataID['ID'];
try{
$values = $_POST['altkategori'];
foreach ($values as $a){
$sorgucatekle=mysql_query("INSERT INTO urunkategoriler (kategoriID,yaziID) VALUES('$a','$productid')");}
}catch(Exception $istisna){}

$dosya_isim_sayi=count($_FILES['resim']['name']); 
for($i=0;$i<$dosya_isim_sayi;$i++){ 
if(!empty($_FILES['resim']['name'][$i])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['resim']['name'][$i],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i],$klasor."/".$yeni_ad); 
$url="../resim/".$yeni_ad;
$sorgu2=mysql_query("INSERT INTO market_resimler (marketilanid,yol) VALUES('$productid','$url')"); } }
	
echo'<script language="javascript">alert("Ürün Ekleme Başarıyla Tamamlandı.");</script><script language="javascript">window.location="urunler.php?i=DEurun";</script></center>';
 }else { ?>

<form method="post" name="form1" enctype="multipart/form-data" style="padding:30px">
<input type="hidden" name="dil" value="DE">

<div class="row"><div class="col-md-3"><div class="form-group"><label> Ürün Başlığı</label>
<input type="text" class="form-control" name="baslik"> </div></div>
<div class="col-md-3"><div class="form-group"><label>Ana Kategori Seçiniz</label>
<select name="kategori"  class="form-control"  onChange="getState(this.value);"><option>Kategori Seçiniz</option>
<?php foreach ($countryResult as $country) { ?><option value="<?php echo $country["kategori_id"]; ?>">
<?php echo $country["kategori_adi"]; ?></option><?php } ?></select></div></div>

<div class="col-md-3"><div class="form-group"><label>Alt Kategori Seçiniz</label>
<select name="altkategori[]" id="state-list" class="form-control"  onChange="getDistrict(this.value);">  </select></div></div>  


<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Nerede Yayımlansın ?</label>
<select name="secim" class="form-control">
<option value="serisonu">Bitti Bitiyor</option><option value="indirimli">Aldın Aldın</option>
<option value="dusukstok">Gitti Gidiyor</option><option value="outlet">Outlet Ürünler</option><option value="anasayfa">Anasayfa</option></select></div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Ürün Ebatı</label>
<input type="text" class="form-control" name="urunebat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Hacmi</label>
<input type="text" class="form-control" name="urunhacim" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Fiyatı</label>
<input type="text" class="form-control" name="birimfiyat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Para Birimi</label>
<input type="text" class="form-control" name="para" placeholder="Örneğin :  TL , € , $"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Ağırlığı</label>
<input type="text" class="form-control" name="urunagirlik" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Depozito</label>
<input type="text" class="form-control" name="depozito" placeholder="Örneğin : 3 €"> </div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Koli Ebatı</label>
<input type="text" class="form-control" name="koliebat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Hacmi</label>
<input type="text" class="form-control" name="kolihacim" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Ağırlığı</label>
<input type="text" class="form-control" name="koliagirlik" placeholder="Sadece Rakam Yazınız"> </div></div>		
<div class="col-md-2"><div class="form-group"><label>Koli İçi Adeti / Stok</label>
<input type="text" class="form-control" name="koliadet" placeholder="Sadece Rakam Yazınız"></div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Kodu</label>
<input type="text" class="form-control" name="kod" value="<?php echo $urundata['kod'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Markası</label>
<input type="text" class="form-control" name="marka" value="<?php echo $urundata['marka'];?>"> </div></div>	
</div>

<label class="control-label">Ürün Açıklaması</label><textarea name="aciklama" id="summernote"></textarea>

<hr><div class="form-group"><label class="control-label">Ana Resim Seç <small>(önizlemelerde gözükecek olan resim)</small></label>
<div class="col-sm-12"><input type="file" name="anaresim" id="anaresim" class="form-control" multiple/><br/></div></div>

<div class="form-group"><label class="control-label">Diğer Resimleri Seç</label>
<div class="col-sm-12"><input type="file" name="resim[]" id="resim[]" class="form-control" multiple/><br/></div></div>

<input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Kaydet"/>
</form><br><hr><br><?php } } ?>
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<?php if($_GET["i"]=="ENGurunekle"){?>
<?php if($_POST){
$klasor="../resim";	
$baslik=mysql_real_escape_string($_POST["baslik"]);
$aciklama=mysql_real_escape_string($_POST["aciklama"]);;
$kategori=mysql_real_escape_string($_POST["kategori"]);
$altkategori=mysql_real_escape_string($_POST["altkategori"]);
$koliebat=mysql_real_escape_string($_POST["koliebat"]);
$urunebat=mysql_real_escape_string($_POST["urunebat"]);
$birimadet=mysql_real_escape_string($_POST["birimadet"]);
$urunhacim=mysql_real_escape_string($_POST["urunhacim"]);
$kolihacim=mysql_real_escape_string($_POST["kolihacim"]);
$urunagirlik=mysql_real_escape_string($_POST["urunagirlik"]);
$koliagirlik=mysql_real_escape_string($_POST["koliagirlik"]);
$kod=mysql_real_escape_string($_POST["kod"]);
$marka=mysql_real_escape_string($_POST["marka"]);
$depozito=mysql_real_escape_string($_POST["depozito"]);
$dil=mysql_real_escape_string($_POST["dil"]);
$birimfiyat=mysql_real_escape_string($_POST["birimfiyat"]);
$koliadet=mysql_real_escape_string($_POST["koliadet"]);
$para=mysql_real_escape_string($_POST["para"]);
$secim=mysql_real_escape_string($_POST["secim"]);

$anaresimurl="";
if(!empty($_FILES['anaresim']['name'])){ 
$uret=array("cu","ma","li","ya","kar");
$uzanti=substr($_FILES['anaresim']['name'],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['anaresim']['tmp_name'],$klasor."/".$yeni_ad); 
$anaresimurl="../resim/".$yeni_ad;} 

$sorguurunekle=mysql_query("INSERT INTO urun (baslik,aciklama,kategori,altkategori,urunebat,koliebat,birimadet,urunhacim,kolihacim,urunagirlik,koliagirlik,kod,depozito,marka,dil,birimfiyat,koliadet,para,secim,anaresimurl) 
VALUES('$baslik','$aciklama','$kategori','$altkategori','$urunebat','$koliebat','$birimadet','$urunhacim','$kolihacim','$urunagirlik','$koliagirlik','$kod','$depozito','$marka','$dil','$birimfiyat','$koliadet','$secim','$secim','$anaresimurl')") or die(mysql_error());

$soruguurunID=mysql_query("SELECT ID FROM urun ORDER BY ID DESC LIMIT 1");
$dataID=mysql_fetch_assoc($soruguurunID);
$productid=$dataID['ID'];
try{
$values = $_POST['altkategori'];
foreach ($values as $a){
$sorgucatekle=mysql_query("INSERT INTO urunkategoriler (kategoriID,yaziID) VALUES('$a','$productid')");}
}catch(Exception $istisna){}

$dosya_isim_sayi=count($_FILES['resim']['name']); 
for($i=0;$i<$dosya_isim_sayi;$i++){ 
if(!empty($_FILES['resim']['name'][$i])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['resim']['name'][$i],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i],$klasor."/".$yeni_ad); 
$url="../resim/".$yeni_ad;
$sorgu2=mysql_query("INSERT INTO market_resimler (marketilanid,yol) VALUES('$productid','$url')"); } }
	
echo'<script language="javascript">alert("Ürün Ekleme Başarıyla Tamamlandı.");</script><script language="javascript">window.location="urunler.php?i=ENGurun";</script></center>';
 }else { ?>

<form method="post" name="form1" enctype="multipart/form-data" style="padding:30px">
<input type="hidden" name="dil" value="ENG">

<div class="row"><div class="col-md-3"><div class="form-group"><label> Ürün Başlığı</label>
<input type="text" class="form-control" name="baslik"> </div></div>
<div class="col-md-3"><div class="form-group"><label>Ana Kategori Seçiniz</label>
<select name="kategori"  class="form-control"  onChange="getState(this.value);"><option>Kategori Seçiniz</option>
<?php foreach ($countryResult as $country) { ?><option value="<?php echo $country["kategori_id"]; ?>">
<?php echo $country["kategori_adi"]; ?></option><?php } ?></select></div></div>

<div class="col-md-3"><div class="form-group"><label>Alt Kategori Seçiniz</label>
<select name="altkategori[]" id="state-list" class="form-control"  onChange="getDistrict(this.value);">  </select></div></div>  


<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Nerede Yayımlansın ?</label>
<select name="secim" class="form-control">
<option value="serisonu">Bitti Bitiyor</option><option value="indirimli">Aldın Aldın</option>
<option value="dusukstok">Gitti Gidiyor</option><option value="outlet">Outlet Ürünler</option><option value="anasayfa">Anasayfa</option></select></div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Ürün Ebatı</label>
<input type="text" class="form-control" name="urunebat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Hacmi</label>
<input type="text" class="form-control" name="urunhacim" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Fiyatı</label>
<input type="text" class="form-control" name="birimfiyat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Para Birimi</label>
<input type="text" class="form-control" name="para" placeholder="Örneğin :  TL , € , $"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Ağırlığı</label>
<input type="text" class="form-control" name="urunagirlik" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Depozito</label>
<input type="text" class="form-control" name="depozito" placeholder="Örneğin : 3 €"> </div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Koli Ebatı</label>
<input type="text" class="form-control" name="koliebat" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Hacmi</label>
<input type="text" class="form-control" name="kolihacim" placeholder="Sadece Rakam Yazınız"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Ağırlığı</label>
<input type="text" class="form-control" name="koliagirlik" placeholder="Sadece Rakam Yazınız"> </div></div>		
<div class="col-md-2"><div class="form-group"><label>Koli İçi Adeti / Stok</label>
<input type="text" class="form-control" name="koliadet" placeholder="Sadece Rakam Yazınız"></div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Kodu</label>
<input type="text" class="form-control" name="kod" value="<?php echo $urundata['kod'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Markası</label>
<input type="text" class="form-control" name="marka" value="<?php echo $urundata['marka'];?>"> </div></div>	
</div>

<label class="control-label">Ürün Açıklaması</label><textarea name="aciklama" id="summernote"></textarea>

<hr><div class="form-group"><label class="control-label">Ana Resim Seç <small>(önizlemelerde gözükecek olan resim)</small></label>
<div class="col-sm-12"><input type="file" name="anaresim" id="anaresim" class="form-control" multiple/><br/></div></div>

<div class="form-group"><label class="control-label">Diğer Resimleri Seç</label>
<div class="col-sm-12"><input type="file" name="resim[]" id="resim[]" class="form-control" multiple/><br/></div></div>

<input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Kaydet"/>
</form><br><hr><br><?php } } ?>
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->



<?php if($_GET["i"]=="TRurun-duzenle"){?>
<?php if($_POST){
$klasor="../resim/";	
$idd=$_POST["idd"];
$baslik=mysql_real_escape_string($_POST["baslik"]);
$aciklama=mysql_real_escape_string($_POST["aciklama"]);;
$kategori=mysql_real_escape_string($_POST["kategori"]);
$altkategori=mysql_real_escape_string($_POST["altkategori"]);
$koliebat=mysql_real_escape_string($_POST["koliebat"]);
$urunebat=mysql_real_escape_string($_POST["urunebat"]);
$birimadet=mysql_real_escape_string($_POST["birimadet"]);
$urunhacim=mysql_real_escape_string($_POST["urunhacim"]);
$kolihacim=mysql_real_escape_string($_POST["kolihacim"]);
$urunagirlik=mysql_real_escape_string($_POST["urunagirlik"]);
$koliagirlik=mysql_real_escape_string($_POST["koliagirlik"]);
$kod=mysql_real_escape_string($_POST["kod"]);
$marka=mysql_real_escape_string($_POST["marka"]);
$depozito=mysql_real_escape_string($_POST["depozito"]);
$dil=mysql_real_escape_string($_POST["dil"]);
$birimfiyat=mysql_real_escape_string($_POST["birimfiyat"]);
$koliadet=mysql_real_escape_string($_POST["koliadet"]);
$para=mysql_real_escape_string($_POST["para"]);
$secim=mysql_real_escape_string($_POST["secim"]);

$anaresimurl="";
if(!empty($_FILES['anaresim']['name'])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['anaresim']['name'],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['anaresim']['tmp_name'],$klasor."/".$yeni_ad); 
$anaresimurl="../resim/".$yeni_ad;} 

$querystring="UPDATE urun SET baslik='$baslik',aciklama='$aciklama',
kategori='$kategori',altkategori='$altkategori',koliebat='$koliebat',urunebat='$urunebat',birimadet='$birimadet',urunhacim='$urunhacim',kolihacim='$kolihacim',urunagirlik='$urunagirlik',koliagirlik='$koliagirlik',kod='$kod',depozito='$depozito',marka='$marka',dil='$dil',birimfiyat='$birimfiyat',koliadet='$koliadet',para='$para',secim='$secim'";

if(!empty($anaresimurl)){
$querystring=$querystring.",anaresimurl='$anaresimurl'"; }

$sorguurunekle=mysql_query( $querystring." WHERE id='$idd'") or die(mysql_error());	

$sorgueskikategorisil=mysql_query("DELETE FROM urunkategoriler WHERE yaziID='$idd'");
try{
$values = $_POST['altkategori'];{
$sorgucatekle=mysql_query("INSERT INTO urunkategoriler (kategoriID,yaziID) VALUES('$altkategori','$idd')"); }
}catch(Exception $istisna){}

$dosya_isim_sayi=count($_FILES['resim']['name']); 
for($i=0;$i<$dosya_isim_sayi;$i++){ 
if(!empty($_FILES['resim']['name'][$i])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['resim']['name'][$i],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i],$klasor."/".$yeni_ad); 
$url="../resim/".$yeni_ad;
$sorgu2=mysql_query("INSERT INTO market_resimler (marketilanid,yol) VALUES('$idd','$url')"); } }

echo'<script language="javascript">alert("İşlem Başarıyla Tamamlandı.");</script><script language="javascript">window.location="urunler.php?i=TRurun";</script></center>';

}else if(!empty($_GET['id'])) {

$id=$_GET['id'];
$sorguurunozellik=mysql_query("SELECT * FROM urun WHERE id='$id' ");
$urundata=mysql_fetch_assoc($sorguurunozellik);
while($sonucurunozellik=mysql_fetch_array($sorguurunozellik)){
$baslik=$sonucurunozellik['baslik'];
$aciklama=$sonucurunozellik['aciklama'];
$kategori=$sonucurunozellik['kategori'];
$altkategori=$sonucurunozellik['altkategori'];
$koliebat=$sonucurunozellik['koliebat'];
$urunebat=$sonucurunozellik['urunebat'];
$birimadet=$sonucurunozellik['birimadet'];
$urunhacim=$sonucurunozellik['urunhacim'];
$kolihacim=$sonucurunozellik['kolihacim'];
$urunagirlik=$sonucurunozellik['urunagirlik'];
$koliagirlik=$sonucurunozellik['koliagirlik'];
$kod=$sonucurunozellik['kod'];
$depozito=$sonucurunozellik['depozito'];
$marka=$sonucurunozellik['marka'];
$birimfiyat=$sonucurunozellik['birimfiyat'];
$dil=$sonucurunozellik['dil'];
$koliadet=$sonucurunozellik['koliadet'];
$para=$sonucurunozellik['para'];
$secim=$sonucurunozellik['secim'];
 } print_r($sonucurunozellik); ?>

<form  method="post" name="form1" enctype="multipart/form-data" style="margin:30px">
<input type="hidden" name="idd" class="form-control" value="<?php echo $urundata['id'];?>">
<input type="hidden" name="dil" value="TR">

<div class="row"><div class="col-md-3"><div class="form-group"><label> Ürün Başlığı</label>
<input type="text" class="form-control" name="baslik" value="<?php echo $urundata['baslik'];?>"> </div></div>


<div class="col-md-3"><div class="form-group"><label>Ürün ANA kategorisi</label>
<?php $sorgumainkategori=mysql_query("SELECT * FROM kategoriler where kategori_ozellik='ana' and dil='TR'")  or die(mysql_error());
echo '<select name="kategori" class="form-control"> 
<option value="'.$urundata['kategori'].'" selected>'.$urundata['kategori'].'</option>';
while($sonucmainkategori=mysql_fetch_array($sorgumainkategori)){
$sorgusecililerigetir= mysql_query("Select * FROM kategoriler WHERE kategori_ozellik='ana' and dil='TR'");
$esit=0;
while($sonucsecililerigetir=mysql_fetch_array($sorgusecililerigetir)){
if($sonucsecililerigetir['kategoriID']==$sonucmainkategori['kategori_id']){
$esit=1;	} }
if($esit==1){
echo '<option value="'.$sonucmainkategori['kategori_adi'].'" selected>'.$sonucmainkategori['kategori_adi'].'</option>';	
}else echo '<option value="'.$sonucmainkategori['kategori_adi'].'">'.$sonucmainkategori['kategori_adi'].'</option>';
}echo '</select>';?></div></div>

<div class="col-md-3"><div class="form-group"><label>Ürün ALT kategorisi</label>
<?php $sorgumainkategori=mysql_query("SELECT * FROM kategoriler where kategori_ozellik='alt' and dil='TR'")  or die(mysql_error());
echo '<select name="altkategori" class="form-control">';
while($sonucmainkategori=mysql_fetch_array($sorgumainkategori)){
$sorgusecililerigetir= mysql_query("Select * FROM urunkategoriler WHERE yaziID='$id'");
$esit=0;
while($sonucsecililerigetir=mysql_fetch_array($sorgusecililerigetir)){
if($sonucsecililerigetir['kategoriID']==$sonucmainkategori['kategori_id']){
$esit=1; } }
if($esit==1) {
echo '<option selected="selected" value="'.$sonucmainkategori['kategori_id'].'" selected>'.$sonucmainkategori['kategori_adi'].'</option>';	}
else { echo '<option value="'.$sonucmainkategori['kategori_id'].'">'.$sonucmainkategori['kategori_adi'].'</option>'; } }
echo '</select>';?>		</div></div>	






<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Nerede Yayımlansın ?</label>
<select name="secim" class="form-control">
<option value="<?php echo $urundata['secim'];?>"><?php echo $urundata['secim'];?></option>
<option value="serisonu">Bitti Bitiyor</option><option value="indirimli">Aldın Aldın</option>
<option value="dusukstok">Gitti Gidiyor</option><option value="outlet">Outlet Ürünler</option><option value="anasayfa">Anasayfa</option></select></div></div>
</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Ürün Ebatı</label>
<input type="text" class="form-control" name="urunebat" value="<?php echo $urundata['urunebat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Hacmi</label>
<input type="text" class="form-control" name="urunhacim" value="<?php echo $urundata['urunhacim'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Fiyatı</label>
<input type="text" class="form-control" name="birimfiyat" value="<?php echo $urundata['birimfiyat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Para Birimi</label>
<input type="text" class="form-control" name="para" value="<?php echo $urundata['para'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Ağırlığı</label>
<input type="text" class="form-control" name="urunagirlik" value="<?php echo $urundata['urunagirlik'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Depozito</label>
<input type="text" class="form-control" name="depozito" value="<?php echo $urundata['depozito'];?>"> </div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Koli Ebatı</label>
<input type="text" class="form-control" name="koliebat" value="<?php echo $urundata['koliebat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Hacmi</label>
<input type="text" class="form-control" name="kolihacim" value="<?php echo $urundata['kolihacim'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Ağırlığı</label>
<input type="text" class="form-control" name="koliagirlik" value="<?php echo $urundata['koliagirlik'];?>"> </div></div>		
<div class="col-md-2"><div class="form-group"><label>Koli İçi Adeti / Stok</label>
<input type="text" class="form-control" name="koliadet" placeholder="Sadece Rakam Yazınız" value="<?php echo $urundata['koliadet'];?>"></div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Kodu</label>
<input type="text" class="form-control" name="kod" value="<?php echo $urundata['kod'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Markası</label>
<input type="text" class="form-control" name="marka" value="<?php echo $urundata['marka'];?>"> </div></div>	
</div>

<div class="row"><div class="col-md-12"><label style="font-weight:900">Ürün Açıklaması</label>
<textarea name="aciklama" id="summernote"><?php echo $urundata['aciklama'];?></textarea></div></div><hr>

<label style="font-weight:900">Ana Resim Seç <small>(önizlemelerde gözükecek olan resim)</small></label>
<br><img src="<?php echo $urundata['anaresimurl'];?>" style="width:100px;height:100px"/>
<input type="file" name="anaresim" id="anaresim" class="form-control"/><br/>

<div class="row"><div class="col-md-12"><label style="font-weight:900">Diğer Resimleri Seç</label>
<br><?php $sorguresimlerigetir= mysql_query("SELECT * FROM market_resimler WHERE marketilanid='$id'");
while($sonucresimlerigetir=mysql_fetch_array($sorguresimlerigetir)){
$resimurl=$sonucresimlerigetir['yol'];
$marketilanid=$sonucresimlerigetir['id'];?>

<a href="urunler.php?i=TRresimsil&id=<?php echo $marketilanid;?>"><i class="fa fa-trash" style="margin-left:80px;position:absolute;color:red;margin-top:5px"></i>
<img src="../resim/<?php echo $resimurl;?>" style="width:100px;height:100px;border:groove"/> </a>		<?php } ?>

<input type="file" name="resim[]" id="resim[]" class="form-control" multiple/></div></div><br/>

<br><input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Güncelle"/>
</form><br><br><br><?php } ?><?php }  ?>
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<?php if($_GET["i"]=="ENGurun-duzenle"){?>
<?php if($_POST){
$klasor="../resim/";	
$idd=$_POST["idd"];
$baslik=mysql_real_escape_string($_POST["baslik"]);
$aciklama=mysql_real_escape_string($_POST["aciklama"]);;
$kategori=mysql_real_escape_string($_POST["kategori"]);
$altkategori=mysql_real_escape_string($_POST["altkategori"]);
$koliebat=mysql_real_escape_string($_POST["koliebat"]);
$urunebat=mysql_real_escape_string($_POST["urunebat"]);
$birimadet=mysql_real_escape_string($_POST["birimadet"]);
$urunhacim=mysql_real_escape_string($_POST["urunhacim"]);
$kolihacim=mysql_real_escape_string($_POST["kolihacim"]);
$urunagirlik=mysql_real_escape_string($_POST["urunagirlik"]);
$koliagirlik=mysql_real_escape_string($_POST["koliagirlik"]);
$kod=mysql_real_escape_string($_POST["kod"]);
$marka=mysql_real_escape_string($_POST["marka"]);
$depozito=mysql_real_escape_string($_POST["depozito"]);
$dil=mysql_real_escape_string($_POST["dil"]);
$birimfiyat=mysql_real_escape_string($_POST["birimfiyat"]);
$koliadet=mysql_real_escape_string($_POST["koliadet"]);
$para=mysql_real_escape_string($_POST["para"]);

$anaresimurl="";
if(!empty($_FILES['anaresim']['name'])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['anaresim']['name'],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['anaresim']['tmp_name'],$klasor."/".$yeni_ad); 
$anaresimurl="../resim/".$yeni_ad;} 

$querystring="UPDATE urun SET baslik='$baslik',aciklama='$aciklama',
kategori='$kategori',koliebat='$koliebat',urunebat='$urunebat',birimadet='$birimadet',urunhacim='$urunhacim',kolihacim='$kolihacim',urunagirlik='$urunagirlik',koliagirlik='$koliagirlik',kod='$kod',depozito='$depozito',marka='$marka',dil='$dil',birimfiyat='$birimfiyat',koliadet='$koliadet',para='$para'";

if(!empty($anaresimurl)){
$querystring=$querystring.",anaresimurl='$anaresimurl'"; }

$sorguurunekle=mysql_query( $querystring." WHERE id='$idd'") or die(mysql_error());	

$sorgueskikategorisil=mysql_query("DELETE FROM urunkategoriler WHERE yaziID='$idd'");
try{
$values = $_POST['altkategori'];

foreach ($values as $a){
$sorgucatekle=mysql_query("INSERT INTO  urunkategoriler   (kategoriID,yaziID) VALUES('$a','$idd')"); }
}catch(Exception $istisna){}

$dosya_isim_sayi=count($_FILES['resim']['name']); 
for($i=0;$i<$dosya_isim_sayi;$i++){ 
if(!empty($_FILES['resim']['name'][$i])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['resim']['name'][$i],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i],$klasor."/".$yeni_ad); 
$url="../resim/".$yeni_ad;
$sorgu2=mysql_query("INSERT INTO market_resimler (marketilanid,yol) VALUES('$idd','$url')"); } }

echo'<script language="javascript">alert("İşlem Başarıyla Tamamlandı.");</script><script language="javascript">window.location="urunler.php?i=ENGurun";</script></center>';

}else if(!empty($_GET['id'])) {

$id=$_GET['id'];
$sorguurunozellik=mysql_query("SELECT * FROM urun WHERE id='$id'");
$urundata=mysql_fetch_assoc($sorguurunozellik);
while($sonucurunozellik=mysql_fetch_array($sorguurunozellik)){
$baslik=$sonucurunozellik['baslik'];
$aciklama=$sonucurunozellik['aciklama'];
$kategori=$sonucurunozellik['kategori'];
$koliebat=$sonucurunozellik['koliebat'];
$urunebat=$sonucurunozellik['urunebat'];
$birimadet=$sonucurunozellik['birimadet'];
$urunhacim=$sonucurunozellik['urunhacim'];
$kolihacim=$sonucurunozellik['kolihacim'];
$urunagirlik=$sonucurunozellik['urunagirlik'];
$koliagirlik=$sonucurunozellik['koliagirlik'];
$kod=$sonucurunozellik['kod'];
$depozito=$sonucurunozellik['depozito'];
$marka=$sonucurunozellik['marka'];
$birimfiyat=$sonucurunozellik['birimfiyat'];
$dil=$sonucurunozellik['dil'];
$koliadet=$sonucurunozellik['koliadet'];
$para=$sonucurunozellik['para'];
 } print_r($sonucurunozellik); ?>

<form  method="post" name="form1" enctype="multipart/form-data" style="margin:30px">
<input type="hidden" name="idd" class="form-control" value="<?php echo $urundata['id'];?>">
<input type="hidden" name="dil" value="ENG">


<div class="row"><div class="col-md-3"><div class="form-group"><label> Ürün Başlığı</label>
<input type="text" class="form-control" name="baslik" value="<?php echo $urundata['baslik'];?>"> </div></div>
<div class="col-md-3"><div class="form-group"><label>Ürün ANA kategorisi</label>
<?php $sorgumainkategori=mysql_query("SELECT * FROM kategoriler where kategori_ozellik='ana' and dil='TR'")  or die(mysql_error());
echo '<select name="kategori" class="form-control"> 
<option value="'.$urundata['kategori'].'" selected>'.$urundata['kategori'].'</option>';
while($sonucmainkategori=mysql_fetch_array($sorgumainkategori)){
$sorgusecililerigetir= mysql_query("Select * FROM kategoriler WHERE kategori_ozellik='ana' and dil='TR'");
$esit=0;
while($sonucsecililerigetir=mysql_fetch_array($sorgusecililerigetir)){
if($sonucsecililerigetir['kategoriID']==$sonucmainkategori['kategori_id']){
$esit=1;	} }
if($esit==1){
echo '<option value="'.$sonucmainkategori['kategori_adi'].'" selected>'.$sonucmainkategori['kategori_adi'].'</option>';	
}else echo '<option value="'.$sonucmainkategori['kategori_adi'].'">'.$sonucmainkategori['kategori_adi'].'</option>';
}echo '</select>';?></div></div>

<div class="col-md-3"><div class="form-group"><label>Ürün ALT kategorisi</label>
<?php $sorgumainkategori=mysql_query("SELECT * FROM kategoriler where kategori_ozellik='alt' and dil='TR'")  or die(mysql_error());
echo '<select name="altkategori[]" class="form-control">
<option value="'.$urundata['altkategori'].'" selected>'.$urundata['altkategori'].'</option>';
while($sonucmainkategori=mysql_fetch_array($sorgumainkategori)){
$sorgusecililerigetir= mysql_query("Select * FROM urunkategoriler WHERE ustkategoriID='$id'");
$esit=0;
while($sonucsecililerigetir=mysql_fetch_array($sorgusecililerigetir)){
if($sonucsecililerigetir['kategoriID']==$sonucmainkategori['kategori_id']){
$esit=1;	} }
if($esit==1){
echo '<option value="'.$sonucmainkategori['kategori_id'].'" selected>'.$sonucmainkategori['kategori_adi'].'</option>';	
}else echo '<option value="'.$sonucmainkategori['kategori_id'].'">'.$sonucmainkategori['kategori_adi'].'</option>';
}echo '</select>';?>		</div></div>

<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Nerede Yayımlansın ?</label>
<select name="secim" class="form-control">
<option value="<?php echo $urundata['secim'];?>"><?php echo $urundata['secim'];?></option>
<option value="serisonu">Bitti Bitiyor</option><option value="indirimli">Aldın Aldın</option>
<option value="dusukstok">Gitti Gidiyor</option><option value="outlet">Outlet Ürünler</option><option value="anasayfa">Anasayfa</option></select></div></div>
</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Ürün Ebatı</label>
<input type="text" class="form-control" name="urunebat" value="<?php echo $urundata['urunebat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Hacmi</label>
<input type="text" class="form-control" name="urunhacim" value="<?php echo $urundata['urunhacim'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Fiyatı</label>
<input type="text" class="form-control" name="birimfiyat" value="<?php echo $urundata['birimfiyat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Para Birimi</label>
<input type="text" class="form-control" name="para" value="<?php echo $urundata['para'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Ağırlığı</label>
<input type="text" class="form-control" name="urunagirlik" value="<?php echo $urundata['urunagirlik'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Depozito</label>
<input type="text" class="form-control" name="depozito" value="<?php echo $urundata['depozito'];?>"> </div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Koli Ebatı</label>
<input type="text" class="form-control" name="koliebat" value="<?php echo $urundata['koliebat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Hacmi</label>
<input type="text" class="form-control" name="kolihacim" value="<?php echo $urundata['kolihacim'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Ağırlığı</label>
<input type="text" class="form-control" name="koliagirlik" value="<?php echo $urundata['koliagirlik'];?>"> </div></div>		
<div class="col-md-2"><div class="form-group"><label>Koli İçi Adeti / Stok</label>
<input type="text" class="form-control" name="koliadet" placeholder="Sadece Rakam Yazınız" value="<?php echo $urundata['koliadet'];?>"></div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Kodu</label>
<input type="text" class="form-control" name="kod" value="<?php echo $urundata['kod'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Markası</label>
<input type="text" class="form-control" name="marka" value="<?php echo $urundata['marka'];?>"> </div></div>	
</div>
<div class="row"><div class="col-md-12"><label style="font-weight:900">Ürün Açıklaması</label>
<textarea name="aciklama" id="summernote"><?php echo $urundata['aciklama'];?></textarea></div></div><hr>

<label style="font-weight:900">Ana Resim Seç <small>(önizlemelerde gözükecek olan resim)</small></label>
<br><img src="<?php echo $urundata['anaresimurl'];?>" style="width:100px;height:100px"/>
<input type="file" name="anaresim" id="anaresim" class="form-control"/><br/>

<div class="row"><div class="col-md-12"><label style="font-weight:900">Diğer Resimleri Seç</label>
<br><?php $sorguresimlerigetir= mysql_query("SELECT * FROM market_resimler WHERE marketilanid='$id'");
while($sonucresimlerigetir=mysql_fetch_array($sorguresimlerigetir)){
$resimurl=$sonucresimlerigetir['yol'];
$marketilanid=$sonucresimlerigetir['id'];?>

<a href="urunler.php?i=ENGresimsil&id=<?php echo $marketilanid;?>"><i class="fa fa-trash" style="margin-left:80px;position:absolute;color:red;margin-top:5px"></i>
<img src="<?php echo $resimurl;?>" style="width:100px;height:100px;border:groove"/> </a>		<?php } ?>

<input type="file" name="resim[]" id="resim[]" class="form-control" multiple/></div></div><br/>

<br><input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Güncelle"/>
</form><br><br><br><?php } ?><?php }  ?>
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<?php if($_GET["i"]=="DEurun-duzenle"){?>
<?php if($_POST){
$klasor="../resim/";	
$idd=$_POST["idd"];
$baslik=mysql_real_escape_string($_POST["baslik"]);
$aciklama=mysql_real_escape_string($_POST["aciklama"]);;
$kategori=mysql_real_escape_string($_POST["kategori"]);
$altkategori=mysql_real_escape_string($_POST["altkategori"]);
$koliebat=mysql_real_escape_string($_POST["koliebat"]);
$urunebat=mysql_real_escape_string($_POST["urunebat"]);
$birimadet=mysql_real_escape_string($_POST["birimadet"]);
$urunhacim=mysql_real_escape_string($_POST["urunhacim"]);
$kolihacim=mysql_real_escape_string($_POST["kolihacim"]);
$urunagirlik=mysql_real_escape_string($_POST["urunagirlik"]);
$koliagirlik=mysql_real_escape_string($_POST["koliagirlik"]);
$kod=mysql_real_escape_string($_POST["kod"]);
$marka=mysql_real_escape_string($_POST["marka"]);
$depozito=mysql_real_escape_string($_POST["depozito"]);
$dil=mysql_real_escape_string($_POST["dil"]);
$birimfiyat=mysql_real_escape_string($_POST["birimfiyat"]);
$koliadet=mysql_real_escape_string($_POST["koliadet"]);
$para=mysql_real_escape_string($_POST["para"]);

$anaresimurl="";
if(!empty($_FILES['anaresim']['name'])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['anaresim']['name'],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['anaresim']['tmp_name'],$klasor."/".$yeni_ad); 
$anaresimurl="../resim/".$yeni_ad;} 

$querystring="UPDATE urun SET baslik='$baslik',aciklama='$aciklama',
kategori='$kategori',koliebat='$koliebat',urunebat='$urunebat',birimadet='$birimadet',urunhacim='$urunhacim',kolihacim='$kolihacim',urunagirlik='$urunagirlik',koliagirlik='$koliagirlik',kod='$kod',depozito='$depozito',marka='$marka',dil='$dil',birimfiyat='$birimfiyat',koliadet='$koliadet',para='$para'";

if(!empty($anaresimurl)){
$querystring=$querystring.",anaresimurl='$anaresimurl'"; }

$sorguurunekle=mysql_query( $querystring." WHERE id='$idd'") or die(mysql_error());	

$sorgueskikategorisil=mysql_query("DELETE FROM urunkategoriler WHERE yaziID='$idd'");
try{
$values = $_POST['altkategori'];

foreach ($values as $a){
$sorgucatekle=mysql_query("INSERT INTO  urunkategoriler   (kategoriID,yaziID) VALUES('$a','$idd')"); }
}catch(Exception $istisna){}

$dosya_isim_sayi=count($_FILES['resim']['name']); 
for($i=0;$i<$dosya_isim_sayi;$i++){ 
if(!empty($_FILES['resim']['name'][$i])){ 
$uret=array("as","rt","ty","yu","fg");
$uzanti=substr($_FILES['resim']['name'][$i],-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad=$uret[rand(0,4)].$uret[rand(0,4)].$uret[rand(0,4)].$sayi_tut.$uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i],$klasor."/".$yeni_ad); 
$url="../resim/".$yeni_ad;
$sorgu2=mysql_query("INSERT INTO market_resimler (marketilanid,yol) VALUES('$idd','$url')"); } }

echo'<script language="javascript">alert("İşlem Başarıyla Tamamlandı.");</script><script language="javascript">window.location="urunler.php?i=DEurun";</script></center>';

}else if(!empty($_GET['id'])) {

$id=$_GET['id'];
$sorguurunozellik=mysql_query("SELECT * FROM urun WHERE id='$id'");
$urundata=mysql_fetch_assoc($sorguurunozellik);
while($sonucurunozellik=mysql_fetch_array($sorguurunozellik)){
$baslik=$sonucurunozellik['baslik'];
$aciklama=$sonucurunozellik['aciklama'];
$kategori=$sonucurunozellik['kategori'];
$koliebat=$sonucurunozellik['koliebat'];
$urunebat=$sonucurunozellik['urunebat'];
$birimadet=$sonucurunozellik['birimadet'];
$urunhacim=$sonucurunozellik['urunhacim'];
$kolihacim=$sonucurunozellik['kolihacim'];
$urunagirlik=$sonucurunozellik['urunagirlik'];
$koliagirlik=$sonucurunozellik['koliagirlik'];
$kod=$sonucurunozellik['kod'];
$depozito=$sonucurunozellik['depozito'];
$marka=$sonucurunozellik['marka'];
$birimfiyat=$sonucurunozellik['birimfiyat'];
$dil=$sonucurunozellik['dil'];
$koliadet=$sonucurunozellik['koliadet'];
$para=$sonucurunozellik['para'];
 } print_r($sonucurunozellik); ?>

<form  method="post" name="form1" enctype="multipart/form-data" style="margin:30px">
<input type="hidden" name="idd" class="form-control" value="<?php echo $urundata['id'];?>">
<input type="hidden" name="dil" value="DE">

<div class="row"><div class="col-md-3"><div class="form-group"><label> Ürün Başlığı</label>
<input type="text" class="form-control" name="baslik" value="<?php echo $urundata['baslik'];?>"> </div></div>
<div class="col-md-3"><div class="form-group"><label>Ürün ANA kategorisi</label>
<?php $sorgumainkategori=mysql_query("SELECT * FROM kategoriler where kategori_ozellik='ana' and dil='TR'")  or die(mysql_error());
echo '<select name="kategori" class="form-control"> 
<option value="'.$urundata['kategori'].'" selected>'.$urundata['kategori'].'</option>';
while($sonucmainkategori=mysql_fetch_array($sorgumainkategori)){
$sorgusecililerigetir= mysql_query("Select * FROM kategoriler WHERE kategori_ozellik='ana' and dil='TR'");
$esit=0;
while($sonucsecililerigetir=mysql_fetch_array($sorgusecililerigetir)){
if($sonucsecililerigetir['kategoriID']==$sonucmainkategori['kategori_id']){
$esit=1;	} }
if($esit==1){
echo '<option value="'.$sonucmainkategori['kategori_adi'].'" selected>'.$sonucmainkategori['kategori_adi'].'</option>';	
}else echo '<option value="'.$sonucmainkategori['kategori_adi'].'">'.$sonucmainkategori['kategori_adi'].'</option>';
}echo '</select>';?></div></div>

<div class="col-md-3"><div class="form-group"><label>Ürün ALT kategorisi</label>
<?php $sorgumainkategori=mysql_query("SELECT * FROM kategoriler where kategori_ozellik='alt' and dil='TR'")  or die(mysql_error());
echo '<select name="altkategori[]" class="form-control">
<option value="'.$urundata['altkategori'].'" selected>'.$urundata['altkategori'].'</option>';
while($sonucmainkategori=mysql_fetch_array($sorgumainkategori)){
$sorgusecililerigetir= mysql_query("Select * FROM urunkategoriler WHERE ustkategoriID='$id'");
$esit=0;
while($sonucsecililerigetir=mysql_fetch_array($sorgusecililerigetir)){
if($sonucsecililerigetir['kategoriID']==$sonucmainkategori['kategori_id']){
$esit=1;	} }
if($esit==1){
echo '<option value="'.$sonucmainkategori['kategori_id'].'" selected>'.$sonucmainkategori['kategori_adi'].'</option>';	
}else echo '<option value="'.$sonucmainkategori['kategori_id'].'">'.$sonucmainkategori['kategori_adi'].'</option>';
}echo '</select>';?>		</div></div>

<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Nerede Yayımlansın ?</label>
<select name="secim" class="form-control">
<option value="<?php echo $urundata['secim'];?>"><?php echo $urundata['secim'];?></option>
<option value="serisonu">Bitti Bitiyor</option><option value="indirimli">Aldın Aldın</option>
<option value="dusukstok">Gitti Gidiyor</option><option value="outlet">Outlet Ürünler</option><option value="anasayfa">Anasayfa</option></select></div></div>
</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Ürün Ebatı</label>
<input type="text" class="form-control" name="urunebat" value="<?php echo $urundata['urunebat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Hacmi</label>
<input type="text" class="form-control" name="urunhacim" value="<?php echo $urundata['urunhacim'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label> Ürün Fiyatı</label>
<input type="text" class="form-control" name="birimfiyat" value="<?php echo $urundata['birimfiyat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Para Birimi</label>
<input type="text" class="form-control" name="para" value="<?php echo $urundata['para'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Ağırlığı</label>
<input type="text" class="form-control" name="urunagirlik" value="<?php echo $urundata['urunagirlik'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Depozito</label>
<input type="text" class="form-control" name="depozito" value="<?php echo $urundata['depozito'];?>"> </div></div>		</div>

<div class="row"><div class="col-md-2"><div class="form-group"><label>Koli Ebatı</label>
<input type="text" class="form-control" name="koliebat" value="<?php echo $urundata['koliebat'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Hacmi</label>
<input type="text" class="form-control" name="kolihacim" value="<?php echo $urundata['kolihacim'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Koli Ağırlığı</label>
<input type="text" class="form-control" name="koliagirlik" value="<?php echo $urundata['koliagirlik'];?>"> </div></div>		
<div class="col-md-2"><div class="form-group"><label>Koli İçi Adeti / Stok</label>
<input type="text" class="form-control" name="koliadet" placeholder="Sadece Rakam Yazınız" value="<?php echo $urundata['koliadet'];?>"></div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Kodu</label>
<input type="text" class="form-control" name="kod" value="<?php echo $urundata['kod'];?>"> </div></div>
<div class="col-md-2"><div class="form-group"><label>Ürün Markası</label>
<input type="text" class="form-control" name="marka" value="<?php echo $urundata['marka'];?>"> </div></div>	
</div>

<div class="row"><div class="col-md-12"><label style="font-weight:900">Ürün Açıklaması</label>
<textarea name="aciklama" id="summernote"><?php echo $urundata['aciklama'];?></textarea></div></div><hr>

<label style="font-weight:900">Ana Resim Seç <small>(önizlemelerde gözükecek olan resim)</small></label>
<br><img src="<?php echo $urundata['anaresimurl'];?>" style="width:100px;height:100px"/>
<input type="file" name="anaresim" id="anaresim" class="form-control"/><br/>

<div class="row"><div class="col-md-12"><label style="font-weight:900">Diğer Resimleri Seç</label>
<br><?php $sorguresimlerigetir= mysql_query("SELECT * FROM market_resimler WHERE marketilanid='$id'");
while($sonucresimlerigetir=mysql_fetch_array($sorguresimlerigetir)){
$resimurl=$sonucresimlerigetir['yol'];
$marketilanid=$sonucresimlerigetir['id'];?>

<a href="urunler.php?i=DEresimsil&id=<?php echo $marketilanid;?>"><i class="fa fa-trash" style="margin-left:80px;position:absolute;color:red;margin-top:5px"></i>
<img src="<?php echo $resimurl;?>" style="width:100px;height:100px;border:groove"/> </a>		<?php } ?>

<input type="file" name="resim[]" id="resim[]" class="form-control" multiple/></div></div><br/>

<br><input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Güncelle"/>
</form><br><br><br><?php } ?><?php }  ?>
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->






<script src="plugins/summernote/summernote-bs4.min.js"></script>
<script>
$(function () {
$('#summernote').summernote()
})
</script>



<?php if($_GET['i']=="TRresimsil"){
$updater = mysql_query("delete from market_resimler where id='$_GET[id]'");
echo '<script language="javascript">alert("Seçili Görsel Silindi.");</script><script language="javascript">window.location="'.$_SERVER[HTTP_REFERER].'";</script></center>'; }?>

<?php if($_GET['i']=="ENGresimsil"){
$updater = mysql_query("delete from market_resimler where id='$_GET[id]'");
echo '<script language="javascript">alert("Seçili Görsel Silindi.");</script><script language="javascript">window.location="'.$_SERVER[HTTP_REFERER].'";</script></center>'; }?>

<?php if($_GET['i']=="DEresimsil"){
$updater = mysql_query("delete from market_resimler where id='$_GET[id]'");
echo '<script language="javascript">alert("Seçili Görsel Silindi.");</script><script language="javascript">window.location="'.$_SERVER[HTTP_REFERER].'";</script></center>'; }?>
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->


<?php if($_GET['i']=="TRurunsil"){
$updater = mysql_query("delete from urun where id='$_GET[id]'");
echo '<script language="javascript">alert("İçerik Silindi.");</script><script language="javascript">window.location="'.$_SERVER[HTTP_REFERER].'";</script></center>'; }?>

<?php if($_GET['i']=="ENGurunsil"){
$updater = mysql_query("delete from urun where id='$_GET[id]'");
echo '<script language="javascript">alert("İçerik Silindi.");</script><script language="javascript">window.location="'.$_SERVER[HTTP_REFERER].'";</script></center>'; }?>


<?php if($_GET['i']=="DEurunsil"){
$updater = mysql_query("delete from urun where id='$_GET[id]'");
echo '<script language="javascript">alert("İçerik Silindi.");</script><script language="javascript">window.location="'.$_SERVER[HTTP_REFERER].'";</script></center>'; }?>

</div></div></div></section></div><?php } include('footer.php');?>


