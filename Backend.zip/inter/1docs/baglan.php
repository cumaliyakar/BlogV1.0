﻿<?php
error_reporting(E_ALL);

date_default_timezone_set("Europe/Istanbul");  
$hostname_bgl = "localhost";
$database_bgl = "u7282364_uygun";
$username_bgl = "u7282364_uygun";
$password_bgl = "TRuygunfiyatlisi1984!!";
@$bgl = mysql_connect($hostname_bgl, $username_bgl, $password_bgl) or trigger_error(mysql_error(),E_USER_ERROR); 
mysql_select_db($database_bgl, $bgl); 
mysql_query("SET NAMES UTF8");
$ip = $_SERVER['REMOTE_ADDR'];
$tarih= date("Y-m-d H:i:s");




function krctrl($ruzanti){
$degis1 = array('JPG','GIF','PNG','DOC','DOCX','XLS','XLSX','PDF');
$degis2 = array('jpg','gif','png','doc','docx','xls','xlsx','pdf');
$ruzanti = str_replace($degis1,$degis2,$ruzanti);
if($ruzanti=='jpg' || $ruzanti=='gif' || $ruzanti=='png' || $ruzanti=='doc' || $ruzanti=='docx' || $ruzanti=='xls' || $ruzanti=='xlsx' || $ruzanti=='pdf' )
{$s=1;}
else
{$s=0;}
return $s;
}
function boyutlandir($resim,$sen,$soy,$ruzanti){
$degis1 = array('JPG','GIF','PNG');
$degis2 = array('jpg','gif','png');
$ruzanti = str_replace($degis1,$degis2,$ruzanti);

ob_start();

$boyut = getimagesize($resim);
$en = $boyut[0];
$boy = $boyut[1];

if($ruzanti == "jpg"){ $eski = imagecreatefromjpeg($resim); }
if($ruzanti == "gif"){ $eski = imagecreatefromgif($resim); }
if($ruzanti == "png"){ $eski = imagecreatefrompng($resim); }

if($soy==0){$soy=($boy*$sen)/$en;}
if($sen==0){$sen=($soy*$en)/$boy;}


$yeni = imagecreatetruecolor($sen,$soy);

imagecopyresampled(
$yeni,$eski,0,0,0,0,
$sen,$soy,$en,$boy);

if($ruzanti == "jpg"){ imagejpeg($yeni,null,100); }
if($ruzanti == "gif"){ imagegif($yeni,null,100); }
if($ruzanti == "png"){ imagepng($yeni,null,100); }

$icerik = ob_get_contents();
ob_end_clean();

imagedestroy($eski);
imagedestroy($yeni);

return $icerik;}


function salla($adres){echo "<script>document.location.href='".$adres."';</script>";die;}

 

function msalla($adres,$mesaj = ''){	if ($mesaj!=''){ $msg = "alert('".$mesaj."')";	}	echo "		<script>			$msg;			document.location.href='".$adres."';		</script>	";	die;}

function nfr($s)
{
return number_format($s,2,'.',',');
}

function mesajver($mesaj){ if ($mesaj!=''){ $msg = "alert('".$mesaj."')";	}	echo "		<script>			$msg;		</script>	";}

function ctrl($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{ $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
$theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);
$theValue=htmlspecialchars($theValue);
switch ($theType) {
case "text":      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";      break;    
case "long":    case "int":      $theValue = ($theValue != "") ? intval($theValue) : "NULL";      break;
case "double":      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";      break;
case "date":      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";      break;
case "defined":      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;      break;
}
return $theValue;}



function ctrl1($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{ $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
$theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);
switch ($theType) {
case "text":      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";      break;    
case "long":    case "int":      $theValue = ($theValue != "") ? intval($theValue) : "NULL";      break;
case "double":      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";      break;
case "date":      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";      break;
case "defined":      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;      break;
}
return $theValue;}

function intk($x)
{
$ids=$x;settype($ids, "integer");
return $ids;
}

function cevir($veri)
{ 
return  mb_convert_encoding ($veri, "UTF-8", "ISO-8859-9");
}


function yukle($file,$genislik,$yukseklik,$yeri,$yeniadi,$po,$bytlndir)
{
$img = new Upload($file);
$kayitadi='';
if($yeniadi=='')
$yeniadi='p_'.time();
if ($bytlndir==true)
{
$img->file_max_size = 50000000000000000000000;
$img->image_resize            = true;
if($yukseklik==0) $img->image_ratio_y           = true;
if($genislik==0) $img->image_ratio_x           = true;

if($yukseklik>0)$img->image_y                 = $yukseklik;
if($genislik>0) $img->image_x                 = $genislik;
}
$img->file_new_name_body	  = $yeniadi;
$uzanti.$po=$img->file_src_name_ext;
if($uzanti.$po=='jpg' || $uzanti.$po=='jpeg' || $uzanti.$po=='gif' || $uzanti.$po=='png' || $uzanti.$po=='txt' || $uzanti.$po=='webp')
{		
if ($img->uploaded) {
$img->process($yeri);
if ($img->processed) {
$kayitadi=$img->file_dst_name;} 
} 
}
return $kayitadi;	
}	

function yukle1($file,$genislik,$yukseklik,$yeri,$genislik2,$yukseklik2,$yeri2,$yeniadi)
{ 
$kayitadi='';
if($yeniadi=='')$yeniadi='R_'.time();
$img = new Upload($file);
$img->file_max_size = 5000000;
$img->image_resize            = true;
if($yukseklik==0) $img->image_ratio_y           = true;
if($genislik==0) $img->image_ratio_x           = true;

if($yukseklik>0)$img->image_y                 = $yukseklik;
if($genislik>0) $img->image_x                 = $genislik;

$img->file_new_name_body	  = $yeniadi;
$uzanti=$img->file_src_name_ext;
if($uzanti=='jpg' || $uzanti=='jpeg' || $uzanti=='gif' || $uzanti=='png' || $uzanti=='txt' || $uzanti=='webp')
{		
if ($img->uploaded) {
$img->process($yeri);
if ($img->processed) {
$kayitadi=$img->file_dst_name;} 
else {echo "<script>alert('Yükleme Başarısız')</script>";}} 
else {echo "<script>alert('Yükleme Başarısız')</script>";}
if($yeri2!='')
{
$img->file_max_size = 5000000;
$img->image_resize            = true;
if($yukseklik2==0) $img->image_ratio_y           = true;
if($genislik2==0) $img->image_ratio_x           = true;

if($yukseklik2>0)$img->image_y                 = $yukseklik2;
if($genislik2>0) $img->image_x                 = $genislik2;

$img->file_new_name_body	  = $yeniadi;

if ($img->uploaded) {
$img->process($yeri2);
if ($img->processed) {} 
else {echo "<script>alert('Yükleme Başarısız')</script>";}} 
else {echo "<script>alert('Yükleme Başarısız')</script>";}
}

}else {echo "<script>alert('Sadece jpg, jpeg, gif, png,txt,webpb Resim Formatlary Yüklenebilir')</script>";}
return $kayitadi;	
}

function seoyap( $s )
{
$turkce=array("s","S","i","(",")","'","ü","Ü","ö","Ö","ç","Ç"," ","/","*","?","s","S","i","g","G","I","ö","Ö","Ç","ç","ü","Ü");
$duzgun=array("s","S","i","","","","u","U","o","O","c","C","_","-","-","","s","S","i","g","G","I","o","O","C","c","u","U");
$s = str_replace($tr,$eng,$s);
$s = @eregi_replace('[^0-9A-Za-z]',"-",$s);
for($i=0;$i <= 5;$i++) { $s = str_replace("--","-",$s); }
return strtolower($s);
}



function AntiSQL($input) {
$search = array(
'@<script[^>]*?>.*?</script>@si', // Strip out javascript
'@<[\/\!]*?[^<>]*?>@si', // Strip out HTML tags
'@<style[^>]*?>.*?</style>@siU', // Strip style tags properly
'@<![\s\S]*?--[ \t\n\r]*>@' // Strip multi-line comments
);

$output = preg_replace($search, '', $input);
return $output; }?>