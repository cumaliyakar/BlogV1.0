<?php
session_start();
include('../baglan.php');
if (isset($_POST['login'])) {
    if (bosmu($_POST) == true && filter($_POST) == true) {
        $login = read("SELECT * FROM ayarlar Where email =? and password =?", 0, [$_POST['email'], $_POST['password']]);
        if ($login[0] > 0) {
            $_SESSION['Yonetici'] = $_POST['email'];
            header("Location:anasayfa.php");
        } else {
            header("Location:index.php?q=danger");
        }
    } else {
        header("Location:index.php?q=warning");
    }
}


if(isset($_POST['islem'])){
    if($_POST['islem']=="ozellikgetir"){
        $id = $_POST["ID"];
        $sorguurunozellik=read("select * from varyasyonozellik WHERE varyasyon_id='$id'", 1, []);
        $dizi = [];
        foreach ($sorguurunozellik[1] as $sonucurunozellik){
            array_push( $dizi,$sonucurunozellik);
        }

       echo json_encode($dizi);
    }else if($_POST['islem']=="kaydet"){ $sayi =0;
       // print_r($_POST);
        foreach($_POST as $key=> $post){
            if($key!="kaydet"&&$key!="fiyat"&&$key!="stok"&&$key!="urunid"&&$post!="kaydet"&&$post!="indirim"&&$key!="indirim"){
                           
           //     echo $sayi;
                $sayi++;
        }
        }


        if($sayi==1){
            foreach($_POST as $key=> $post){
                $fiyat = $_POST['fiyat'];
                $stok = $_POST['stok'];
                $urunid = $_POST['urunid'];
                $iskonto = $_POST['indirim'];

                if($key!="kaydet"&&$key!="fiyat"&&$key!="stok"&&$key!="urunid"&&$post!="kaydet"&&$post!="indirim"&&$key!="indirim"){
                    
                        $sorguekle=read("INSERT INTO urunstok (urunid,varyasyonbir,fiyat,stok,iskonto) values ('$urunid','$post','$fiyat','$stok','$iskonto')", 1, []);
                        
                }
            }
        }else if($sayi==2){
            $fiyat = $_POST['fiyat'];
            $stok = $_POST['stok'];
            $urunid = $_POST['urunid'];
            $iskonto = $_POST['indirim'];

            $dizi = [];

            foreach($_POST as $key=> $post){
                if($key!="kaydet"&&$key!="fiyat"&&$key!="stok"&&$key!="urunid"&&$post!="kaydet"&&$post!="indirim"&&$key!="indirim"){
                    array_push($dizi, $post);
            }

            }
                $sorguekle=read("INSERT INTO urunstok (urunid,varyasyonbir,v2,fiyat,stok,iskonto) values ('$urunid','".$dizi[0]."','".$dizi[1]."','$fiyat','$stok','$iskonto')", 1, []);
                

        }else if($sayi==3){
            $fiyat = $_POST['fiyat'];
            $stok = $_POST['stok'];
            $urunid = $_POST['urunid'];
            $iskonto = $_POST['indirim'];

            $dizi = [];

            foreach($_POST as $key=> $post){
                if($key!="kaydet"&&$key!="fiyat"&&$key!="stok"&&$key!="urunid"&&$post!="kaydet"&&$post!="indirim"&&$key!="indirim"){
                    array_push($dizi, $post);
            }

            }
                $sorguekle=read("INSERT INTO urunstok (urunid,varyasyonbir,v2,v3,fiyat,stok,iskonto) values ('$urunid','".$dizi[0]."','".$dizi[1]."','".$dizi[2]."','$fiyat','$stok','$iskonto')", 1, []);
                

        }

        



    }else if($_POST['islem']=="varyantType"){
        $id = $_POST["urunid"];
        $v1 = $_POST["v1"];
        $v2 = $_POST["v2"];
        $v3 = $_POST["v3"];
        $val = $_POST['val'];
        if($val==1){
            $temizle=read("DELETE FROM urunstok Where urunid='$id'", 1, []);
            $sorguekle=read("INSERT INTO varyanttype (urunid,v1) values ('$id','$v1')", 1, []);
        }else if($val==2){
            $temizle=read("DELETE FROM urunstok Where urunid='$id'", 1, []);
            $sorguekle=read("INSERT INTO varyanttype (urunid,v1,v2) values ('$id','$v1','$v2')", 1, []);
        }else if($val==3){
            $temizle=read("DELETE FROM urunstok Where urunid='$id'", 1, []);
            $sorguekle=read("INSERT INTO varyanttype (urunid,v1,v2,v3) values ('$id','$v1','$v2','$v3')", 1, []);
        }
    }else if($_POST['islem']=="dataGetir"){
        $id = $_POST["ID"]; ?>

<div>
<?php 

$UrunSorgu          = $db->prepare("SELECT * FROM urunstok WHERE urunid=?");
$UrunSorgu->execute([$id]);
$Kontrol            = $UrunSorgu->rowCount();
$Kayit              = $UrunSorgu->FetchAll(PDO::FETCH_ASSOC);


foreach($Kayit as $data){ echo '<tr class="middle">';
    if($data['varyasyonbir']!=null){
    
        $UrunSorgu1          = $db->prepare("SELECT * FROM varyasyonozellik inner join varyasyonlar on varyasyonlar.id   = varyasyonozellik.varyasyon_id WHERE varyasyonozellik.id=? LIMIT 1");
        $UrunSorgu1->execute([$data['varyasyonbir']]);
        $Kontrol1            = $UrunSorgu1->rowCount();
        $Kayit1              = $UrunSorgu1->Fetch(PDO::FETCH_ASSOC); ?>

        <td><?php echo $Kayit1['ozellik_adi'] ?> <?php echo $Kayit1['varyasyon_adi'] ?></td>

   <?php }else{
       echo '<td></td>';
   }
   

if($data['v2']!=null){
    $UrunSorgu1          = $db->prepare("SELECT * FROM varyasyonozellik inner join varyasyonlar on varyasyonlar.id = varyasyonozellik.varyasyon_id WHERE varyasyonozellik.id=? LIMIT 1");
    $UrunSorgu1->execute([$data['v2']]);
    $Kontrol1            = $UrunSorgu1->rowCount();
    $Kayit1              = $UrunSorgu1->Fetch(PDO::FETCH_ASSOC); ?>

    <td><?php echo $Kayit1['ozellik_adi'] ?> <?php echo $Kayit1['varyasyon_adi'] ?></td>

<?php }else{
       echo '<td></td>';
   }
if($data['v3']!=null){
    $UrunSorgu1          = $db->prepare("SELECT * FROM varyasyonozellik inner join varyasyonlar on varyasyonlar.id = varyasyonozellik.varyasyon_id WHERE varyasyonozellik.id=? LIMIT 1");
    $UrunSorgu1->execute([$data['v3']]);
    $Kontrol1            = $UrunSorgu1->rowCount();
    $Kayit1              = $UrunSorgu1->Fetch(PDO::FETCH_ASSOC); ?>

    <td><?php echo $Kayit1['ozellik_adi'] ?> <?php echo $Kayit1['varyasyon_adi'] ?></td>

<?php }else{
       echo '<td></td>';
   } ?>
    <td>% <?php echo $data['iskonto'] ?> İndirimli</td>
    <td><?php echo $data['fiyat'] ?> TL</td>
    <td><?php echo $data['stok'] ?> Adet</td>
    <td style="width:20%">
    <button type="button" onclick="updateVariant('<?php echo $data['id'] ?>')" class="btn btn-info"><i class="fa fa-edit"></i></button>  
    <button type="button" onclick="deleteVariant('<?php echo $id ?>','<?php echo $data['id'] ?>')" class="btn btn-danger">X</button>
   
</td>
    </tr>
    <?php
}

    






?>



   <?php     
    }else if($_POST['islem']=="temizle"){
        $id = $_POST["urunid"];
        
        $temizle=read("DELETE FROM urunstok Where urunid='$id'", 1, []);
        $temizle=read("DELETE FROM varyantType Where urunid='$id'", 1, []);
        exit;
        
    }else if($_POST['islem']=="stokkaydet"){
        $id = $_POST["urunid"];
        $stok = $_POST["stok"];
        $fiyat = $_POST["fiyat"];
        $iskonto = $_POST["indirim"];
        
$kaydet = read("INSERT INTO urunstok (urunid,stok,fiyat,iskonto) 
VALUES('$id','$stok','$fiyat','$iskonto')", 1, []);


        exit;
        
    }else if($_POST['islem']=="deleteVariant"){
        $id = $_POST["ID"];
        $sorguurunozellik=read("DELETE FROM urunstok Where id = '$id'", 1, []);
    }

    
}

exit();
