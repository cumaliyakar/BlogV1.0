<?php if ($durum) { ?>


<aside class="main-sidebar sidebar-dark-primary elevation-4">
<center><a href="anasayfa.php" class="brand-link"><span class="brand-text" style="font-weight:900">YÖNETİM PANELİ</span></a></center>
<div class="sidebar">
<nav class="mt-2"><ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
<!----------------------------------------------------------------------------------------------------------------------->

<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item menu-open"><a href="anasayfa.php" class="nav-link active"><i class="nav-icon fas fa-tachometer-alt"></i><p>Panel Anasayfa</p></a></li>
<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><a href="#" class="nav-link"><i class="nav-icon fas fa-tags"></i><p>Blog Yönetimi<i class="right fas fa-angle-left"></i></p></a>
<ul class="nav nav-treeview">
<li class="row nav-item" style="margin-left:30px"><p><a href="blog.php?i=blog" class="link"><i class="fas fa-bars nav-icon"></i>Blog Listesi</a></li>

<li class="row nav-item" style="margin-left:30px"><a href="blog.php?i=blogekle" ><i class="fa fa-plus nav-icon"></i>&nbsp;Blog Ekle</a></li>						</ul>
<!---------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><a href="#" class="nav-link"><i class="nav-icon fas fa-bars"></i><p>Kategori Yönetimi<i class="right fas fa-angle-left"></i></p></a>
<ul class="nav nav-treeview">
<li class="nav-item" style="margin-left:30px"><p><a href="kategori.php?i=katust" class="link"><i class="fas fa-bars nav-icon"></i>Ana Kategori Liste </a></p></li>
<li class="nav-item" style="margin-left:30px"><p><a href="kategori.php?i=katustekle" class="link"><i class="fa fa-plus nav-icon"> </i>Üst Kategori Ekle </a></p></li>

<li class="nav-item" style="margin-left:30px"><p><a href="kategori.php?i=katalt" class="link"><i class="fas fa-bars nav-icon"></i>Alt Kategori Liste </a></p></li>
<li class="nav-item" style="margin-left:30px"><p><a href="kategori.php?i=kataltekle" class="link"><i class="fa fa-plus nav-icon"> </i>Alt Kategori Ekle </a></p></li>  		

</ul></li>
<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><a href="#" class="nav-link"><i class="nav-icon fas fa-users"></i><p>Kullanıcı Yönetimi<i class="right fas fa-angle-left"></i></p></a>
<ul class="nav nav-treeview">
<li class="nav-item" style="margin-left:30px"><p><a href="kullanici-liste.php?i=TRkullanici" class="link"><i class="fas fa-bars nav-icon"></i>Kullanıcı Listesi</a> </p></li>
<li class="nav-item" style="margin-left:30px"><p><a href="kullanici-liste.php?i=TRkullaniciekle" class="link"><i class="fa fa-plus nav-icon"></i>Kullanıcı Ekle +</a></p></li></ul></li>
<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><a href="#" class="nav-link"><i class="nav-icon fas fa-newspaper"></i><p>Sayfalar Yönetimi<i class="right fas fa-angle-left"></i></p></a>
<ul class="nav nav-treeview">
<li class="nav-item" style="margin-left:30px"><p><a href="sayfa.php?i=sayfahepsi" class="link"><i class="fas fa-bars nav-icon"></i>Sayfa Listesi</a> </p></li>
<li class="nav-item" style="margin-left:30px"><p><a href="sayfa.php?i=sayfaekle" class="link"><i class="fa fa-plus nav-icon"></i>Sayfa Ekle +</a></p></li></ul></li>
<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><a href="abone.php?i=TRabone" class="nav-link"><i class="nav-icon fas fa-thumbs-up"> </i>
<p>E-Abone Yönetimi<i class="right fas fa-angle-left"></i></p></a></li>
<!------------------------------------------------------------------------------------------------------------->
<!------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><a href="yorum.php?i=yorumhepsi" class="nav-link"><i class="nav-icon fas fa-comments"> </i>
<p>Yorum Yönetimi<i class="right fas fa-angle-left"></i></p></a></li>
<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><a href="mesaj.php?i=TRmesaj" class="nav-link"><i class="nav-icon fas fa-envelope"> </i>
<p>Mesaj Yönetimi<i class="right fas fa-angle-left"></i></p></a></li>
<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><a href="#" class="nav-link"><i class="nav-icon fas fa-images"></i><p>Reklam Yönetimi<i class="right fas fa-angle-left"></i></p></a>
<ul class="nav nav-treeview">
<li class="nav-item" style="margin-left:30px"><p><a href="reklam.php?i=reklam" class="link"><i class="fas fa-bars nav-icon"></i>Reklam Listesi </a></p> </li>
<li class="nav-item" style="margin-left:30px"><p><a href="reklam.php?i=reklamekle" class="link"><i class="fa fa-plus nav-icon"></i>Reklam Ekle </a></p></li>		 </ul></li>
<!----------------------------------------------------------------------------------------------------------------------->
<li class="nav-item"><?php $urundata = $durum ?><a href="ayarlar.php?i=ayarlar&id=<?php echo $urundata['id']; ?>" class="nav-link"><i class="nav-icon fas fa-wrench"> </i>
<p>Site Ayarları<i class="right fas fa-angle-left"></i></p></a></li> <!------------------------------------------------------------------------------------------------------------->
<hr><li class="nav-item"><center style="color:#fff">Web Yazılım Destek</center>
<a href="https://interaktifhizmetler.com" target="_blank"><img src="../logo/interaktif.jpg" style="height:120px;width:100%;"></a></li>

</ul></nav></div></aside><?php }?>
