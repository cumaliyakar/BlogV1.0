<?php 

use Phppot\CountryState;

include('header.php');
$durum =  $ayarSorgu[1]; ?>

<div class="content-wrapper">


<div class="content-header"><div class="container-fluid"><div class="row mb-2"><div class="col-sm-3"><h1 class="m-0">Kayıtlı Blog Listesi</h1></div><div class="col-sm-9"><ol class="breadcrumb float-sm-right"><li class="breadcrumb-item"><a href="blog.php?i=blogekle" class="btn btn-success">Yeni Blog Ekle +</a></li></ol></div></div></div></div>


<section class="content"><div class="row"><div class="col-md-12"><div class="card card-primary card-outline">

<?php if ($_GET["i"] == "blog") { ?>

<div class="card-body"><table id="example1" class="table table-bordered table-striped"><thead><tr>
<th style="width:1%">#</th><th style="width:7%">Görsel</th><th>Başlık</th><th>Durum</th><th>Yazar</th><th>Yorum</th><th>Hit</th><th>İşlem</th>
</tr></thead><tbody>
<?php $p = 1;
if (empty($_GET['p'])) $p = 1;
else $p = $_GET['p'];
$maximum = 100;
$limitbasla = ($p - 1) * $maximum;
$limitbitir = $maximum;
$sorguurunler = read("SELECT * FROM blog ORDER BY id asc LIMIT $limitbasla,$limitbitir", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) {  ?>       <tr>
<td><?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $sonucurunler['id'] . "' order by id desc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?><?php echo $sonucurunler['id'] ?></td>
<td><div class="w3-dropdown-hover">
<img src="../logo/<?php echo $resimurl; ?>" alt="<?php echo $sonucurunler['baslik'] ?>" style="width:84px;height:42px">
<div class="w3-dropdown-content" style="width:300px"><br>
<img src="../logo/<?php echo $resimurl; ?>" alt="<?php echo $sonucurunler['baslik'] ?>" style="width:100%;height:250px">
</div></div><?php } ?></td>

<td><?php echo $sonucurunler['baslik'] ?></td>
<td><?php echo $sonucurunler['durum'] ?></td>
<td><?php echo $sonucurunler['uyeID'] ?></td>
<td>0</td>
<td><?php echo $sonucurunler['okunma'] ?></td>

<td style="width:10%"><a class="btn btn-info" href="blog.php?i=blog-duzenle&id=<?php echo $sonucurunler['id'] ?>"><i class="fa fa-edit"></i></a><a class="btn btn-danger" href="blog.php?i=blogsil&id=<?php echo $sonucurunler['id'] ?>"><i class="fa fa-trash-alt"></i></a></td></tr><?php } ?></tbody></table></div></div></div></div>

<div class="card-footer p-0"><div class="mailbox-controls"><div class="float-right"><div class="card-tools"><ul class="pagination pagination-sm">
<?php $sorgukategoriurunsayisi = read("SELECT COUNT(id) as sayi FROM blog", 1, []);
$sayi = 0;
foreach ($sorgukategoriurunsayisi[1] as $sonuckategoriurunsayisi) {
$sayi = $sonuckategoriurunsayisi['sayi']; }
if ($sayi > $maximum)
$sayi = $sayi / $maximum + 1;
else $sayi = 0;
for ($j = 1; $j < $sayi; $j++) {
if ($p == $j) {
echo '<li class="page-item"><a class="page-link" href="blog.php?i=blog&id=' . $id . '&p=' . $j . '">' . $j . '</a></li>';
} else {
echo '<li class="page-item"><a class="page-link" href="blog.php?i=blog&id=' . $id . '&p=' . $j . '">' . $j . '</a></li>';}} ?>
</ul></div></div></div></div><?php } ?>
<!----------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------->
<?php require_once __DIR__ . '/anakategori.php';
$countryState = new CountryState();
$countryResult = $countryState->getAllCountry();?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" type="text/javascript"></script>

<script>
function getState(val) {
$("#loader").show();
$.ajax({
type: "POST",
url: "altkategori.php",
data:'ana_key='+val,
success: function(data){
$("#alt-list").html(data);
$("#loader").hide();
}
});
}
</script>
<!--------------------------------------------------------------------------------------------------------------->

<script src="plugins/jquery/jquery.min.js"></script>
<script>
$(function() {
$("#example1").DataTable({
"responsive": true,
"lengthChange": true,
"autoWidth": true,
"buttons": ["copy", "csv", "excel", "pdf", "print"]
}).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
});
</script>
<script src="plugins/datatables-buttons/buttons.flash.min.js"></script>



<?php if ($_GET["i"] == "blogekle") { ?>

<?php if ($_POST) {
$klasor = "../logo";
$baslik = $_POST["baslik"];
$aciklama = $_POST["aciklama"];
$anakategori = $_POST["anakategori"];
$altkategori = $_POST["altkategori"];
$durum = $_POST["durum"];
$uyeID = $_POST["uyeID"];
$onecikan = $_POST["onecikan"];
$tarih = $_POST["tarih"];

$sorguurunekle = read("INSERT INTO blog (baslik,aciklama,anakategori,altkategori,durum,uyeID,onecikan,tarih)

VALUES('$baslik','$aciklama','$anakategori','$altkategori','$durum','$uyeID','$onecikan','$tarih')", 1, []);

$soruguurunID = read("SELECT ID FROM blog ORDER BY ID DESC LIMIT 1", 1, []);
foreach ($soruguurunID[1] as $dataID)
$productid = $dataID['ID'];

$dosya_isim_sayi = count($_FILES['resim']['name']);
for ($i = 0; $i < $dosya_isim_sayi; $i++) {
if (!empty($_FILES['resim']['name'][$i])) {
$uret = array("as", "rt", "ty", "yu", "fg");
$uzanti = substr($_FILES['resim']['name'][$i], -4, 4);
$sayi_tut = rand(1, 10000);
$yeni_ad = $uret[rand(0, 4)] . $uret[rand(0, 4)] . $uret[rand(0, 4)] . $sayi_tut . $uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i], $klasor . "/" . $yeni_ad);
$url = "../logo/" . $yeni_ad;
$urunKaydet = read("INSERT INTO resimler (marketilanid,yol) VALUES('$productid','$url')", 1, []);}}

echo '<div class="alert alert-dismissible alert-success">
<button type="button" class="close" data-dismiss="alert"><i class="fa fa-remove"></i></button>
Blog Ekleme Başarıyla Tamamlandı <a href="blog.php?i=blog" class="alert-link">Geri Dön</a>.</div>';
} else { ?>

<form method="post" name="form1" enctype="multipart/form-data" style="padding:30px">
<input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>">
<div class="row"><div class="col-md-12"><div class="form-group"><label style="font-weight:900"> Blog Başlığı</label>
<input type="text" class="form-control" name="baslik"></div></div> </div>

<div class="row"><div class="col-md-2"><div class="form-group"><label style="font-weight:900">Yayınlayan Üye</label>
<select name="uyeID" class="form-control">
<option value="Admin" selected>Admin</option>
<?php $sorguurunler = read("SELECT * FROM uyeler order by id desc", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?>    
<option value="<?php echo $sonucurunler['uyeID'] ?>"><?php echo $sonucurunler['adsoyad'] ?></option>
<?php }?></select></div></div> 

<div class="col-md-2"><div class="form-group"><label style="font-weight:900">Yayın Durumu</label>
<select name="durum" class="form-control">
<option value="Aktif">Aktif</option>
<option value="Pasif">Pasif</option></select></div></div>   

<div class="col-md-2"><div class="form-group"><label style="font-weight:900">Öne Çıkan Durumu</label>
<select name="onecikan" class="form-control">
<option value="Hayır">Hayır</option>
<option value="Evet">Evet</option></select></div></div> 

<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Ana Kategorisi </label>
<select name="anakategori" class="form-control" onChange="getState(this.value);"><option>Ana Kategori Seçiniz</option>
<?php foreach ($countryResult as $country) { ?>
<option value="<?php echo $country["ana_key"]; ?>"><?php echo $country["ana_title"]; ?></option><?php } ?></select></div></div> 

<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Alt Kategorisi </label>
<select name="altkategori" id="alt-list" class="form-control"  onChange="getDistrict(this.value);"></select></div></div> 
</div>

<div class="col-md-12"><div class="form-group"><label style="font-weight:900">Blog Açıklaması</label>
<textarea name="aciklama" id="summernote"></textarea></div></div>

<hr><div class="row"><div class="col-md-6"><div class="form-group"><label style="font-weight:900">Resimleri Seç</label>
<input type="file" name="resim[]" id="resim[]" class="form-control" multiple /><br /></div></div>

<div class="col-md-6"><div class="form-group"><br><input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Kaydet" /></div></div>

</div></form><br><hr><br><?php }} ?>
<!----------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<?php if ($_GET["i"] == "blog-duzenle") { ?>
<?php if ($_POST) {

$klasor = "../logo/";
$idd = $_POST["idd"];

$baslik = $_POST["baslik"];
$aciklama = $_POST["aciklama"];
$ana_key = $_POST["anakategori"];
$alt_key = $_POST["altkategori"];
$durum = $_POST["durum"];
$uyeID = $_POST["uyeID"];
$onecikan = $_POST["onecikan"];
$tarih = $_POST["tarih"];

$sorguurunler = read("UPDATE blog SET baslik='$baslik',aciklama='$aciklama',anakategori='$ana_key',altkategori='$alt_key',durum='$durum',uyeID='$uyeID',onecikan='$onecikan',tarih='$tarih' WHERE id='$idd'", 1, []);

$dosya_isim_sayi = count($_FILES['resim']['name']);
for ($i = 0; $i < $dosya_isim_sayi; $i++) {
if (!empty($_FILES['resim']['name'][$i])) {
$uret = array("as", "rt", "ty", "yu", "fg");
$uzanti = substr($_FILES['resim']['name'][$i], -4, 4);
$sayi_tut = rand(1, 10000);
$yeni_ad = $uret[rand(0, 4)] . $uret[rand(0, 4)] . $uret[rand(0, 4)] . $sayi_tut . $uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i], $klasor . "/" . $yeni_ad);
$url = "../logo/" . $yeni_ad;
$sorgu2 = read("INSERT INTO resimler (marketilanid,yol) VALUES('$idd','$url')", 1, []);
}
}

echo '<div class="alert alert-dismissible alert-success">
<button type="button" class="close" data-dismiss="alert"><i class="fa fa-remove"></i></button>
<strong>Tamamlandı!.</strong> İşlem Başarıyla Tamamlandı <a href="blog.php?i=blog" class="alert-link">Geri Dön</a>.</div>';
} else if (!empty($_GET['id'])) {

$id = $_GET['id'];
$sorguurunozellik = read("SELECT * FROM blog WHERE id='$id'", 1, []);
foreach ($sorguurunozellik[1] as $urundata);?>


<form method="post" name="form1" enctype="multipart/form-data" style="margin:20px">
<input type="hidden" name="idd" class="form-control" value="<?php echo $urundata['id']; ?>">
<input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>">
<div class="row"><div class="col-md-12"><div class="form-group"><label style="font-weight:900"> Blog Başlığı</label>
<input type="text" class="form-control" name="baslik" value="<?php echo $urundata['baslik']; ?>"></div></div></div>

<div class="row"><div class="col-md-2"><div class="form-group"><label style="font-weight:900">Yayınlayan Üye</label>
<select name="uyeID" class="form-control">
<option value="<?php echo $urundata['uyeID']; ?>" selected><?php echo $urundata['uyeID']; ?></option>
<?php $sorguurunler = read("SELECT * FROM uyeler", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?>    
<option value="<?php echo $urundata['uyeID'] ?>"><?php echo $sonucurunler['adsoyad'] ?></option>
<?php }?></select></div></div> 

<div class="col-md-2"><div class="form-group"><label style="font-weight:900">Öne Çıkan Durumu</label>
<select name="onecikan" class="form-control">
<option value="<?php echo $urundata['onecikan']; ?>" selected><?php echo $urundata['onecikan']; ?></option>
<option value="Hayır">Hayır</option>
<option value="Evet">Evet</option></select></div></div> 

<div class="col-md-2"><div class="form-group"><label style="font-weight:900">Yayın Durumu ?</label>
<select name="durum" class="form-control">
<option value="<?php echo $urundata['durum']; ?>" selected><?php echo $urundata['durum']; ?></option>
<option value="Aktif">Aktif</option>
<option value="Pasif">Pasif</option></select></div></div>         


<?php
$v1sorgu          = $db->prepare("SELECT * FROM anakategori inner join blog on blog.anakategori = anakategori.ana_id  WHERE blog.anakategori=? LIMIT 1");
$v1sorgu->execute([$urundata['anakategori']]);
$v1Kontrol            = $v1sorgu->rowCount();
$v1Kayit              = $v1sorgu->Fetch(PDO::FETCH_ASSOC);

$v2sorgu          = $db->prepare("SELECT * FROM altkategori inner join blog on blog.altkategori = altkategori.alt_id  WHERE blog.altkategori=? LIMIT 1");
$v2sorgu->execute([$urundata['altkategori']]);
$v2Kontrol            = $v2sorgu->rowCount();
$v2Kayit              = $v2sorgu->Fetch(PDO::FETCH_ASSOC); ?>

<div class="col-md-3"><div class="form-group"><label>Blog ANA kategorisi</label>
<select name="anakategori" class="form-control" onChange="getState(this.value);">
<option value="<?php echo $v1Kayit['ana_id'];?>"><?php echo $v1Kayit['ana_title'];?></option>
<?php foreach ($countryResult as $country) { ?>
<option value="<?php echo $country["ana_key"]; ?>"><?php echo $country["ana_title"]; ?></option>	<?php } ?></select></div></div>

<div class="col-md-3"><div class="form-group"><label>Blog ALT kategorisi</label>
<select name="altkategori" id="alt-list" class="form-control"  onChange="getDistrict(this.value);">
<option value="<?php echo $v2Kayit['alt_id'] ?>"><?php echo $v2Kayit['alt_title'];?></option>
<?php foreach ($countryResult as $country) { ?>
<option value="<?php echo $country["alt_key"]; ?>">
<?php echo $country["alt_title"]; ?></option><?php } ?>		</select></div></div>        </div>


<div class="row"><div class="col-md-12"><label style="font-weight:900">Blog Açıklaması</label>
<textarea name="aciklama" id="summernote"><?php echo $urundata['aciklama']; ?></textarea></div></div><hr>

<div class="row"><div class="col-md-12"><label style="font-weight:900">Resimleri Seç</label><br>
<?php $sorguresimlerigetir = read("SELECT * FROM resimler WHERE marketilanid='$id'", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol'];
$marketilanid = $sonucresimlerigetir['id']; ?>
<a href="blog.php?i=resimsil&id=<?php echo $marketilanid; ?>"><i class="fa fa-trash fa-2x" style="margin-left:80px;position:absolute;color:red;margin-top:5px"></i>
<img src="../logo/<?php echo $resimurl; ?>" style="width:100px;height:100px;border:groove" /> </a> <?php } ?></div></div>

<div class="row"><div class="col-md-6"><input type="file" name="resim[]" id="resim[]" class="form-control" multiple /></div><br />

<div class="col-md-6"><input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Güncelle" /></div></div>
</form><br><br><br><?php } ?></div><?php }  ?></div>
<!---->
<!---->
<!---->
<!---->
<!---->
<!---->
<!---->
<!---->
<!---->
<!---->
<!---->
<!---->
<!------->

<script src="plugins/summernote/summernote-bs4.min.js"></script>
<script>
$(function() {
$('#summernote').summernote()
});
</script>



</div>




<?php if ($_GET['i'] == "resimsil") {
$updater = read("delete from resimler where id='$_GET[id]'", 1, []);
echo '<script language="javascript">alert("Seçili Görsel Silindi.");</script><script language="javascript">window.location="' . $_SERVER['HTTP_REFERER'] . '";</script></center>';} ?>


<?php if ($_GET['i'] == "blogsil") {
$updater = read("delete from blog where id='$_GET[id]'", 1, []);
echo '<script language="javascript">alert("İçerik Silindi.");</script><script language="javascript">window.location="' . $_SERVER['HTTP_REFERER'] . '";</script></center>';} ?>


</div></div></div></section></div><?php include('footer.php'); ?>