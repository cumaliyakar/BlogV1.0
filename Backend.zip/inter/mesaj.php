<?php
include('header.php');
$durum =  $ayarSorgu[1];
?>

<div class="content-wrapper"><section class="content"><div class="row">

<div class="col-md-12"><div class="card card-primary card-outline">


<?php if ($_GET["i"] == "TRmesaj") {; ?><div class="content-header">
<div class="container-fluid">
<div class="row mb-2">
<div class="col-sm-6">
<h1 class="m-0">Gelen Mesajlar</h1>
</div>
<div class="col-sm-6">
<ol class="breadcrumb float-sm-right">
<li class="breadcrumb-item"><a href="anasayfa.php">Anasayfa</a></li>
</ol>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-body">
<table class="table table-bordered table-hover">
<thead>
<tr>
<th>ID</th>
<th>E-Mail</th>
<th>Ad / Soyad</th>
<th>Telefon</th>
<th>Tarih</th>
<th>işlem</th>
</tr>
</thead>
<tbody>
<?php $p = 1;
if (empty($_GET['p'])) $p = 1;
else $p = $_GET['p'];
$maximum = 10;
$limitbasla = ($p - 1) * $maximum;
$limitbitir = $maximum;
$sorguurunler = read("SELECT * FROM mesaj ORDER BY id asc LIMIT $limitbasla,$limitbitir", 1, []);

foreach ($sorguurunler[1] as $sonucurunler) { ?>
<tr>
<td><?php echo $sonucurunler['id'] ?></td>
<td><?php echo $sonucurunler['email'] ?></td>
<td><?php echo $sonucurunler['adsoyad'] ?></td>
<td><?php echo $sonucurunler['telefon'] ?></td>
<td><?php echo $sonucurunler['tarih'] ?></td>
<td style="width:10%"><a class="btn btn-info" style="background-color:green" href="mesaj.php?i=TRmesajoku&id=<?php echo $sonucurunler['id'] ?>"><i class="fa fa-eye icon-white"></i></a>
<a class="btn btn-default" style="background-color:#333;color:white" href="mesaj.php?i=TRmesajsil&id=<?php echo $sonucurunler['id'] ?>"><i class="fa fa-trash icon-white"></i></a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
<div class="card-footer p-0">
<div class="mailbox-controls">
<div class="float-right">
<div class="card-tools">
<ul class="pagination pagination-sm">
<?php
$sorgukategoriurunsayisi = read("SELECT COUNT(id) as sayi FROM mesaj", 0, []);
$sayi = 0;
$sayi = $sorgukategoriurunsayisi[1]['sayi'];
if ($sayi > $maximum)
$sayi = $sayi / $maximum + 1;
else $sayi = 0;
for ($j = 1; $j < $sayi; $j++) {
if ($p == $j) {
echo '<li class="page-item"><a class="page-link" href="mesaj.php?i=TRmesaj&p=' . $j . '">' . $j . '</a></li>';
} else {
echo '<li class="page-item"><a class="page-link" href="mesaj.php?i=TRmesaj&p=' . $j . '">' . $j . '</a></li>';
}
} ?>
</ul>
</div>
</div>
</div>
</div><?php } ?>
<!----------------------------------------------------------------------------------------------------------------------->
<?php if ($_GET["i"] == "TRmesajoku") { ?><div class="col-md-12">
<div class="card card-primary card-outline">
<div class="card-header">
<h3 class="card-title">Gönderilen Mesaj Detayı</h3>
</div>
<?php
if (bosmu($_GET['id']) != true) {
// alert
}
$sayfa = read("SELECT * FROM mesaj Where id =?", 0, [$_GET['id']]);
$yaz = $sayfa[1]; ?><div class="card-body p-0">
<div class="mailbox-read-message">
<table id="example1" class="table table-bordered table-striped">
<tr>
<tr>
<td><b>Gönderenin E-Mail'i :</b>&nbsp;&nbsp; <?php echo $yaz['email']; ?> </td>
</tr>
<tr>
<td><b>Gönderim Tarihi : </b>&nbsp;&nbsp;<?php echo $yaz['tarih']; ?></td>
</tr>
<tr>
<td><b>Gönderenin Telefon No :</b>&nbsp;&nbsp; <?php echo $yaz['telefon']; ?></td>
</tr>
<tr>
<td><b>Gönderenin Adı /Soyadı : </b>&nbsp;&nbsp;<?php echo $yaz['adsoyad']; ?></td>
</tr>
<tr>
</tr>

<tr>
<td><b>Mesajı :</b> &nbsp;&nbsp;<p><?php echo $yaz['mesajj']; ?> </p>
</td>
</tr>
</tr>
</table>
<button id="printbtn" type="button" class="btn btn-success"><a title="Geri" href="mesaj.php?i=TRmesaj"><i class="fa fa-arrow-left" style="height:22px;color:white">&nbsp; Geri</i></button></a>
<button id="printbtn" class="btn btn-info" type="button" onclick="window.print()"><i class="fa fa-print"></i> Yazdır</button>


</div>
</div>
</div>
</div><?php } ?>



<!---------------------------------------------------------------------------------------------------------------------->
<?php if ($_GET['i'] == "TRmesajsil") {
$updater = read("delete from mesaj where id='$_GET[id]'", 0, []);
if ($updater[0] > 0) {
header("Location:mesaj.php?i=TRmesaj&q=success");
} else {
header("Location:mesaj.php?i=TRmesaj&q=danger");
}
} ?>
</div></div></div></section></div><?php include('footer.php');?>


