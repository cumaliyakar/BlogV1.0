<?php
include('header.php');
$durum =  $ayarSorgu[1];
?>


<div class="content-wrapper"><div class="content-header"><div class="container-fluid"><div class="row mb-2">
<div class="col-sm-6"><h1 class="m-0">Kayıtlı Abone Listesi</h1></div>
<div class="col-sm-6"><ol class="breadcrumb float-sm-right"><li class="breadcrumb-item"><a href="anasayfa.php" class="btn btn-success" style="background-color:green">Anasayfa</a></li>
</ol></div></div></div></div>


<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/datatables-buttons/buttons.flash.min.js"></script>
<script>
$(function () {
$("#example1").DataTable({
"responsive": true, "lengthChange": true, "autoWidth": true,
"buttons": ["copy", "csv", "excel", "pdf", "print"]
}).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
});
</script>

<section class="content"><div class="row">


<div class="col-md-12"><div class="card card-primary card-outline">



<!----------------------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------------------->
<?php if($_GET["i"]=="TRabone"){?><div class="row"><div class="col-sm-12">
<center><h3 style="font-weight:900">Kayıtlı Abone Listesi</h3></center><section class="panel">
<table id="example1" class="table table-hover table-striped">
<thead class="thead-dark"><tr><th style="width:1%">#</th><th>E-Mail</th><th>Tarih</th><th>Sil</th></tr></thead><tbody>
<?php $p = 1;
if (empty($_GET['p'])) $p = 1;
else $p = $_GET['p'];
$maximum = 12;
$limitbasla = ($p - 1) * $maximum;
$limitbitir = $maximum;
$sorguurunler = read("SELECT * FROM abone order by id desc LIMIT $limitbasla,$limitbitir", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?>
<tr><td><?php echo $sonucurunler['id']?></td>
<td><?php echo $sonucurunler['email']?></td>
<td><?php echo $sonucurunler['tarih']?></td>

<td style="width:11%">
<a class="btn btn-danger" href="abone.php?i=TRabonesil&id=<?php echo $sonucurunler['id']?>"><i class="fa fa-trash icon-white"></i></a></td>
</tr><?php } ?></tbody></table></section>
<ul class="pagination pagination-sm">
<?php $sorgukategoriurunsayisi = read("SELECT COUNT(id) as sayi FROM abone", 0, []);
$sayi = $sorgukategoriurunsayisi[1]['sayi'];
if ($sayi > $maximum)
$sayi = $sayi / $maximum + 1;
else $sayi = 0;
for ($j = 1; $j < $sayi; $j++) {
if ($p == $j) {
echo '<li class="page-item"><a class="page-link" href="abone.php?i=TRabone&p=' . $j . '">' . $j . '</a></li>';
} else {
echo '<li class="page-item"><a class="page-link" href="abone.php?i=TRabone&p=' . $j . '">' . $j . '</a></li>';
}
} ?></ul>		</div></div><?php } ?>
<!----------------------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------------------->

<?php if ($_GET['i'] == "TRabonesil") {
$updater = read("delete from abone where id='$_GET[id]'", 0, []);
if ($updater[0] > 0) {
header("Location:abone.php?i=TRabone&q=success");
} else {
header("Location:abone.php?i=TRabone&q=danger");
}
} ?>



</div></div></div></section></div><?php  include('footer.php');?>