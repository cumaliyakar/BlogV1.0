﻿<?php
try {
    $db  = new PDO("mysql:host=localhost;dbname=blog;charset=UTF8", "root", "");
} catch (PDOException $Hata) {
    die("database hatası");
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Europe/Istanbul');

function read($sorgu, $limit, $data = [])
{
    global $db;
    if ($limit > 0) {

        $sorgu       =    $db->prepare($sorgu);
        $sorgu->execute($data);
        $kontrol     =    $sorgu->rowCount();
        $kayit       =    $sorgu->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $sorgu       =    $db->prepare($sorgu);
        $sorgu->execute($data);
        $kontrol     =    $sorgu->rowCount();
        $kayit       =    $sorgu->fetch(PDO::FETCH_ASSOC);
    }
    return  [$kontrol, $kayit];
}
$ayarSorgu = read("SELECT * FROM ayarlar Where id =?", 0, [1]);
$ayar = $ayarSorgu[1];
if (isset($_SESSION['Kullanici'])) {
    $uyeSorgu = read("SELECT * FROM uyeler Where email=?", 0, [$_SESSION['Kullanici']]);
    if ($uyeSorgu[0]) {
        $uye = $uyeSorgu[1];
    } else {
        unset($_SESSION['Kullanici']);
    }
}
$tarih = date("d-m-Y");
$saat = date("h:i");
$a = rand(0, 100000000000);
function guvenlik($q)
{
    $q = htmlspecialchars(stripslashes($q));
    $oldchar = array("
<script", "&lt;script", "'", "(", ")", ";", "(", ")", "
<iframe", "&lt;iframe", "&quot;", "&lt;?", "?&gt;", "&gt;", "&lt;", "insert into", "delete from", "mysql_query");
    $q = str_replace($oldchar, "", $q);
    $q = trim($q);
    return $q;
}
function fiyatDuzenle($data)
{
    return number_format($data, '2', ',', '.') . " ₺";
}


function filter($data)
{
    $char = [
        "<",
        ">",
        "<?php",
        "<?",
        "<?=",
        "?>",
        "*",
        ",",
        "/",
        "&",
        "+"
    ];
    if (is_array($data)) {
        foreach ($data as $key => $value) {

            for ($i = 0; $i < count($char); $i++) {
                $out = strstr($data[$key], $char[$i]);
                if ($out == true) {
                    return false;
                    break;
                }
            }
        }
    } else {
        for ($i = 0; $i < count($char); $i++) {
            $out = strstr($data, $char[$i]);
            if ($out == true) {
                return false;
                break;
            }
        }
    }

    return true;
}

function yonlendir($data)
{
    header("Location:" . $data);
    exit;
}
function convert($data)
{
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            if ($value == "") {
                $data[$key] = null;
            }
        }
    } else {
        if ($data == "") {
            $data = null;
        }
    }
    $veri = $data;
    return $veri;
}
function bosmu($data, $empty = [])
{
    $kontrolsuz = [];
    if (count($empty) > 0) {
        foreach ($empty as $key) {
            array_push($kontrolsuz, $key);
        }
    }
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            if (!in_array($key, $kontrolsuz)) {
                if (empty($value)) {
                    return false;
                }
            }
        }
    } else {
        if (!in_array($data, $kontrolsuz)) {
            if (empty($data)) {
                return false;
            }
        }
    }





    return true;
}




function pagination($s, $ptotal, $link)
{
    $forlimit = 2;
    if ($ptotal < 2) {
        null;
    } else {
        echo '
        <div class="paging">
        <ul class="pagination">';
        if ($s > 1) {
            $prev  = $s - 1;
            echo '<li><a onclick="sayfa(\'' . $link . '\',\'' . $prev . '\')"  ><i class="fa fa-angle-left"></i></a></li>';
        }
        for ($i = $s - $forlimit; $i < $s + $forlimit + 1; $i++) {
            if ($i > 0 && $i <= $ptotal) {
                if ($i == $s) {
                    echo '<li class="active"><a>' . $i . '</a></li>';
                } else {
                    echo '<li><a onclick="' . $link . '\',\'' . $i . '\'"  >' . $i . '</a></li>';
                }
            }
        }
        if ($s <= $ptotal - 1) {
            $next  = $s + 1;
            echo '<li><a onclick="sayfa(\'' . $link . '\',\'' . $next . '\')"  ><i class="fa fa-angle-right"></i></a></li>';
        }
        echo '</ul></div>';
    }
}
