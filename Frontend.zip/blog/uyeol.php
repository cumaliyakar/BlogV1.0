﻿<?php include ('header.php');?>


<div class="page-title"><div class="container"><div class="row"><div class="col-sm-12"><ul class="breadcrumb">
<li><a href="index.php">Anasayfa</a></li><li>Ücretsiz Üye Olun !</li>
</ul></div></div></div></div>



<section class="utf_block_wrapper"><div class="container"><div class="row">
<div class="col-lg-3 col-md-12"></div>


<div class="col-lg-6 col-md-12"><h3>Ücretsiz Üye Ol</h3><form method="post" action="uyelik.php">

<div class="row">

<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="Ad-Soyad *" name="adsoyad" minlength="10" type="text" required></div></div>

<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="E-Posta *" type="email" name="email" minlength="15" required></div></div>

<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="Şifre *" type="password" name="sifre" minlength="4" required></div></div>

<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="Telefon Numarası *" type="text" name="telefon" minlength="10" required></div></div>	

</div>

<div class="row"><div class="form-group col-12"><br><label><i class="fa fa-check-square" disabled style="margin-top:4px;color:green"></i> <a href="sayfa.php?id=2" target="_blank"><b>Üyelik sözleşmesini </b></a><span> okudum ve onaylıyorum.</span></label></div></div>

<div class="clearfix"><button class="btn btn-primary" type="submit" formaction="uyelik.php" style="width:100%">Ücretsiz Üye Ol</button></div>

<input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>">
<input name="durum" value="Pasif" type="hidden">
</form> 		  		  
</div> 

<div class="col-lg-3 col-md-12"></div>





</div></div></div></div>    </div><?php include ('footer.php');?>
