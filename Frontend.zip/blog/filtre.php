<div class="col-xs-12 col-sm-4 col-md-3">


    <div class="block block-sidebar">
        <div class="block-head">
            <center>
                <h5 class="widget-title">Alt Kategoriler</h5>
            </center>
        </div>
        <div class="block-inner">
            <div class="block-list-category">
                <ul>

                    <?php if (strstr($_SERVER['PHP_SELF'], 'anakategori')) {
                        $sorguurunler = read("SELECT * FROM altkategori Where alt_ustkey=?", 1, [$id]);
                        foreach ($sorguurunler[1] as $data) { ?>
                            <a href="altkategori.php?id=<?php echo $data['alt_id']; ?>">
                                <li>
                                    <h6 style="font-weight:900"><i class="fa fa-arrow-right"></i> <?php echo $data['alt_title']; ?></h6>
                                </li>
                            </a>

                    <?php }
                    } ?>
                    <?php if (strstr($_SERVER['PHP_SELF'], 'altkategori')) {
                        $sorguurunler = read("SELECT * FROM subkategori Where sub_altkey=?", 1, [$id]);
                        foreach ($sorguurunler[1] as $data) { ?>
                            <a href="subkategori.php?id=<?php echo $data['sub_id']; ?>">
                                <li>
                                    <h6 style="font-weight:900"><i class="fa fa-arrow-right"></i> <?php echo $data['sub_title']; ?></h6>
                                </li>
                            </a>

                        <?php }
                    } else if (strstr($_SERVER['PHP_SELF'], 'subkategori')) {
                        $sub = read("SELECT * FROM subkategori Where sub_id=?", 0, [$id]);

                        $sorguurunler = read("SELECT * FROM subkategori Where sub_altkey=?", 1, [$sub[1]['sub_altkey']]);
                        foreach ($sorguurunler[1] as $data) { ?>
                            <a href="subkategori.php?id=<?php echo $data['sub_id']; ?>">
                                <li>
                                    <h6 style="font-weight:900"><i class="fa fa-arrow-right"></i> <?php echo $data['sub_title']; ?></h6>
                                </li>
                            </a>
                    <?php
                        }
                    }
                    ?>

                </ul>
            </div>
        </div>
    </div>


    <form action="" id="filterForm" method="POST">
        <div class="block block-sidebar">
            <div class="block-head">
                <center>
                    <h5 class="widget-title">Fiyata Göre </h5>
                </center>
            </div><br>
            <div class="widget-content" style="display: block">
                <div class="row">

                    <div class="col-md-12">
                        <div class="row mb-3">
                            <div class="col-md-6"><span style="margin-left:10px">Minimum Fiyat</span></div>
                            <div class="col-md-6" style="padding:10px;margin-left:-20px;margin-top:-10px"><input <?= ($filter && $min > 0) ? "value='" . $min . "'" : "" ?> type="text" name="min" class="form-control" aria-describedby="basic-addon1"></div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="row mb-3">
                            <div class="col-md-6"><span style="margin-left:10px">Maximum Fiyat</span></div>
                            <div class="col-md-6" style="padding:10px;margin-left:-20px;margin-top:-10px"><input <?= ($filter && $max > 0) ? "value='" . $max . "'" : "" ?> type="text" name="max" class="form-control" aria-describedby="basic-addon1"></div>
                        </div><br>
                    </div>

                </div>
            </div>
        </div>


        <button type="submit" class="col-md-12 mb-15 btn btn page-title-area" style="height:35px">Filtrele</button>

        <div class="block block-sidebar">
            <div class="block-head">
                <center>
                    <h5 class="widget-title">Cinsiyete Göre </h5>
                </center>
            </div><br>
            <div class="widget-content" style="display: block;margin-left:20px">

                  <input type="radio" id="Bayan" <?= ($filter && isset($_POST['cinsiyet']) && $_POST['cinsiyet'] == "Bayan") ? "checked=''" : "" ?> name="cinsiyet" value="Bayan">  <label for="html">Bayan</label><br>
                  <input type="radio" id="Erkek" <?= ($filter && isset($_POST['cinsiyet']) && $_POST['cinsiyet'] == "Erkek") ? "checked=''" : "" ?> name="cinsiyet" value="Erkek">  <label for="html">Erkek</label><br>
                  <input type="radio" id="Çocuk" <?= ($filter && isset($_POST['cinsiyet']) && $_POST['cinsiyet'] == "Çocuk") ? "checked=''" : "" ?> name="cinsiyet" value="Çocuk">  <label for="Çocuk">Çocuk</label><br>
                  <input type="radio" id="Unisex" <?= ($filter && isset($_POST['cinsiyet']) && $_POST['cinsiyet'] == "Unisex") ? "checked=''" : "" ?> name="cinsiyet" value="Unisex">  <label for="Unisex">Unisex</label>

            </div>
        </div>

        <input type="hidden" name="sirala" value="<?= $siralama ?>">
        <input type="hidden" name="sayfa" value="<?= $sayfaNumarasi ?>">
        <input type="hidden" name="filter" value="1">
        <button type="submit" class="col-md-12 mb-15 btn page-title-area" style="height:35px">Filtrele</button>
    </form>



    <div class="block block-top-sellers">
        <div class="block-head">
            <div class="block-title">
                <center>
                    <div class="block-title-text text-sm"><i class="fa fa-star fa-spin" style="font-size:24px;color:orange;margin-left:-30px"></i> En Popüler</div>
                </center>
            </div>
        </div>
        <div class="block-inner" style="margin-top:10px">
            <ul class="products kt-owl-carousel" data-items="1" data-autoplay="true" data-loop="true" data-nav="true">


                <?php $sorguurunler = read("SELECT * FROM urun order by rand() limit 7", 1, []);
                if ($sorguurunler[0]) {
                    foreach ($sorguurunler[1] as $sonucsalonler) { ?>
                        <li class="product">
                            <div class="product-container">
                                <div class="product-left">
                                    <?php $sorguresimlerigetir = read("SELECT yol FROM market_resimler WHERE marketilanid='" . $sonucsalonler['id'] . "' order by id asc limit 1", 1, []);
                                    foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
                                        $resimurl = $sonucresimlerigetir['yol']; ?>
                                        <div class="product-thumb"><a class="product-img" href="detay.php?id=<?php echo $sonucsalonler['id'] ?>"><img src="logo/<?php echo $resimurl; ?>" alt="<?php echo $sonucsalonler['baslik'] ?>"></a></div><?php } ?>
                                </div>
                                <center>
                                    <div class="product-right">
                                        <div class="product-name"><a href="detay.php?id=<?php echo $sonucsalonler['id'] ?>"><?php echo $sonucsalonler['baslik'] ?></a></div>
                                        <div class="price-box"><span><?php echo number_format($sonucsalonler['birimfiyat'], 2, ',', '.'); ?> TL</span></div>
                                    </div>
                                </center>

                            </div>
                        </li><?php }
                        } ?>
            </ul>
        </div>
    </div>



</div>