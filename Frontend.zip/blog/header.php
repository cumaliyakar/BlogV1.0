<?php

use Phppot\CountryState;

session_start();
ob_start();
include('baglan.php');


function herAlert($info)
{
$title = "";
$icon = "";
if ($info == "success") {
$icon = "success";
$title = "Bilgi";
$text = "Başarılı";
} else if ($info == "danger") {
$icon = "error";
$title = "Hata";
$text = "Beklenmeyen bir hata oluştu.";
} else if ($info == "warning") {
$icon = "warning";
$title = "Uyarı";
$text = "Eksik bilgi girişi.";
} else if ($info == "filter") {
$icon = "error";
$title = "Uyarı";
$text = "Yetkisiz bilgi girişi.";
} else if ($info == "eslesme") {
$icon = "error";
$title = "Uyarı";
$text = "Şifreler Eşleşmiyor.";
} else if ($info == "mevcut") {
$icon = "error";
$title = "Uyarı";
$text = "Bu bilgilere ait üyelik mevcut.";
}

echo '<script>herAlert("' . $icon . '","' . $title . '","' . $text . '")</script>';
}



@$ip = $_SERVER['REMOTE_ADDR'];
@$past = time() - 150;

$onlineDelete = read("DELETE FROM online Where time < ?", 0, [$past]);
$result = read("SELECT time FROM online WHERE ip= ?", 0, [$ip]);

@$time = time();
if ($result[0] > 0) {
$update = read("UPDATE online SET time= ?,ip=? Where ip =?", 0, [$time, $ip, $ip]);
} else {
$update = read("INSERT INTO online (ip,time) VALUES (?,?)", 0, [$ip, $time]);
}
@$ipsi  = $_SERVER['REMOTE_ADDR'];
@$tarih = date("Y-m-d");
$ipkontrol = read("SELECT * FROM ziyaret WHERE ip= ? order by id desc", 0, [$ipsi]);
$yaz = $ipkontrol[1];
@$vip   = $yaz['ip'];
@$vtarih = $yaz['tarih'];
@$bak = $ipkontrol[0];
if ($bak > 0) {
if ($vtarih < $tarih) {
$kayit_1 = read("INSERT INTO ziyaret (ip,tarih) VALUES (?,?)", 0, [$ipsi, $tarih]);
}
} else {
$kayit_2 = read("INSERT INTO ziyaret (ip,tarih) VALUES (?,?)", 0, [$ipsi, $tarih]);
} ?>




<?php $statuscon = read("SELECT * FROM ayarlar Where id =?", 0, [1]);
$statu = $statuscon[1];    ?>



<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" lang="tr"><head><meta charset="UTF-8">
<title><?php echo $statu['baslik'];?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no" />
<link rel="icon" type="favicon" href="logo/<?php echo $statu['ikon'];?>" />
 
<link rel="shortcut icon" href="logo/<?php echo $statu['ikon']; ?>" />

<link rel="icon" type="image/png" sizes="194x194" href="logo/<?php echo $statu['ikon']; ?>">
<link rel="icon" type="image/png" sizes="192x192" href="logo/<?php echo $statu['ikon']; ?>">
<link rel="icon" type="image/png" sizes="32x32" href="logo/<?php echo $statu['ikon']; ?>">
<link rel="icon" type="image/png" sizes="96x96" href="logo/<?php echo $statu['ikon']; ?>">
<link rel="icon" type="image/png" sizes="16x16" href="logo/<?php echo $statu['ikon']; ?>">

<meta name="description" content="<?php echo $statu['baslik'];?>" />
<meta name="twitter:card" content="app" />
<meta name="twitter:site" content="@cumaliyakar" />
<meta name="twitter:description" content="<?php echo $statu['baslik'];?>" />
<meta name="twitter:app:country" content="TR" />
<meta name="twitter:app:name:iphone" content="<?php echo $statu['baslik'];?>" />
<meta property="al:web:url" content="http://www.cumaliyakar.com/" />
<link rel="canonical" href="http://www.cumaliyakar.com/" />
<meta name="robots" content="noodp" />
<meta name="referrer" content="no-referrer-when-downgrade">
<link rel="icon" type="image/png" href="logo/<?php echo $statu['ikon'];?>" sizes="32x32">
<link rel="icon" type="image/png" href="logo/<?php echo $statu['ikon'];?>" sizes="48x48">
<link rel="icon" type="image/png" href="logo/<?php echo $statu['ikon'];?>" sizes="96x96">
<link rel="icon" type="image/png" href="logo/<?php echo $statu['ikon'];?>" sizes="120x120">
<link rel="icon" type="image/png" href="logo/<?php echo $statu['ikon'];?>" sizes="144x144">
<link rel="icon" type="image/png" href="logo/<?php echo $statu['ikon'];?>" sizes="180x180">
<link rel="apple-touch-icon" sizes="180x180" href="logo/<?php echo $statu['ikon'];?>">
<meta name="theme-color" content="#fff">
<meta name="isResponsive" content="true">
<meta name="twitter:card" 			content="summary_large_image" />
<meta name="twitter:creator" 		content="@cumaliyakar" />
<meta name="twitter:image" 			content="logo/<?php echo $statu['logo'];?>" />
<meta name="ROBOTS" CONTENT="INDEX, FOLLOW">
<meta name="ROBOTS" CONTENT="ALL">
<meta name="REVISIT-AFTER" CONTENT="1 DAYS">
<meta name="RATING" CONTENT="GENERAL">
<meta name="RESOURCE-TYPE" CONTENT="DOCUMENT">
<meta name="DISTRIBUTION" CONTENT="GLOBAL">
<meta name="AUTHOR" CONTENT="cumali yakar">
<meta name="googlebot" content="snippet"> 
<meta name="robots" content="all">
<meta name="rating" content="general">
<meta name="language" content="Turkish">
<meta property="business:contact_data:street_address" content="Konya Ticaret Merkezi" /> 
<meta property="business:contact_data:locality"       content="Konya" /> 
<meta property="business:contact_data:postal_code"    content="42050" /> 
<meta property="business:contact_data:country_name"   content="Turkey" /> 
<meta property="place:location:latitude"              content="37.922612" /> 
<meta property="place:location:longitude"             content="32.536151" /> 
<meta name="HandheldFriendly" content="True" />
<meta name="author" content="Cumali Yakar | İnteraktif Hizmetler" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-touch-fullscreen" content="yes" />
<meta name="msapplication-TileColor" content="#f8f8f8"/>
<meta name="theme-color" content="#2a6bb0"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="#f8f8f8"/>
<meta name="apple-mobile-web-app-title" content="E-Ticaret Sitesi"/>
<meta property="og:locale" content="tr-TR" />
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel='prefetch' href='https://www.google-analytics.com'>
<link rel='prefetch' href='https://staticxx.facebook.com'>

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/colorbox.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link href="https://use.fontawesome.com/releases/v5.0.1/css/all.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>@media(max-width:767px){.hidden-mobile{display:none;}}@media(min-width:768px){.hidden-desktop{display:none;}}</style> 

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.all.min.js"></script>
</head><body>


<?php $gun = $statuscon[1]; ?>


<script>
function herAlert(icon1, title1, text1) {
Swal.fire({
icon: icon1,
title: title1,
text: text1

})
}
</script>

<?php
if (isset($_GET['q'])) {
if ($_GET['q'] != "") {
herAlert($_GET['q']);
}
}
?>


<div class="body-inner">


<div id="top-bar" class="top-bar"><div class="container"><div class="row">

<?php if (isset($_SESSION['Kullanici'])) { ?>
<div class="col-md-8"><ul class="unstyled top-nav"><li style="margin-top:10px"><a href="profil.php?id=paylasimlar">Profilim</a></li></ul></div>
<?php } else { ?>
<div class="col-md-8"><ul class="unstyled top-nav"><li><a href="giris.php">Giriş Yap</a></li>
<li><a href="uyeol.php"> Üye Ol</a></li></ul></div>
<?php } ?>   

<div class="col-md-4 top-social text-lg-right text-md-center"><ul class="unstyled"><li> 
<a title="facebook" href="<?php echo $statu['facebook']; ?>" target="_blank"> <span class="social-icon"><i class="fab fa-facebook" style="margin-top:7px"></i></span> </a> 
<a title="twitter" href="<?php echo $statu['twitter']; ?>" target="_blank"> <span class="social-icon"><i class="fab fa-twitter" style="margin-top:7px"></i></span> </a> 
<a title="instagram" href="<?php echo $statu['instagram']; ?>" target="_blank"> <span class="social-icon"><i class="fab fa-instagram" style="margin-top:7px"></i></span> </a> 
<a title="linkedin" href="<?php echo $statu['linkedin']; ?>" target="_blank"> <span class="social-icon"><i class="fab fa-linkedin" style="margin-top:7px"></i></span> </a> 
<a title="youtube" href="<?php echo $statu['youtube']; ?>" target="_blank"> <span class="social-icon"><i class="fab fa-youtube" style="margin-top:7px"></i></span> </a> 
</li></ul></div>

</div></div></div>



<header id="header" class="header"><div class="container"><div class="row"><div class="col-md-12 col-sm-12 text-center">
<div class="logo"><a href="anasayfa.php"> <img src="logo/<?php echo $statu['logo']; ?>" style="height:120px" alt="<?php echo $statu['baslik']; ?>"></a>
</div></div></div></div></header>









<div class="utf_main_nav_area clearfix utf_sticky"><div class="container"><div class="row">
<nav class="navbar navbar-expand-lg col">       <div class="utf_site_nav_inner float-left">

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Mobil Menü"> <span class="navbar-toggler-icon"></span> 
</button>    

<div id="navbarSupportedContent" class="collapse navbar-collapse navbar-responsive-collapse"><ul class="nav navbar-nav">

<li class="nav-item"> <a href="anasayfa.php" class="nav-link"><i class="fa fa-home fa-2x"></i> <span class="hidden-desktop">Anasayfa</span></a></li>

<?php $ustsorgu = read("SELECT * FROM anakategori", 1, []);
foreach ($ustsorgu[1] as $kategori) { ?>
<li class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $kategori['ana_title'];?> <i class="fa fa-angle-down"></i></a>

<div class="utf_dropdown_menu utf_mega_menu_content clearfix"><div class="menu-tab"><div class="row">

<ul class="nav flex-column col-12">
<?php $altsorgu = read("SELECT * from altkategori where alt_ustkey= '" . $kategori['ana_key'] . "'", 1, []);
foreach ($altsorgu[1] as $altkategori) { ?>
<li class="nav-item"> <a href="kategori.php?id=<?php echo $altkategori['alt_id'] ?>"> <span class="tab-head"> <span class="tab-text-title"><i class="fa fa-angle-double-right"></i> <?php echo $altkategori['alt_title'] ?></span> </span> </a> </li>
<?php }?></ul>

</div></div></div></li>    <?php }?>

             
</ul></div></div></nav>       

<div class="utf_nav_search"> <span id="search"><i class="fa fa-search" style="margin-top:7px"></i></span> </div>        
<div class="utf_search_block" style="display: none;"><form action="ara.php" method="POST">
<input type="text" class="form-control" placeholder="Hızlıca Buradan Arayın..." name="value" required>
<span class="utf_search_close">&times;</span> </form></div>    


</div></div></div>
