<?php
session_start();ob_start();
require('ayar.php');

if(filter($_POST) == true){
	

if (isset($_POST['login'])) {
	
$email = $_POST['email'];
$sifre = $_POST['sifre'];

$query = read("SELECT * FROM uyeler where email=? and sifre=?",1,[$email,$sifre]);



if ($query[0]>0) {
$_SESSION['email'] = $email;
header('Location:anasayfa.php');
}else{
header('Location:index.php');
}
}else{
header('Location:index.php');
}
}else{
header('Location:index.php');
}
ob_end_flush();
?>