<?php
namespace Phppot;
use Phppot\CountryState;
if (isset($_POST["ana_key"])) {
$countryId = $_POST["ana_key"];
require_once __DIR__ . '/anakategori.php';
require_once __DIR__ . '/baglan.php';
$countryState = new CountryState();
$stateResult = $countryState->getStateByCountrId($countryId);
echo "<option value=''>Alt Kategori Seçiniz</option>";
foreach ($stateResult as $state) {
echo "<option value='".$state["alt_key"]."'>".$state["alt_title"]."</option>";
}
}
?>