

<div class="col-lg-4 col-md-12"><div class="sidebar utf_sidebar_right">


<div class="block block-widget"><div class="block-inner">
<a href="profil.php?id=paylasimYap"><div class="alert alert-primary"><span><i class="fa fa-bars fa-2x" style="color:#777"></i> Paylaşım Ekle</span></div></a>

<a href="profil.php?id=paylasimlar"><div class="alert alert-success"><span><i class="fa fa-bars fa-2x" style="color:#777"></i> Paylaşımlarım</span></div></a>

<a href="profil.php?id=yorumlar"><div class="alert alert-warning"><span><i class="fa fa-comments fa-2x" style="color:#777"></i> Yorumlarım</span></div></a>

<a href="profil.php?id=profilim"><div class="alert alert-info"><span><i class="fa fa-user fa-2x" style="color:#777"></i> Bilgilerim</span></div></a>

<a href="cikis.php"><div class="alert alert-danger"><span><i class="fa fa-close fa-2x" style="color:#777"></i> Çıkış Yap</span></div></a>

<ul class="list-link">
<?php $sorguurunler = read("SELECT * FROM sayfa", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?>
<li><i class="fa fa-arrow-right" style="margin-top:7px"></i> <a href="sayfa.php?id=<?php echo $sonucurunler['id'] ?>"><?php echo $sonucurunler['baslik'] ?></a></li><?php } ?></ul>

</div></div>






<div class="widget">

<h3 class="utf_block_title"><span>Bizi Takip Edin</span></h3><ul class="social-icon"><center>
<li><a href="<?php echo $statu['instagram'] ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
<li><a href="<?php echo $statu['facebook'] ?>" target="_blank"><i class="fab fa-facebook"></i></a></li>
<li><a href="<?php echo $statu['linkedin'] ?>" target="_blank"><i class="fab fa-linkedin"></i></a></li>
<li><a href="<?php echo $statu['twitter'] ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
<li><a href="<?php echo $statu['youtube'] ?>" target="_blank"><i class="fab fa-youtube"></i></a></li>       </center></ul></div>


<div class="widget color-default"><h3 class="utf_block_title"><span>Popüler Paylaşımlar</span></h3>
<div class="utf_list_post_block"><ul class="utf_list_post">

<?php $sorguurunler = read("SELECT * FROM blog order by rand() LIMIT 7", 1, []);
foreach ($sorguurunler[1] as $sonuc) { ?> 
<li class="clearfix">
<div class="utf_post_block_style post-float clearfix" onclick="location.href='detay.php?id=<?php echo $sonuc['id'] ?>'"  style="cursor:pointer">
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $sonuc['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<div class="utf_post_thumb"><img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $sonuc['baslik'] ?>" style="width:100%"> </div><?php } ?>

<div class="utf_post_content">
<h2 class="utf_post_title title-small"> <a href="detay.php?id=<?php echo $sonuc['id'] ?>"><?php echo $sonuc['baslik'] ?></a> </h2>
<?php $YazarSorgu = $db->prepare("SELECT * FROM uyeler inner join blog on blog.uyeID = uyeler.id  WHERE blog.id=?");
$YazarSorgu->execute([$sonuc['id']]);
$YazarSonuc = $YazarSorgu->rowCount();
$YazarSonuc = $YazarSorgu->Fetch(PDO::FETCH_ASSOC); ?>
<div class="utf_post_meta"> <span class="utf_post_author"><i class="fa fa-user"></i> <a href="#" style="text-transform:capitalize"><?= $YazarSonuc['adsoyad'] ?></a></span> <span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $sonuc['tarih'] ?></span> </div>
</div></div></li><?php }?>

</ul></div></div>




<?php $reklamsorgu = read("SELECT * FROM reklam inner join altkategori on reklam.secim=altkategori.alt_id where reklam.secim=altkategori.alt_key and konum='Side Bar'", 1, []);
foreach ($reklamsorgu[1] as $reklam) { ?>
<div class="widget text-center"><div class="container"><div class="row">
<div class="col-md-12"> 
<a href="kategori.php?id=<?php echo $reklam['alt_id'] ?>">
<img class="banner img-fluid" src="logo/<?php echo $reklam['resim'] ?>" style="width:100%" alt="<?php echo $reklam['baslik'] ?>"></a> </div>
</div></div></div><?php }?>


<div class="widget m-bottom-0"><h3 class="utf_block_title"><span>E-Bültene Katılın</span></h3><div class="utf_newsletter_block">
<div class="utf_newsletter_introtext"><h4>E-Bülten Abonelik !</h4><p>Yeni Paylaşımlardan ve Duyurulardan haberdar Olmak İçin Bültenimize Abone Olun</p></div><div class="utf_newsletter_form"><form action="abone.php" method="POST">
<div class="form-group"><input type="email" class="form-control form-control-lg" placeholder="Email Adresiniz" name="email" required="required" autocomplete="off"><button class="btn btn-primary">Abone Ol</button>
</div><input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>"></form></div></div></div>


</div></div>  