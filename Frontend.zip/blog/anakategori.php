<?php namespace Phppot;
use Phppot\DataSource;
class CountryState {
private $ds;
function __construct() {
require_once __DIR__ . '/data.php';
$this->ds = new DataSource();
}
public function getAllCountry() {
$result = read("SELECT * FROM anakategori",1,[])[1];
return $result;
}
public function getStateByCountrId($countryId) {
$result = read("SELECT * FROM altkategori WHERE alt_ustkey = ?",1,[$countryId])[1];

return $result;
}
}