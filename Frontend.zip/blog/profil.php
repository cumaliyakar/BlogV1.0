﻿<?php use Phppot\CountryState;
include('header.php');
if (!isset($_SESSION['Kullanici'])) {
yonlendir('giris.php');
}
?>

<script src="https://cdn.ckeditor.com/ckeditor5/37.0.1/classic/ckeditor.js"></script>

<div class="page-title"><div class="container"><div class="row"><div class="col-sm-12"><ul class="breadcrumb">
<li><a href="index.php">Anasayfa</a></li><li>Kullanıcı Profilim</li></ul></div></div></div></div>


<?php $query = read("SELECT * FROM uyeler Where email=? and durum='Pasif'", 1, [$_SESSION['Kullanici']]);
 if ($query[1])
foreach ($query[1] as $data) { ?><br><br> 
<center><p class="alert alert-danger container">
ÜYELİĞİNİZ GEÇİCİ/KALICI OLARAK DURDURULMUŞTUR !<br>Daha detaylı bilgi için İLETİŞİM sayfasından bizlere ulaşabilirsiniz.<hr><br><a href="iletisim.php" class="btn btn-secondary">İLETİŞİM SAYFASI</a>
<a href="cikis.php" class="btn btn-info">ÇIKIŞ YAP</a></p></center>
<br><br><br><br><br>
<?php }else{?>


<section class="utf_block_wrapper"><div class="container"><div class="row">

<div class="col-lg-8 col-md-12"><div class="block category-listing">



<?php if (isset($_GET['id']) && $_GET['id'] == "paylasimlar") { ?>
<div class="col-md-12 col-12"><h4 class="text-center MyAccount-Title">Paylaşımlarım</h4><hr>
<table class="table table-bordered">
<thead><tr><th>Başlık</th><th>Tarih</th><th style="width:16%">İşlem</th></tr></thead>     <tbody>

<?php $query = read("SELECT blog.*,uyeler.id,blog.id FROM blog inner join uyeler on uyeler.id = blog.uyeID Where blog.uyeID=?", 1, [$uye['id']]);
 if ($query[1])
foreach ($query[1] as $data) { ?>    <tr>
<td><?= $data['baslik'] ?></td>
<td><?= date('d/m/Y H:i', strtotime($data['tarih'])) ?></td>
<td><a href="detay.php?id=<?= $data['id'] ?>" class="btn btn-info"><i class="fa fa-eye" style="margin-top:4px"></i> </a>
<a href="profil.php?idsi=blogduzenle&id=<?= $data['id'] ?>" class="btn btn-success"><i class="fa fa-edit" style="margin-top:4px"></i></a>
<!--<a href="profil.php?id=blogsil&id=<?= $data['id'] ?>" class="btn btn-danger"><i class="fa fa-trash" style="margin-top:4px"></i></a>--></td>

</tr><?php }else{?><center><h1 class="alert alert-danger"> Kayıt Bulunamadı.</h1></center><?php }?></tbody></table></div><?php } ?>






<?php require_once __DIR__ . '/anakategori.php';
$countryState = new CountryState();
$countryResult = $countryState->getAllCountry();?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" type="text/javascript"></script>

<script>
function getState(val) {
$("#loader").show();
$.ajax({
type: "POST",
url: "altkategori.php",
data:'ana_key='+val,
success: function(data){
$("#alt-list").html(data);
$("#loader").hide();
}
});
}
</script>



<?php if (isset($_GET['id']) && $_GET['id'] == "paylasimYap") { ?>

<?php if ($_POST) {
$klasor = "logo/";
$baslik = $_POST["baslik"];
$aciklama = $_POST["aciklama"];
$anakategori = $_POST["anakategori"];
$altkategori = $_POST["altkategori"];
$durum = $_POST["durum"];
$uyeID = $_POST["uyeID"];
$tarih = $_POST["tarih"];
$onecikan = $_POST["onecikan"];

$sorguurunekle = read("INSERT INTO blog (baslik,aciklama,anakategori,altkategori,durum,uyeID,tarih,onecikan)

VALUES('$baslik','$aciklama','$anakategori','$altkategori','$durum','$uyeID','$tarih','$onecikan')", 1, []);

$soruguurunID = read("SELECT ID FROM blog ORDER BY ID DESC LIMIT 1", 1, []);
foreach ($soruguurunID[1] as $dataID)
$productid = $dataID['ID'];

$dosya_isim_sayi = count($_FILES['resim']['name']);
for ($i = 0; $i < $dosya_isim_sayi; $i++) {
if (!empty($_FILES['resim']['name'][$i])) {
$uret = array("as", "rt", "ty", "yu", "fg");
$uzanti = substr($_FILES['resim']['name'][$i], -4, 4);
$sayi_tut = rand(1, 10000);
$yeni_ad = $uret[rand(0, 4)] . $uret[rand(0, 4)] . $uret[rand(0, 4)] . $sayi_tut . $uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i], $klasor . "/" . $yeni_ad);
$url = "" . $yeni_ad;
$urunKaydet = read("INSERT INTO resimler (marketilanid,yol) VALUES('$productid','$url')", 1, []);}}

echo '<div class="alert alert-dismissible alert-success">
<button type="button" class="close" data-dismiss="alert"><i class="fa fa-remove"></i></button>
Blog Ekleme Başarıyla Tamamlandı <a href="profil.php?id=paylasimlar" class="alert-link">Geri Dön</a>.</div>';
} else { ?>
<!--<center><p class="alert alert-warning">Paylaşımınız Admin kontrolünden Sonra Yayına Girecektir</p></center>-->

<form method="post" enctype="multipart/form-data" style="padding:">
<input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>">
<input type="hidden" name="uyeID" value="<?= $uye['id'] ?>">
<input type="hidden" name="onecikan" value="Hayır">

<div class="row"><div class="col-md-9"><div class="form-group"><label style="font-weight:900"> Blog Başlığı</label>
<input type="text" class="form-control" name="baslik" style="height:35px"></div></div>
<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Yayın Durumu</label>
<select name="durum" class="form-control">
<option value="Aktif">Aktif Olsun</option>
<option value="Pasif">Pasif Olsun</option></select></div></div>  </div>

<div class="row">
<div class="col-md-6"><div class="form-group"><label style="font-weight:900">Ana Kategorisi </label>
<select name="anakategori" class="form-control" onChange="getState(this.value);"><option>Ana Kategori Seçiniz</option>
<?php foreach ($countryResult as $country) { ?>
<option value="<?php echo $country["ana_key"]; ?>"><?php echo $country["ana_title"]; ?></option><?php } ?></select></div></div> 

<div class="col-md-6"><div class="form-group"><label style="font-weight:900">Alt Kategorisi </label>
<select name="altkategori" id="alt-list" class="form-control" onChange="getDistrict(this.value);"></select></div></div> 
</div>

<div class="row"><div class="col-md-12"><div class="form-group"><label style="font-weight:900">Blog Açıklaması</label>
<textarea name="aciklama" id="editor"></textarea></div></div></div>

<hr><div class="row"><div class="col-md-6"><div class="form-group"><label style="font-weight:900">Resimleri Seç</label>
<input type="file" name="resim[]" id="resim[]" class="form-control" multiple /><br /></div></div>

<div class="col-md-6"><div class="form-group"><br><input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Kaydet" /></div></div>

</div></form><br><?php } } ?>




<?php if (isset($_GET["idsi"]) == "blogduzenle" && !empty($_GET['id'])) { ?>
<?php if ($_POST) {

$klasor = "logo/";
$idd = $_POST["idd"];

$baslik = $_POST["baslik"];
$aciklama = $_POST["aciklama"];
$ana_key = $_POST["anakategori"];
$alt_key = $_POST["altkategori"];
$durum = $_POST["durum"];
$uyeID = $_POST["uyeID"];
$tarih = $_POST["tarih"];
$onecikan = $_POST["onecikan"];

$sorguurunler = read("UPDATE blog SET baslik='$baslik',aciklama='$aciklama',anakategori='$ana_key',altkategori='$alt_key',durum='$durum',uyeID='$uyeID',tarih='$tarih',onecikan='$onecikan' WHERE id='$idd'", 1, []);

$dosya_isim_sayi = count($_FILES['resim']['name']);
for ($i = 0; $i < $dosya_isim_sayi; $i++) {
if (!empty($_FILES['resim']['name'][$i])) {
$uret = array("as", "rt", "ty", "yu", "fg");
$uzanti = substr($_FILES['resim']['name'][$i], -4, 4);
$sayi_tut = rand(1, 10000);
$yeni_ad = $uret[rand(0, 4)] . $uret[rand(0, 4)] . $uret[rand(0, 4)] . $sayi_tut . $uzanti;
move_uploaded_file($_FILES['resim']['tmp_name'][$i], $klasor . "/" . $yeni_ad);
$url = "" . $yeni_ad;
$sorgu2 = read("INSERT INTO resimler (marketilanid,yol) VALUES('$idd','$url')", 1, []);
}
}

echo '<div class="alert alert-dismissible alert-success">
<button type="button" class="close" data-dismiss="alert"><i class="fa fa-remove"></i></button>
<strong>Tamamlandı!.</strong> İşlem Başarıyla Tamamlandı <a href="profil.php?id=paylasimlar" class="alert-link">Geri Dön</a>.</div>';
} else if (!empty($_GET['id'])) {

$query = read("SELECT * FROM blog  Where blog.id=?", 1, [$_GET['id']]);
foreach ($query[1] as $urundata) { ?>
<!--<center><p class="alert alert-warning">Düzenlemeniz Admin kontrolünden Sonra Yayına Girecektir</p></center>-->

<form method="post" name="form1" enctype="multipart/form-data" style="margin:20px">
<input type="hidden" name="idd" class="form-control" value="<?php echo $urundata['id']; ?>">
<input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>">
<input type="hidden" name="uyeID" value="<?= $uye['id'] ?>">
<input type="hidden" name="onecikan" value="Hayır">

<div class="row"><div class="col-md-9"><div class="form-group"><label style="font-weight:900"> Blog Başlığı</label>
<input type="text" class="form-control" name="baslik" style="height:35px" value="<?php echo $urundata['baslik']; ?>"></div></div>
<div class="col-md-3"><div class="form-group"><label style="font-weight:900">Yayın Durumu</label>
<select name="durum" class="form-control">
<option value="<?php echo $urundata['durum']; ?>" selected><?php echo $urundata['durum']; ?></option>
<option value="Aktif">Aktif Olsun</option>
<option value="Pasif">Pasif Olsun</option></select></div></div>  </div>

<div class="row">  
<?php
$v1sorgu          = $db->prepare("SELECT * FROM anakategori inner join blog on blog.anakategori = anakategori.ana_id  WHERE blog.anakategori=? LIMIT 1");
$v1sorgu->execute([$urundata['anakategori']]);
$v1Kontrol            = $v1sorgu->rowCount();
$v1Kayit              = $v1sorgu->Fetch(PDO::FETCH_ASSOC);

$v2sorgu          = $db->prepare("SELECT * FROM altkategori inner join blog on blog.altkategori = altkategori.alt_id  WHERE blog.altkategori=? LIMIT 1");
$v2sorgu->execute([$urundata['altkategori']]);
$v2Kontrol            = $v2sorgu->rowCount();
$v2Kayit              = $v2sorgu->Fetch(PDO::FETCH_ASSOC); ?>

<div class="col-md-6"><div class="form-group"><label>Blog ANA kategorisi</label>
<select name="anakategori" class="form-control" onChange="getState(this.value);">
<option value="<?php echo $v1Kayit['ana_id'];?>"><?php echo $v1Kayit['ana_title'];?></option>
<?php foreach ($countryResult as $country) { ?>
<option value="<?php echo $country["ana_key"]; ?>"><?php echo $country["ana_title"]; ?></option>	<?php } ?></select></div></div>

<div class="col-md-6"><div class="form-group"><label>Blog ALT kategorisi</label>
<select name="altkategori" id="alt-list" class="form-control"  onChange="getDistrict(this.value);">
<option value="<?php echo $v2Kayit['alt_id'] ?>"><?php echo $v2Kayit['alt_title'];?></option>
<?php foreach ($countryResult as $country) { ?>
<option value="<?php echo $country["alt_key"]; ?>">
<?php echo $country["alt_title"]; ?></option><?php } ?>		</select></div></div>        </div>


<div class="row"><div class="col-md-12"><label style="font-weight:900">Blog Açıklaması</label>
<textarea name="aciklama" id="editor"><?php echo $urundata['aciklama']; ?></textarea></div></div><hr>

<div class="row"><div class="col-md-12"><label style="font-weight:900">Resimleri Seç</label><br>
<?php $sorguresimlerigetir = read("SELECT * FROM resimler WHERE marketilanid='".$urundata['id']."'", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol'];
$marketilanid = $sonucresimlerigetir['id']; ?>
<a href="profil.php?i=resimsil&id=<?php echo $marketilanid; ?>"><i class="fa fa-trash fa-2x" style="margin-left:80px;position:absolute;color:red;margin-top:5px"></i>
<img src="logo/<?php echo $resimurl; ?>" style="width:100px;height:100px;border:groove" /> </a> <?php } ?></div></div>

<div class="row"><div class="col-md-6"><br><br><input type="file" name="resim[]" id="resim[]" class="form-control" multiple /></div><br />

<div class="col-md-6"><br><br><input type="submit" class="btn btn-success btn-block btn-lg font-sm" name="gonder" value="Güncelle" /></div></div><?php }  ?>
</form><br><br><br><?php } ?><?php }  ?>











<?php if ($_GET["id"] == "yorumlar") { ?>
<div class="col-md-12 col-12"><h4 class="text-center">Yorumlarım</h4><hr><table class="table table-bordered"><thead>
<tr><th>Paylaşım</th><th>Tarihi</th><th>Yorum</th><th>Durum</th></tr></thead>       <tbody>

<?php $query = read("SELECT yorum.*,blog.baslik FROM yorum inner join blog on blog.id = yorum.blogID Where yorum.uyeID=?", 1, [$uye['id']]);
foreach ($query[1] as $data) { ?>  <tr>
<td><a href="detay.php?id=<?= $data['uyeID'] ?>"><?= $data['baslik'] ?></a></td>
<td><?= date('d/m/Y H:i', strtotime($data['tarih'])) ?></td>
<td><a href="profil.php?id=yorum-detay&yorum=<?= $data['id'] ?>" class="btn btn-info">Görüntüle</a></td>
<td><?= ($data['durum']) ? "Onaylandı" : "Onay Bekliyor" ?></td>
</tr> <?php } ?></tbody>
</table>
</div><?php } ?>

<?php if ($_GET["id"] == "yorum-detay" && isset($_GET['yorum'])) { ?>
<div class="col-md-12 col-12"><h4 class="text-center MyAccount-Title">Yorum Detayı</h4><hr>

<?php $yorum = read("SELECT * FROM yorum Where id=? and uyeID=?", 0, [$_GET['yorum'], $uye['id']]);
$blog = read("SELECT * FROM blog Where id=?", 0, [$yorum[1]['blogID']])[1]; ?>

<table class="table table-bordered">
<tr><td>Paylaşım</td><td><b><a href="detay.php?id=<?= $blog['id'] ?>"><?= $blog['baslik'] ?></b></a></td></tr>
<tr><td>Tarih</td><td><?= date('d/m/Y H:i', strtotime($yorum[1]['tarih'])) ?></td></tr>
<tr><td>Durum</td><td><?= ($yorum[1]['durum']) ? "Onaylandı" : "Onay Bekliyor" ?></td></tr>
<tr><td>Yorum</td><td><?= $yorum[1]['yorumu'] ?></td></tr>
</table>

<a href="profil.php?id=yorumlar"><button type="button" class="btn btn-info"><i class="fa fa-arrow-left"></i> Geri</button></a>

</div><?php } ?>







<?php if ($_GET["id"] == "profilim") { ?>
<div class="col-md-12 col-12"><h4 class="text-center">Üyelik Bilgilerim</h4>
<center><p class="alert alert-info" style="margin:20px;padding:20px">LÜTFEN Bilgilerinizi Eksiksiz Girerek Güncelleyiniz</p>
</center>

<form method="POST" action="islem.php" enctype="multipart/form-data"><div class="row">

<div class="col-md-6 mt-1"><label>Ad Soyad</label>
<input type="text" name="adsoyad" value="<?= $uye['adsoyad'] ?>" class="form-control"></div>

<div class="col-md-6 mt-1"><label>Email</label>
<input type="text" name="email" disabled value="<?= $uye['email'] ?>" class="form-control"></div>

<div class="col-md-6 mt-1"><hr><label>Telefon</label>
<input type="text" name="telefon" value="<?= $uye['telefon'] ?>" class="form-control"></div>

<div class="col-md-6 mt-1"><hr><label>Şifre</label>
<input type="password" name="sifre" class="form-control"></div>

<div class="col-md-6 mt-1"><hr><label>Şehir (Opsiyonel)</label>
<input type="text" name="il" value="<?= $uye['il'] ?>" class="form-control"></div>

<div class="col-md-6 mt-1"><hr><label>İlçe (Opsiyonel)</label>
<input type="text" name="ilce" value="<?= $uye['ilce'] ?>" class="form-control"></div>

<div class="col-md-12 mt-1"><hr><label>Kısaca Hakkınızda (Ön Yazı Max:100 kelime)</label>
<input type="text" name="onyazi" value="<?= $uye['onyazi'] ?>" class="form-control"></div>

<div class="col-md-12 mt-1"><hr><label>Hakkınızda (Opsiyonel)</label>
<textarea name="hakkinda" class="form-control" cols="30" rows="3"><?= $uye['hakkinda'] ?></textarea></div>

<div class="row"><div class="col-lg-6 col-md-6"><div class="form-group"><hr><label>Avatar (Opsiyonel) 250px X 250px</label>
<img src="logo/<?php echo $uye['avatar'];?>" style="width:200px;height:170px" /></div></div>

<div class="form-group col-lg-6 col-md-6"><div class="form-group"><hr><br><br><br><br>
<input type="file" name="avatar" id="logo" id="fileField" style="width:100%"/></div></div></div>

<div class="col-md-12"><br><br><button type="submit" name="uyelikGuncelle" class="btn btn-success" style="width:100%">Güncelle</button></div>
<input type="hidden" name="durum" value="Aktif"><input type="hidden" name="id" value="<?php echo $uye['id'];?>" />

</div></form></div><?php } ?>



 
</div></div>







<div class="col-lg-4 col-md-12"><div class="block block-widget"><div class="block-inner">

<a href="profil.php?id=paylasimYap"><div class="alert alert-primary"><span><i class="fa fa-bars fa-2x" style="color:#777"></i> Paylaşım Ekle</span></div></a>

<a href="profil.php?id=paylasimlar"><div class="alert alert-success"><span><i class="fa fa-bars fa-2x" style="color:#777"></i> 
Paylaşımlarım</span></div></a>

<a href="profil.php?id=yorumlar"><div class="alert alert-warning"><span><i class="fa fa-comments fa-2x" style="color:#777"></i> Yorumlarım</span></div></a>

<a href="profil.php?id=profilim"><div class="alert alert-info"><span><i class="fa fa-user fa-2x" style="color:#777"></i> Bilgilerim</span></div></a>

<a href="cikis.php"><div class="alert alert-danger"><span><i class="fa fa-close fa-2x" style="color:#777"></i> Çıkış Yap</span></div></a>

<ul class="list-link">
<?php $sorguurunler = read("SELECT * FROM sayfa", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?>
<li><i class="fa fa-arrow-right" style="margin-top:7px"></i> <a href="sayfa.php?id=<?php echo $sonucurunler['id'] ?>"><?php echo $sonucurunler['baslik'] ?></a></li><?php } ?></ul>

</div></div></div>




<?php if (isset($_GET['i']) == "resimsil") {
$updater = read("delete from resimler where id='$_GET[id]'", 1, []);
echo '<script language="javascript">alert("Seçili Görsel Silindi.");</script><script language="javascript">window.location="' . $_SERVER['HTTP_REFERER'] . '";</script></center>';} ?>


<?php if (isset($_GET['i']) == "blogsil") {
$updater = read("delete from blog where id='$_GET[id]'", 1, []);
echo '<script language="javascript">alert("İçerik Silindi.");</script><script language="javascript">window.location="' . $_SERVER['HTTP_REFERER'] . '";</script></center>';} ?>



<script>
ClassicEditor
.create( document.querySelector( '#editor' ) )
.then( editor => {
console.log( editor );
} )
.catch( error => {
console.error( error );
} );
</script>

</div></div></section><?php } include('footer.php'); ?>