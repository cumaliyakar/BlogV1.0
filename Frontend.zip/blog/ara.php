<?php include('header.php');
$db->query("SET CHARACTER SET utf8");
if (isset($_POST['value'])) {
$aranan = $_POST['value'];
$blogler = read("SELECT * FROM blog where baslik Like '%$aranan%' or aciklama Like '%$aranan%'", 1, [])[1];


$begeniDizi = [];
$begeniSayi = 0;
if (isset($_SESSION['Kullanici'])) {
$begeniler = read("SELECT * FROM begeni Where uyeID=?", 1, [$uye['id']]);
foreach ($begeniler[1] as $begeni) {
array_push($begeniDizi, $begeni['blogID']);
}

$begeniSayi = $begeniler[0];
}

?>

<div class="page-title"><div class="container"><div class="row"><div class="col-sm-12"><ul class="breadcrumb">
<li><a href="index.php">Anasayfa</a></li><li>Arama Sayfası</li></ul></div></div></div></div>

<section class="utf_block_wrapper"><div class="container"><div class="row">

<div class="col-lg-12 col-md-12"><div class="block category-listing">

<h3 class="utf_block_title"><span>"<?= $aranan ?>" ile ilgili sonuçlar </span></h3>


<div class="row">


<?php
if (count($blogler) > 0) {
for ($i = 0; $i < count($blogler); $i++) {
$data = $blogler[$i];
?>
<?php $YazarSorgu = $db->prepare("SELECT * FROM uyeler inner join blog on blog.uyeID = uyeler.id  WHERE blog.id=?");
$YazarSorgu->execute([$data['id']]);
$YazarSonuc = $YazarSorgu->rowCount();
$YazarSonuc = $YazarSorgu->Fetch(PDO::FETCH_ASSOC); ?>

<div class="col-md-4"><div class="utf_post_block_style post-grid clearfix" onclick="location.href='detay.php?id=<?php echo $data['id'] ?>'"  style="cursor:pointer">

<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $data['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<div class="utf_post_thumb"><img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $data['baslik'] ?>" style="width:100%;height:330px"> </div><?php } ?>

<div class="utf_post_content"><h2 class="utf_post_title title-large"><a href="detay.php?id=<?php echo $data['id'] ?>"><?php echo $data['baslik'] ?></a> </h2>

<div class="utf_post_meta"> <span class="utf_post_author"><i class="fa fa-user"></i> <a href="#"><?= $YazarSonuc['adsoyad'] ?></a></span> 
<span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $data['tarih'] ?></span> 

<?php $YorumSorgu          = $db->prepare("SELECT COUNT(*) as sayi FROM yorum Where blogID = ?");
$YorumSorgu->execute([$data['id']]);
$YorumSayi            = $YorumSorgu->rowCount();
$Yorum              = $YorumSorgu->Fetch(PDO::FETCH_ASSOC); 
if($YorumSayi>0){
$YorumSorgu          = $db->prepare("SELECT * FROM yorum Where blogID = ? and durum=1");
$YorumSorgu->execute([$data['id']]);
$YorumTotal            = $YorumSorgu->rowCount();
$puan = $YorumTotal;
}?>
<span class="post-comment pull-right"><i class="fa fa-comments-o"></i> <a href="#" class="comments-link"><span><?php echo $YorumTotal ?></span></a></span>


</div>	

<p><?php echo substr($data['aciklama'],0,190); ?>...</p>
</div>

</div></div>


<?php

}
} else {
echo '<center><h1 class="alert alert-danger" style="width:100%">Maalesef Kayıt Bulunamadı.</h1></center>';
}
?>


</div></div></div></div></div></section>

<?php } include ('footer.php');?>



