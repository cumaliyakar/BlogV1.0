<?php
session_start();
ob_start();
include('baglan.php');
if (!bosmu($_POST, ['uyeol'])) {
	header("Location:uyeol.php?q=warning");
	exit;
}
$data = convert($_POST);
$mailcont = read("select * from uyeler where email=?", 1, [$data['email']]);

if (!$mailcont[0]) {
	foreach ($data as $key => $value) {
		$$key = $value;
	}

	$uye = read(
		"insert into uyeler (adsoyad,email,sifre,telefon,tarih,durum)
 values (?,?,?,?,?,?)",
		0,
		[$adsoyad, $email, $sifre,  $telefon, date('Y-m-d H:i:s', time()), "Aktif"]
	);
	if ($uye[0] > 0) {
		header("Location:index.php?q=success");
		exit;
	}
	header("Location:uyeol.php?q=danger");
	exit;
}
header("Location:uyeol.php?q=mevcut");
exit;
ob_end_flush();



