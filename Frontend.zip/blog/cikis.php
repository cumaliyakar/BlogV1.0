<?php
session_start();
ob_start();
unset($_SESSION['Kullanici']);
header("Location:index.php");
exit;
