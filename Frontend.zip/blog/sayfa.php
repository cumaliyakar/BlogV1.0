﻿<?php include('header.php'); ?>


<section class="utf_block_wrapper"><div class="container"><div class="row">
<?php $bos = bosmu($_GET);
if ($bos == true) {
} else {
}

$iduz = read("SELECT * FROM sayfa Where id=?", 0, [$_GET['id']]);
$uruny = $iduz[1]; 
$resim = $uruny['resim'];
$baslik = $uruny['baslik'];
$aciklama = $uruny['aciklama']; ?>
<div class="col-lg-8 col-md-12"><div class="single-post">

<div class="utf_post_content-area">
    


<div class="entry-content">
<h1><?php echo $uruny['baslik'];?></h1>
<p><?php echo $uruny['aciklama'];?></p>
<hr>
<div class="post-media post-featured-image"> 
<img src="logo/<?php echo $uruny['resim'];?>" class="img-fluid" alt="<?php echo $uruny['baslik'];?>" style="width:100%;">
</div></div>

</div>


</div>





</div>



<?php include ('sidebar.php');?>   </div></div></section> <?php include ('footer.php');?>