﻿<?php include ('header.php');?>


<div class="page-title"><div class="container"><div class="row"><div class="col-md-12"><ul class="breadcrumb">
<li><a href="index.php">Anasayfa</a></li><li>İletişim Sayfası</li></ul></div></div></div></div>



<section class="utf_block_wrapper">
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-12 contact_area">
<h3>Bize Ulaşın</h3>

<form id="contactForm" action="mesajgonder.php" method="POST"><div class="form-group">
<input type="text" name="adsoyad" class="form-control" required data-error="Ad-Soyadınız ?" placeholder="Ad-Soyadınız ?"><div class="help-block with-errors"></div></div>

<div class="form-group"><input type="email" name="email" class="form-control" required data-error="E-mail Adresiniz ?" placeholder="E-mail Adresiniz ?"><div class="help-block with-errors"></div></div>

<div class="form-group"><input type="text" name="telefon" required data-error="İletişim Numaranız ?" class="form-control" placeholder="İletişim Numaranız ?"><div class="help-block with-errors"></div></div>

<div class="form-group"><input type="text" name="konu" class="form-control" required data-error="Mesaj Konusu ?" placeholder="Mesaj Konusu ?"><div class="help-block with-errors"></div></div>

<div class="form-group"><textarea name="mesajj" class="form-control" cols="30" rows="5" required data-error="Bize iletmek istediğiniz ?" placeholder="Bize iletmek istediğiniz ?"></textarea>
<div class="help-block with-errors"></div></div>

<div class="form-check"><input type="checkbox" class="form-check-input" id="accept" checked disabled style="color:green">
<label class="form-check-label" for="accept"> <a href="#">KVKK & Gizlilik</a> Bildirgesi okudum,onaylıyorum.</label></div>
<input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>">
<br><br>
<button type="submit" class="btn btn-primary" style="width:100%">Mesajımı Gönder <i class="bx bx-pointer"></i></button>

<div class="clearfix"></div></form>
</div>



<div class="col-lg-4 col-md-12 contact_detail_area"><div class="sidebar utf_sidebar_right">

<div class="widget"><h3 class="utf_block_title"><span>Hızlı İletişim</span></h3><ul class="contct_detail_list">
<li><i class="fa fa-home"></i><?php echo $statu['adres']; ?></li>
<li><i class="fa fa-info-circle"></i> <a href="#"><?php echo $statu['sehir']; ?>  |  <?php echo $statu['ilce']; ?></a></li>	
<li><i class="fa fa-phone"></i> <a href="tel:<?php echo $statu['telefon']; ?>"><?php echo $statu['telefon']; ?></a></li>
<li><i class="fa fa-envelope-o"></i> <a href="mailto:<?php echo $statu['emaill']; ?>"><?php echo $statu['emaill']; ?></a></li>
</ul></div>

<div class="widget"><h3 class="utf_block_title"><span>Bizi Takip Edin</span></h3><ul class="social-icon"><center>
<li><a href="<?php echo $statu['linkedin']; ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
<li><a href="<?php echo $statu['facebook']; ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
<li><a href="<?php echo $statu['twitter']; ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
<li><a href="<?php echo $statu['instagram']; ?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
<li><a href="<?php echo $statu['youtube']; ?>" target="_blank"><i class="fa fa-youtube"></i></a></li>
<br><hr>
<li><img src="logo/<?php echo $statu['logo'] ?>" alt="<?php echo $statu['firma'] ?>" style="width:100%"></li>

<center></ul></div>

</div></div></div></div></section>      <?php include ('footer.php');?>