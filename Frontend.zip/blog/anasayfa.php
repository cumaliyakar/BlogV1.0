﻿<?php include ('header.php');?>
<div class="gap-20"></div>


<section class="utf_featured_post_area no-padding"><div class="container"><div class="row">

<div class="col-lg-7 col-md-12 pad-r"><div id="utf_featured_slider" class="owl-carousel owl-theme utf_featured_slider">
    
<?php $sorguurunler = read("SELECT * FROM blog where onecikan='Evet' order by rand()", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?> <div class="item" onclick="location.href='detay.php?id=<?php echo $sonucurunler['id'] ?>'"  style="cursor:pointer">
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $sonucurunler['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<img src="logo/<?php echo $resimurl; ?>" style="width:100%;height:460px;object-fit:fill;border-radius:2%" alt="<?php echo $sonucurunler['baslik'] ?>"><?php } ?>
<div class="utf_featured_post"><div class="utf_post_content"><a href="detay.php?id=<?php echo $sonucurunler['id'] ?>">
<h2 class="utf_post_title title-extra-large"> <?php echo $sonucurunler['baslik'] ?></a> </h2>
</div></div></div><?php }?>     </div></div>

<div class="col-lg-5 col-md-12 pad-l"><div class="row">

<?php $sorguurunler = read("SELECT * FROM blog where onecikan='Evet' order by rand() limit 1", 1, []);
foreach ($sorguurunler[1] as $data) { ?> 
<div class="col-md-12"><div class="utf_post_overaly_style contentTop hot-post-top clearfix" onclick="location.href='detay.php?id=<?php echo $sonucurunler['id'] ?>'"  style="cursor:pointer">
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $data['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $data['baslik'] ?>" style="width:100%;height:240px"><?php } ?>
<div class="utf_post_content"><h2 class="utf_post_title title-large"> <a href="detay.php?id=<?php echo $sonucurunler['id'] ?>"><?php echo $data['baslik'] ?></a> </h2>
<span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $data['tarih'] ?></span> </div></div></div><?php }?>

<?php $sorguurunler = read("SELECT * FROM blog where onecikan='Evet' order by rand() limit 1", 1, []);
foreach ($sorguurunler[1] as $data) { ?> 
<div class="col-md-6 pad-r-small"><div class="utf_post_overaly_style contentTop utf_hot_post_bottom clearfix" onclick="location.href='detay.php?id=<?php echo $data['id'] ?>'"  style="cursor:pointer">
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $data['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $data['baslik'] ?>" style="width:100%;height:220px"><?php } ?>
<div class="utf_post_content"><h2 class="utf_post_title title-medium"><a href="detay.php?id=<?php echo $sonucurunler['id'] ?>"><?php echo $data['baslik'] ?> </h2>
<div class="utf_post_meta"><span class="utf_post_author"><i class="fa fa-calendar"></i> <?php echo $data['tarih'] ?></span></div>
</a></div></div></div><?php }?>

<?php $sorguurunler = read("SELECT * FROM blog where onecikan='Evet' limit 1", 1, []);
foreach ($sorguurunler[1] as $data) { ?> 
<div class="col-md-6 pad-l-small"><div class="utf_post_overaly_style contentTop utf_hot_post_bottom clearfix" onclick="location.href='detay.php?id=<?php echo $sonucurunler['id'] ?>'"  style="cursor:pointer">
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $data['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $data['baslik'] ?>" style="width:100%;height:220px"><?php } ?>
<div class="utf_post_content"><h2 class="utf_post_title title-medium"> <a href="detay.php?id=<?php echo $sonucurunler['id'] ?>"><?php echo $data['baslik'] ?></a> </h2>
<div class="utf_post_meta"> <span class="utf_post_author"><i class="fa fa-calendar"></i> <?php echo $data['tarih'] ?></span> </div>
</div></div></div><?php }?>

</div></div></div></div></section>





<section class="utf_latest_new_area pb-bottom-20"><div class="container"><div class="utf_latest_news block color-red">
<h3 class="utf_block_title"><span>SON 12 PAYLAŞIM</span></h3>
<div id="utf_latest_news_slide" class="owl-carousel owl-theme utf_latest_news_slide">

<?php $sorguurunler = read("SELECT * FROM blog where durum='Aktif' order by id desc LIMIT 12", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?> 
<div class="item"><ul class="utf_list_post"><li class="clearfix"><div class="utf_post_block_style clearfix">

<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $sonucurunler['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?><a href="detay.php?id=<?php echo $sonucurunler['id'] ?>">
<div class="utf_post_thumb"><img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $sonucurunler['baslik'] ?>" style="width:100%;height:200px"></div></a><?php } ?>
<div class="utf_post_content"><center><h2 class="utf_post_title title-medium" style="font-weight:900"><a href="detay.php?id=<?php echo $sonucurunler['id'] ?>"><?php echo $sonucurunler['baslik'] ?></h2></center>
<?php $YazarSorgu = $db->prepare("SELECT * FROM uyeler inner join blog on blog.uyeID = uyeler.id  WHERE blog.id=?");
$YazarSorgu->execute([$sonucurunler['id']]);
$YazarSonuc = $YazarSorgu->rowCount();
$YazarSonuc = $YazarSorgu->Fetch(PDO::FETCH_ASSOC); ?>
<div class="utf_post_meta"> <span class="utf_post_author" style="border-right:none"><i class="fa fa-user"></i> <a href="#" style="text-transform:capitalize"><?= $YazarSonuc['adsoyad'] ?></a></span> <span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $sonucurunler['tarih'] ?></span> </div>
</div></div></li></ul></div><?php }?></div></div></div></section>





<?php $reklamsorgu = read("SELECT * FROM reklam inner join altkategori on reklam.secim=altkategori.alt_id where reklam.secim=altkategori.alt_key and konum='Anasayfa Üst'", 1, []);
foreach ($reklamsorgu[1] as $reklam);  
if (isset($reklam['resim'])) {?> 
<div class="utf_ad_content_area text-center utf_banner_area no-padding"><div class="container"><div class="row">
<div class="col-md-12"> 
<a href="kategori.php?id=<?php echo $reklam['alt_id'] ?>">
<img class="img-fluid" src="logo/<?php echo $reklam['resim'] ?>" style="width:100%" alt="<?php echo $reklam['baslik'] ?>"></a> </div>
</div></div></div><?php }else{?><?php }?>







<section class="utf_block_wrapper p-bottom-0"><div class="container"><div class="row">

<?php $kategori = read("SELECT * FROM blog inner join anakategori on blog.anakategori=anakategori.ana_id where durum='Aktif' limit 9", 1, []); 
foreach ($kategori[1] as $data) { ?> 

<div class="col-lg-4"><div class="block color-dark-blue" onclick="location.href='detay.php?id=<?php echo $data['id'] ?>'"  style="cursor:pointer">
    

<div class="utf_post_overaly_style clearfix">
 
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $data['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?><div class="utf_post_thumb">
<img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $data['baslik'] ?>" style="width:100%;height:200px">
</div><?php } ?>


<div class="utf_post_content">
<h2 class="utf_post_title"><a href="detay.php?id=<?php echo $data['id'] ?>"><?php echo $data['baslik'] ?></a> </h2>
<?php $YazarSorgu = $db->prepare("SELECT * FROM uyeler inner join blog on blog.uyeID = uyeler.id  WHERE blog.id=?");
$YazarSorgu->execute([$sonucurunler['id']]);
$YazarSonuc = $YazarSorgu->rowCount();
$YazarSonuc = $YazarSorgu->Fetch(PDO::FETCH_ASSOC); ?>
<div class="utf_post_meta"><span class="utf_post_author"><i class="fa fa-user"></i> <a href="#" style="text-transform:capitalize"><?= $YazarSonuc['adsoyad'] ?></a></span> 
<span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $data['tarih'] ?></span> </div>
</div>

</div>



<div class="utf_list_post_block"><ul class="utf_list_post">
<?php $sorguurunler = read("SELECT * FROM blog where durum='Aktif' order by rand() LIMIT 3", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?> 
<li class="clearfix"><div class="utf_post_block_style post-float clearfix">
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $sonucurunler['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?><div class="utf_post_thumb">
<img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $data['baslik'] ?>" style="width:100%;height:70px">
</div><?php } ?><div class="utf_post_content"><h2 class="utf_post_title title-small"><a href="detay.php?id=<?php echo $data['id'] ?>"><?php echo $sonucurunler['baslik'] ?></a></h2>

<?php $YazarSorgu = $db->prepare("SELECT * FROM uyeler inner join blog on blog.uyeID = uyeler.id  WHERE blog.id=?");
$YazarSorgu->execute([$sonucurunler['id']]);
$YazarSonuc = $YazarSorgu->rowCount();
$YazarSonuc = $YazarSorgu->Fetch(PDO::FETCH_ASSOC); ?><div class="utf_post_meta"> <span class="utf_post_author"><i class="fa fa-user"></i><a href="#" style="text-transform:capitalize"><?= $YazarSonuc['adsoyad'] ?></a></span> <span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $sonucurunler['tarih'] ?></span></div></div></div></li><?php }?>
</ul></div>


</div><br></div><?php }?></div></div></section>














<section class="utf_block_wrapper p-bottom-0"><div class="container"><div class="row">

<div class="col-lg-8 col-md-12"><div class="utf_more_news block color-default">
<h3 class="utf_block_title"><span>En Çok Okunan Paylaşımlar</span></h3>
<div id="utf_more_news_slide" class="owl-carousel owl-theme utf_more_news_slide"><div class="item">

<?php $sorgu = read("SELECT * FROM blog where durum='Aktif' order by okunma LIMIT 4", 1, []);
foreach ($sorgu[1] as $sonuc) { ?> 
<?php $YazarSorgu = $db->prepare("SELECT * FROM uyeler inner join blog on blog.uyeID = uyeler.id  WHERE blog.id=?");
$YazarSorgu->execute([$sonuc['id']]);
$YazarSonuc = $YazarSorgu->rowCount();
$YazarSonuc = $YazarSorgu->Fetch(PDO::FETCH_ASSOC); ?>
<div class="utf_post_block_style utf_post_float_half clearfix" onclick="location.href='detay.php?id=<?php echo $sonuc['id'] ?>'"  style="cursor:pointer">
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $sonuc['id'] . "' limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<div class="utf_post_thumb"><img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $sonuc['baslik'] ?>" style="width:100%;height:170px"> </div><?php } ?><div class="utf_post_content">
<h2 class="utf_post_title"> <a href="detay.php?id=<?php echo $sonuc['id'] ?>"><?php echo $sonuc['baslik'] ?></a> </h2>
<div class="utf_post_meta"> <span class="utf_post_author"><i class="fa fa-user"></i> <a href="#" style="text-transform:capitalize"><?= $YazarSonuc['adsoyad'] ?></a></span> <span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $sonuc['tarih'] ?></span> </div>
<p><?php echo substr($sonuc['aciklama'],0,300) ?>...</p>
</div></div><?php }?></div></div></div></div>




<div class="col-lg-4 col-sm-12"><div class="sidebar utf_sidebar_right">
    
<div class="widget color-default"><h3 class="utf_block_title"><span>Son Yorumlar</span></h3><div class="utf_list_post_block">
<ul class="utf_list_post review-post-list">


<?php $sorguurunler = read("SELECT * FROM blog where durum='Aktif' order by okunma LIMIT 4", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?> 
<?php $YorumSorgu          = $db->prepare("SELECT COUNT(*) as sayi FROM yorum Where blogID = ?");
$YorumSorgu->execute([$sonucurunler['id']]);
$YorumSayi            = $YorumSorgu->rowCount();
$Yorum              = $YorumSorgu->Fetch(PDO::FETCH_ASSOC); 
if($YorumSayi>0){
$YorumSorgu          = $db->prepare("SELECT * FROM yorum Where blogID = ? and durum=1");
$YorumSorgu->execute([$sonucurunler['id']]);
$YorumTotal            = $YorumSorgu->rowCount();
$puan = $YorumTotal;
}else{
}?>
<li class="clearfix" onclick="location.href='detay.php?id=<?php echo $sonucurunler['id'] ?>'"  style="cursor:pointer">
<div class="utf_post_block_style post-float clearfix">

<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $sonucurunler['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<div class="utf_post_thumb"><img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $sonucurunler['baslik'] ?>" style="width:100%"> </div><?php } ?>

<?php $YazarSorgu = $db->prepare("SELECT * FROM uyeler inner join blog on blog.uyeID = uyeler.id  WHERE blog.id=?");
$YazarSorgu->execute([$sonucurunler['id']]);
$YazarSonuc = $YazarSorgu->rowCount();
$YazarSonuc = $YazarSorgu->Fetch(PDO::FETCH_ASSOC); ?>
<div class="utf_post_meta">
<h2 class="utf_post_title"> <a href="detay.php?id=<?php echo $sonucurunler['id'] ?>"><?php echo $sonucurunler['baslik'] ?> </h2>
 
<p><span class="utf_post_author"><i class="fa fa-comments"></i> <?php echo $YorumTotal ?> Adet Yorum</span>
<span class="utf_post_author" style="text-transform:capitalize;border-right:none"><i class="fa fa-user"></i> <?= $YazarSonuc['adsoyad'] ?></span></p></a>
</div>

</div></li><?php }?></ul></div></div>


<div class="widget m-bottom-0"><h3 class="utf_block_title"><span>E-Bültene Katılın</span></h3><div class="utf_newsletter_block">
<div class="utf_newsletter_introtext"><h4>E-Bülten Abonelik !</h4><p>Yeni Paylaşımlardan ve Duyurulardan haberdar Olmak İçin Bültenimize Abone Olun</p></div><div class="utf_newsletter_form"><form action="abone.php" method="POST">
<div class="form-group"><input type="email" class="form-control form-control-lg" placeholder="Email Adresiniz" name="email" required="required" autocomplete="off"><button class="btn btn-primary">Abone Ol</button>
</div><input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>"></form></div></div></div>

</div></div>


</div></div></section>  



<?php $reklamsorgu = read("SELECT * FROM reklam inner join altkategori on reklam.secim=altkategori.alt_id where reklam.secim=altkategori.alt_key and konum='Anasayfa Alt'", 1, []);
foreach ($reklamsorgu[1] as $reklam) { ?> <br><br>
<div class="utf_ad_content_area text-center utf_banner_area no-padding"><div class="container"><div class="row">
<div class="col-md-12"> 
<a href="kategori.php?id=<?php echo $reklam['alt_id'] ?>">
<img class="img-fluid" src="logo/<?php echo $reklam['resim'] ?>" style="width:100%" alt="<?php echo $reklam['baslik'] ?>"></a> </div>
</div></div></div><?php }?>


<br><br><br>
<?php include ('footer.php');?>


