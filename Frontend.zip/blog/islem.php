<?php
session_start();
ob_start();
include('baglan.php');
if (isset($_POST['uyeOl'])) {
  if (!bosmu($_POST, ['uyeOl'])) {
    yonlendir('index.php?q=warning');
  }
  if (!$_SESSION['Kullanici']) {
    header("Location:uyeol.php");
    exit;
  }

  $data = convert($_POST);
  $query = read("SELECT * FROM uyeler Where email=?", 1, [$data['email']]);
  if (!$query[0]) {
    $query = read("INSERT INTO uyeler SET adsoyad=?,telefon=?,email=?,sifre=?", 1, [$data['adsoyad'], $data['telefon'], $data['email'], $data['sifre']]);
    if ($query[0]) {
      yonlendir('index.php?q=success');
    }
    yonlendir('index.php?q=danger');
  }
  yonlendir('index.php?q=mevcut');
} elseif (isset($_POST['girisYap'])) {
  if (!bosmu($_POST, ['girisYap'])) {
    yonlendir('index.php?q=warning');
  }
  $data = convert($_POST);
  $query = read("SELECT * FROM uyeler Where email=? and sifre=?", 1, [$data['email'], $data['sifre']]);
  if ($query[0]) {
    $_SESSION['Kullanici'] = $data['email'];
    yonlendir('profil.php?id=profilim');
  }
  yonlendir('giris.php?q=danger');
} 




elseif (isset($_POST['uyelikGuncelle'])) {
  if (!bosmu($_POST, ['uyelikGuncelle', 'sifre'])) {
    yonlendir('profil.php?id=profilim&q=warning');
  }
  $data = convert($_POST);
  foreach ($data as $key => $value) {
    $$key = $value;
  }
  $klasor="";	
  $depo = "logo/";
  $a = rand(0, 100000000000);
  $b = "$a.webp";
  $neresi = $depo . basename($b);
  if (@move_uploaded_file($_FILES['avatar']['tmp_name'], $neresi)) {

  //$query = read("UPDATE uyeler SET adsoyad=?,telefon=?,il=?,ilce=?,onyazi=?,hakkinda=?,avatar=? Where id=?", 1,
   // [$adsoyad,  $telefon, $il, $ilce, $onyazi, $hakkinda, $b, $uye['id']]
  //);}

  $query = read("UPDATE uyeler set adsoyad='$adsoyad', sifre='$sifre', il='$il',ilce='$ilce', hakkinda='$hakkinda', telefon='$telefon', onyazi='$onyazi',durum='$durum',avatar='$b' where id='$id'", 1, []);
} else {
$query = read("UPDATE uyeler set adsoyad='$adsoyad', sifre='$sifre', il='$il',ilce='$ilce', hakkinda='$hakkinda', telefon='$telefon', onyazi='$onyazi',durum='$durum' where id='$id'", 0, []);
}

 // if (!empty($sifre)) {
  //  $query2 = read("UPDATE uyeler SET sifre=? Where id=?", 1, [$sifre, $uye['id']]);
  //}
  if ($query[0] || $query2[0]) {
    yonlendir('profil.php?id=profilim&q=success');
  }
  yonlendir('profil.php?id=profilim&q=danger');
} 



else if (isset($_POST['yorumYap'])) {
 // if (!bosmu($_POST, ['yorumYap'])) {
   // header("Location:index.php");
   // exit;
  //}
  
  $data = convert($_POST);

  $query = read("INSERT INTO yorum SET yorumu=?,tarih=?,uyeID=?,blogID=?,durum=?", 1, [$data['yorumu'],$data['tarih'],$uye['id'],$data['blogID'],$data['durum']]);
  if ($query[0]) {
    header("Location:detay.php?id=" . $data['id'] . '&q=success');
    exit;
  }
  header("Location:detay.php?id=" . $data['id'] . '&q=danger');
  exit;
}

  else if (isset($_POST['begeniEkle'])) {

  $data = convert($_POST);
  $ctrl = read("SELECT * FROM begeni Where uyeID=? and blogID=?", 0, [$uye['id'], $data['blogID']]);
  if (!$ctrl[0]) {
    $query = read("INSERT INTO begeni SET blogID=?,uyeID=?", 1, [$data['blogID'], $uye['id']]);
    if ($query[0]) {
      header("Location:detay.php?id=" . $data['id'] . '&q=success');
      exit;
    }

    header("Location:" . $data['link'] . 'q=danger');
    exit;
  } else {
    header("Location:" . $data['link'] . 'q=success');
    exit;
  }
} else if (isset($_POST['begeniSil'])) {
  $data = convert($_POST);
  $query = read("DELETE FROM begeni Where blogID=? and uyeID=?", 1, [$data['blogID'], $uye['id']]);
  if ($query[0]) {
    header("Location:" . $data['link'] . 'q=success');
    exit;
  }
  header("Location:" . $data['link'] . 'q=danger');
  exit;
}