﻿<?php include ('baglan.php');
$mailcont=read("select * from abone where email=?",1,[$_POST['email']]);

if ($mailcont[0]>0) { echo "<script language='javascript'>alert('$_POST[email] Bu mail adresi ile zaten daha önce abone oldunuz...');history.go(-1);</script>";
 }else{
	 
	 
$tarih =$_POST["tarih"];
$email =$_POST["email"];
  
$uye = read("insert into abone (tarih,email) values(?,?)",0,
[$tarih,$email]);
if($uye[0]>0){
	header("Location:index.php?q=success");
}else{
	header("Location:index.php?q=danger");
}

	}
?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
 