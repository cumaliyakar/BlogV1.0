﻿<?php include ('header.php');?>
<?php
ob_start();
if (isset($_SESSION['email'])) {
$ayarSorgu = read("SELECT * FROM uyeler Where email=?", 1, [$data['email']]);
if ($ayarSorgu[0] > 0) {
} else {
header("Location:index.php?q=yetki");
}
} else {
header("Location:index.php?q=yetki");
}

$durum = $ayarSorgu[1];

if ($durum) { ?>

<div class="page-title"><div class="container"><div class="row"><div class="col-sm-12"><ul class="breadcrumb">
<li><a href="index.php">Anasayfa</a></li><li>Hesabınıza Giriş Yapın</li>
</ul></div></div></div></div>



<section class="utf_block_wrapper"><div class="container"><div class="row">

<div class="col-lg-3 col-md-12"></div>  


<div class="col-lg-6 col-md-12 mrb-40"><center><h3>Hesabınıza Giriş Yapın</h3></center><form method="post" action="islem.php">
  
<div class="row">
<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="Email Adresiniz *" type="email" name="email" required></div></div>

<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="Kullanıcı Şifreniz *" type="password" name="sifre" required></div></div>  
</div>

<div class="clearfix"><button class="btn btn-primary" type="submit" name="girisYap" style="width:100%">Giriş Yap</button></div>
</form></div>



<div class="col-lg-3 col-md-12"></div>  
		  
      
</div></div></section><?php } include ('footer.php');?>