<?php include ('baglan.php');

$adsoyad =$_POST["adsoyad"];
$mesajj =$_POST["mesajj"];
$tarih =$_POST["tarih"];
$telefon =$_POST["telefon"];
$email =$_POST["email"];
$konu =$_POST["konu"];
  
$uye = read("insert into mesaj (adsoyad,mesajj,tarih,telefon,email,konu) values(?,?,?,?,?,?)",0,
[$adsoyad,$mesajj,$tarih,$telefon,$email,$konu]);
if($uye[0]>0){
	header("Location:index.php?q=success");
}else{
	header("Location:index.php?q=danger");
}

	?>