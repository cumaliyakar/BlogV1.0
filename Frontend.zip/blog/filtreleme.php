<?php

function filter($data)
{
    $char = [
        "<",
        ">",
        "<?php",
        "<?",
        "<?=",
        "?>",
        "*",
        ".",
        ",",
        "/",
        "&",
        "+"
    ];
    if (is_array($data)) {
        foreach ($data as $key => $value) {

            for ($i = 0; $i < count($char); $i++) {
                $out = strstr($data[$key], $char[$i]);
                if ($out == true) {
                    return false;
                    break;
                }
            }
        }
    } else {
        for ($i = 0; $i < count($char); $i++) {
            $out = strstr($data, $char[$i]);
            if ($out == true) {
                return false;
                break;
            }
        }
    }

    return true;
}


// $string = "Deneme string";
$string= [
    "ad" => "Hamza1",
    "soyad" => "Kurt"
];
if(filter($string)==false){
    echo "false";
}else{
    echo "true";
}
