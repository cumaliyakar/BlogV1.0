﻿<?php include('header.php');?>


<?php if (isset($_SESSION['email'])) {
    $data = convert($_POST);
    $ayarSorgu = read("SELECT * FROM uyeler Where email=?", 1, [$data['email']]);
} 
$durum = $ayarSorgu[1];
if ($durum) { ?>



<?php if (!isset($_GET['id']) || !filter($_GET)) {
    header("Location:anasayfa.php");
    exit;
}
$ID = $_GET['id'];

$blogData = read("SELECT * FROM blog Where id=?", 0, [$ID]);
if (!$blogData[0]) {
    header("Location:anasayfa.php");
    exit;
}

$kategori = read("SELECT * FROM blog inner join anakategori on blog.anakategori=anakategori.ana_id
inner join altkategori on blog.altkategori = altkategori.alt_id Where blog.id =?", 0, [$ID]);

$data = $blogData[1];

$idsi = $_GET["id"];
read("UPDATE blog SET okunma=okunma+1 WHERE id='$idsi'", 1, []);

$begeniDizi = [];
$begeniSayi = 0;
if (isset($_SESSION['Kullanici'])) {
$begeniler = read("SELECT * FROM begeni Where uyeID=?", 1, [$uye['id']]);
foreach ($begeniler[1] as $begeni) {
array_push($begeniDizi, $begeni['blogID']);
}
$begeniSayi = $begeniler[0];
}
?>




<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if (isset($_SESSION['Kullanici'])) {
$button = "type='submit'";
} else {
$button = 'type="button" onclick="herAlert(\'warning\',\'Uyarı\',\'Lütfen Giriş Yapın\')"';
} ?>



<div class="page-title"><div class="container"><div class="row"><div class="col-md-12"><ul class="breadcrumb">
<li><a href="index.php">Anasayfa</a></li>
<li><a href="#"><?= $kategori[1]['ana_title'] ?></a></li>
<li><a href="kategori.php?id=<?= $kategori[1]['alt_id'] ?>"><?= $kategori[1]['alt_title'] ?></a></li>
<li><?php echo $data['baslik'] ?></li>
</ul></div></div></div></div>


<?php $YorumSorgu          = $db->prepare("SELECT COUNT(*) as sayi FROM yorum Where blogID = ?");
$YorumSorgu->execute([$data['id']]);
$YorumSayi            = $YorumSorgu->rowCount();
$Yorum              = $YorumSorgu->Fetch(PDO::FETCH_ASSOC); 
if($YorumSayi>0){
$YorumSorgu          = $db->prepare("SELECT * FROM yorum Where blogID = ? and durum=1");
$YorumSorgu->execute([$data['id']]);
$YorumTotal            = $YorumSorgu->rowCount();
$puan = $YorumTotal;
}?>

<?php $BegeniSorgu          = $db->prepare("SELECT COUNT(*) as sayi FROM begeni Where blogID = ?");
$BegeniSorgu->execute([$data['id']]);
$BegeniSayi            = $BegeniSorgu->rowCount();
$Begen              = $BegeniSorgu->Fetch(PDO::FETCH_ASSOC); 
if($BegeniSayi>0){
$BegeniSorgu          = $db->prepare("SELECT * FROM begeni Where blogID = ?");
$BegeniSorgu->execute([$data['id']]);
$BegeniTotal            = $BegeniSorgu->rowCount();
$puan = $BegeniTotal;
}else{
}?>

<?php $YazarSorgu = $db->prepare("SELECT * FROM uyeler inner join blog on blog.uyeID = uyeler.id  WHERE blog.id=?");
$YazarSorgu->execute([$data['id']]);
$YazarSonuc = $YazarSorgu->rowCount();
$YazarSonuc = $YazarSorgu->Fetch(PDO::FETCH_ASSOC); ?>


<section class="utf_block_wrapper"><div class="container"><div class="row">

<div class="col-lg-8 col-md-12"><div class="single-post">

<div class="utf_post_title-area"><h2 class="utf_post_title"><?php echo $data['baslik'] ?></h2>
<div class="utf_post_meta"><span class="utf_post_author"><a href="#" style="text-transform:capitalize"><i class="fa fa-user"></i> <?= $YazarSonuc['adsoyad'] ?></a> </span> 
<span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $data['tarih'] ?></span> 
<span class="post-hits"><i class="fa fa-eye"></i> <?php echo $data['okunma'] ?> Ziyaret</span> 
<span class="post-comment"><i class="fa fa-comments-o"></i> <span><?php echo $YorumTotal ?> Yorum</span></span> 

<span class="post-comment"><form action="islem.php" method="POST">
<input type="hidden" name="blogID" value="<?= $data['id'] ?>">
<input type="hidden" name="link" value="<?= $_SERVER['PHP_SELF'] ?>?">
<button style="background-color:transparent;border:none" <?= $button ?> style="<?= (in_array($data['id'], $begeniDizi))?>" type="submit" name="begeniEkle"><span class="post-hits"><i class="fa fa-thumbs-up"></i> <?php echo $BegeniTotal ?> Beğeni</span>
 

</span></button>
</form></span> 


</div></div>


<div class="utf_post_content-area"><div class="post-media post-featured-image"> 
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $data['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?><a href="logo/<?php echo $resimurl; ?>" class="gallery-popup">
<img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $data['baslik'] ?>" style="width:100%;height:"></a>
<?php } ?></div>





<div class="entry-content">
<p><?php echo $data['aciklama'] ?></p>
</div>


<!--<div class="tags-area clearfix"><div class="post-tags"> 
<span>Etiketler:</span> 
<a href="#"># etiket</a> 				
</div></div>-->

<!--<div class="share-items clearfix"><ul class="post-social-icons unstyled">
<li class="facebook"> <a href="#"> <i class="fa fa-facebook"></i> <span class="ts-social-title">Facebook</span></a> </li>
<li class="twitter"> <a href="#"> <i class="fa fa-twitter"></i> <span class="ts-social-title">Twitter</span></a> </li>
<li class="gplus"> <a href="#"> <i class="fa fa-google-plus"></i> <span class="ts-social-title">Google +</span></a> </li>
<li class="pinterest"> <a href="#"> <i class="fa fa-pinterest"></i> <span class="ts-social-title">Pinterest</span></a> </li>
</ul></div> -->


</div></div>





<nav class="post-navigation clearfix">
<?php $sorguurunler = read("SELECT * FROM blog order by id desc LIMIT 1", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?>
<div class="post-previous"> 
<a href="detay.php?id=<?php echo $sonucurunler['id'] ?>"> <span><i class="fa fa-angle-left"></i>Önceki Paylaşım</span>
<h3><?php echo $sonucurunler['baslik'] ?></h3>
</a> </div><?php }?>

<?php $sorguurunler = read("SELECT * FROM blog order by id asc LIMIT 1", 1, []);
foreach ($sorguurunler[1] as $sonucurunler) { ?>
<div class="post-next"> 
<a href="detay.php?id=<?php echo $sonucurunler['id'] ?>"> <span>Sonraki Paylaşım<i class="fa fa-angle-right"></i></span>
<h3><?php echo $sonucurunler['baslik'] ?></h3>
</a></div><?php }?>

</nav>






<?php $yazar = read("SELECT blog.*,uyeler.adsoyad,uyeler.avatar,uyeler.onyazi,blog.baslik FROM blog inner join uyeler on blog.uyeID=uyeler.id Where blog.id=?", 1, [$_GET['id']]);
if ($yazar[0]) { 
foreach ($yazar[1] as $paylasim) { ?>
<div class="author-box"><div class="author-img pull-left"> 
<?php if ($paylasim['avatar']) {?> 
<img src="logo/<?= $paylasim['avatar'] ?>" alt="<?= $paylasim['adsoyad'] ?>">
<?php }else{?>
<img src="logo/<?php echo $statu['ikon']; ?>" alt="<?= $statu['firma'] ?>">
<?php }?>
</div>
<div class="author-info">
<h3><?= $paylasim['adsoyad'] ?></h3>
<p><?= $paylasim['onyazi'] ?></p>              
</div>

</div><?php }}?>






<?php if (isset($_SESSION['Kullanici'])) {?>
<div class="related-posts block"><h3 class="utf_block_title"><span>Yazarın Diğer Paylaşımları</span></h3>
<div id="utf_latest_news_slide" class="owl-carousel owl-theme utf_latest_news_slide">

<?php $query = read("SELECT blog.*,uyeler.id,blog.id FROM blog inner join uyeler on uyeler.id = blog.uyeID Where blog.uyeID=?", 1, [$uye['id']]);
 if ($query[1])
foreach ($query[1] as $paylasim) { ?> 

 
<div class="item" style="border:solid 1px; border-color:#444;border-radius:5%"><div class="utf_post_block_style clearfix" style="margin:3px;padding:3px">
<div class="utf_post_thumb" onclick="location.href='detay.php?id=<?php echo $paylasim['id'] ?>'"  style="cursor:pointer"> 
  
<?php $sorguresimlerigetir = read("SELECT yol FROM resimler WHERE marketilanid='" . $paylasim['id'] . "' order by id asc limit 1", 1, []);
foreach ($sorguresimlerigetir[1] as $sonucresimlerigetir) {
$resimurl = $sonucresimlerigetir['yol']; ?>
<img class="img-fluid" src="logo/<?php echo $resimurl; ?>" alt="<?php echo $paylasim['baslik'] ?>" style="width:100%;height:auto">
<?php } ?>
</div>
<div class="utf_post_content">
<h2 class="utf_post_title title-medium"><a href="detay.php?id=<?= $paylasim['id'] ?>"><?= substr($paylasim['baslik'],0,22);?>...</h2>
<center> <span class="utf_post_date"><i class="fa fa-calendar"></i> <?php echo $paylasim['tarih'] ?></span> </center></a> </div>

</div></div><?php }?>

</div></div><?php }?>







<div id="comments" class="comments-area block"><h3 class="utf_block_title"><span><?= $data['baslik'] ?></b> İçin Kullanıcı Yorumları</span></h3><ul class="comments-list">

<?php $yorumlar = read("SELECT yorum.*,uyeler.avatar,uyeler.adsoyad,blog.id,yorum.durum FROM yorum inner join uyeler on yorum.uyeID=uyeler.id inner join blog on blog.id =yorum.blogID Where blogID=? and yorum.durum='Aktif'", 1, [$_GET['id']]);
if ($yorumlar[0]) { ?>
<?php foreach ($yorumlar[1] as $yorum) { ?>
<li><div class="comment"> 
<?php if ($yorum['avatar']) {?> 
<img src="logo/<?= $yorum['avatar'] ?>" alt="<?= $yorum['adsoyad'] ?>" class="comment-avatar pull-left">
<?php }else{?>
<img src="logo/<?php echo $statu['ikon']; ?>" alt="<?= $statu['firma'] ?>" class="comment-avatar pull-left">
<?php }?>

<div class="comment-body">
<div class="meta-data"><span class="comment-author" style="text-transform:capitalize"><?= $yorum['adsoyad'] ?> ' ın yorumu</span> 
<span class="comment-date pull-right"><?= $yorum['tarih'] ?></span></div>
<div class="comment-content"><p><?= $yorum['yorumu'] ?></p></div>
</div></div></li>
<?php }
} else { ?>
<center><p class="alert alert-danger" style="padding:20px;margin:20px">Henüz Yorum Eklenmemiş.<br>İlk Ekleyen Siz Olun</p></center>
<?php } ?>

</ul></div>




<div class="comments-form"><center><h3 class="comment-reply-title">Sizde Bu Paylaşım Hakkında Yorum Yapın</h3></center>
<?php if (isset($_SESSION['Kullanici'])) { ?>
<form action="islem.php" method="POST"><div class="row">

<div class="col-md-6"><div class="form-group">
<input class="form-control" name="adsoyad" placeholder="<?= $uye['adsoyad'] ?>" disabled required></div></div>

<div class="col-md-6"><div class="form-group">
<input class="form-control" name="email" placeholder="<?= $uye['email'] ?>" disabled required></div></div>

<div class="col-md-12"><div class="form-group">
<textarea class="form-control required-field" name="yorumu" placeholder="Yorumunuz *" rows="10" required></textarea></div></div>

</div>

<div class="clearfix"><button class="comments-btn btn btn-primary" name="yorumYap" type="submit">Yorumumu Ön Onaya Gönder</button></div>

<input type="hidden" name="blogID" value="<?php echo $_GET['id'] ?>">
<input type="hidden" name="durum" value="Pasif"><input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>">
</form>
<?php } else { ?>
<center><a href="giris.php">
<p class="alert alert-info" style="padding:20px;margin:20px"> Yorum Yapmak İçin Giriş Yapın</p>
</a></center>
<?php } ?>
</div>





</div>



<?php include ('sidebar.php');?>   </div></div></section> <?php } include ('footer.php');?>