﻿<?php include('header.php');
if (!isset($_SESSION['Kullanici'])) {
    header("Location:giris.php");
    exit;
}
$query = read("SELECT begeni.*,urun.baslik,urun.birimfiyat,urun.stok FROM begeni inner join urun on begeni.urunID=urun.id Where begeni.uyeID=?", 1, [$uye['id']]);
?>

<div class="container">
    <div class="row">


        <div class="page-title-area block block-breadcrumbs" style="height:40px;">
            <ul>
                <li class="home"><a href="index.php"><i class="fa fa-home" style="color:#fff;margin-top:12px"></i></a><span></span></li>
                <li><a style="color:#fff" href="#"> Beğendiklerim</a><span></span></li>
            </ul>
        </div>



        <div class="row">






            <div class="col-xs-12 col-sm-12 col-md-12">
                <center>
                    <h1 class="page-title">Beğendiklerim Listesi
                        <hr>
                    </h1>
                </center>


                <table class="table table-bordered table-wishlist">
                    <thead>
                        <tr>
                            <th>Ürün Adı</th>
                            <th>Stok</th>
                            <th style="width:20%">Fiyat</th>
                            <th class="hidden-mobile">Ürüne Git</th>
                            <th class="hidden-desktop">Ürün</th>
                            <th>Sil</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($query[1] as $data) {
                        ?>


                            <tr>

                                <td><?= $data['baslik'] ?></td>
                                <td><?= $data['stok'] ?></td>
                                <td class="hidden-mobile"><?= fiyatDuzenle($data['birimfiyat']) ?></td>
                                <td class="hidden-desktop"><?= $data['birimfiyat'] ?> ₺</td>
                                <td><a href="detay.php?id=<?= $data['urunID'] ?>">İncele</a></td>
                                <td class="text-center">
                                    <form action="islem.php" method="POST">
                                        <input type="hidden" name="urunID" value="<?= $data['urunID'] ?>">
                                        <input type="hidden" name="link" value="<?= $_SERVER['PHP_SELF'] ?>?">
                                        <button type="submit" name="begeniSil"><span class="fa fa-close"></span></button>
                                    </form>
                                </td>

                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>


                <ul class="hidden-mobile row list-wishlist">
                    <?php
                    foreach ($query[1] as $data) {
                        $resim = read("SELECT * FROM market_resimler Where marketilanid=?", 0, [$data['urunID']])[1];
                    ?>

                        <li class="col-sm-6 col-md-3">

                            <div class="product-img"><a href="detay.php?id=<?= $data['urunID'] ?>"><img src="logo/<?= $resim['yol'] ?>" alt="Product"></a></div>

                            <h5 class="product-name"><a href="detay.php?id=<?= $data['urunID'] ?>">
                                    <center><?= $data['baslik'] ?></center>
                                </a></h5>


                            <form action="islem.php" method="POST" class="alert alert-info">
                                <input type="hidden" name="urunID" value="<?= $data['urunID'] ?>">
                                <input type="hidden" name="link" value="<?= $_SERVER['PHP_SELF'] ?>?">


                                <div class="qty" style="border-bottom: 1px solid grey;padding:7px">
                                    <div class="row"><div class="col-md-6"><label>Ürün Adeti</label></div>
                                    <div class="col-md-6"><input name="adet" style="background-color:#fff;border:solid 1px" type="number" value="1"></div></div>
                                </div>

<div class="row">
                                <div class="col-md-8"><div class="button-action">
                                    <button type="submit" name="sepeteEkle" class="page-title-area button button-sm">Sepete Ekle</button>
                                </div>
                            </form></div>
<div class="col-md-2"></div><div class="col-md-2">
                            <form action="islem.php" method="POST">
                                <input type="hidden" name="urunID" value="<?= $data['urunID'] ?>">
                                <input type="hidden" name="link" value="<?= $_SERVER['PHP_SELF'] ?>?">
                                <button type="submit" name="begeniSil" class="btn btn-default" style="margin-top:10px;padding:10px;margin-left:-17px"><span class="fa fa-close"></span></button>
                            </form></div>

</div>
                        </li>

                    <?php
                    }
                    ?>



                </ul>



            </div>


        </div>
    </div>
</div><?php include('footer.php'); ?>