﻿<!DOCTYPE html>
<html lang="tr">
<?php

function herAlert($info)
{
    $title = "";
    $icon = "";
    if ($info == "danger") {
        $icon = "error";
        $title = "Hata";
        $text = "Giriş Başarısız.";
    } else if ($info == "warning") {
        $icon = "warning";
        $title = "Uyarı";
        $text = "Eksik bilgi girişi.";
    } else if ($info == "yetki") {
        $icon = "error";
        $title = "Uyarı";
        $text = "Bu site SADECE üyelere özel ücretsiz blog sitesidir.Giriş Yapın veya Üye Olun.";
    } else if ($info == "success") {
        $icon = "success";
        $title = "Bilgi";
        $text = "Başarıyla Üye Oldunuz. Şimdi Giriş Yapın";
    }

    echo '<script>herAlert("' . $icon . '","' . $title . '","' . $text . '")</script>';
}
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Giriş Paneli</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/colorbox.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link href="https://use.fontawesome.com/releases/v5.0.1/css/all.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>@media(max-width:767px){.hidden-mobile{display:none;}}@media(min-width:768px){.hidden-desktop{display:none;}}</style> 

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.all.min.js"></script>

<body class="login-img3-body" style="background-image:url(logo/footer.jpg);">

    <script>
        function herAlert(icon1, title1, text1) {
            Swal.fire({
                icon: icon1,
                title: title1,
                text: text1

            })
        }
    </script>

    <?php
    if (isset($_GET['q'])) {
        if ($_GET['q'] != "") {
            herAlert($_GET['q']);
        }
    }
    ?>

<div class="row" style="margin-left:35%;margin-right:20%;margin-top:20%;margin-bottom:20%">
<center>
<h1 style="width:100%;color:#2ed5c8">Site Yönetimine Giriş Yapın</h1><br>
<form action="islem.php" method="post">
<div class="row">

<div class="col-lg-6 col-md-6"><div class="form-group"><i class="fa fa-asterisk" style="color:red"></i>&nbsp;&nbsp;<label style="color:#2ed5c8;font-weight:900">&nbsp;&nbsp;E-Mail Adresiniz</label><input type="text" class="form-control" name="email" required="required"></div></div>

<div class="col-lg-6 col-md-6"><div class="form-group"><i class="fa fa-asterisk" style="color:red"></i>&nbsp;&nbsp;<label style="color:#2ed5c8;font-weight:900">&nbsp;&nbsp;Kullanıcı Şifreniz</label><input type="password" min="4" class="form-control" name="sifre" required="required"></div></div>

</div>
<input class="btn col-md-12" style="width:100%;background-color:#2ed5c8;color:#fff" type="submit" name="girisYap" value="Giriş Yap" />

</form><hr>

<button onclick="document.getElementById('uyelik').style.display='block'" class="btn col-md-12" style="width:100%;background-color:#4f4f4f;color:#fff">Ücretsiz Üye Ol</button>

</center></div>




<div class="w3-container">
 
  <div id="uyelik" class="w3-modal">
    <div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">

    <div class="w3-center"><br>
        <span onclick="document.getElementById('uyelik').style.display='none'" class="w3-button w3-xlarge w3-hover-red w3-display-topright" title="Kapat">&times;</span>

      <form class="w3-container" method="post" action="islem.php">
        <div class="w3-section">
         
        <div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="Ad-Soyad *" name="adsoyad" minlength="10" type="text" required></div></div>

<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="E-Posta *" type="email" name="email" minlength="15" required></div></div>

<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="Şifre *" type="password" name="sifre" minlength="4" required></div></div>

<div class="col-md-12"><div class="form-group">
<input class="form-control" placeholder="Telefon Numarası *" type="text" name="telefon" minlength="10" required></div></div>	

<div class="col-md-12"><div class="form-group"><br><label><i class="fa fa-check-square" disabled style="margin-top:4px;color:green"></i> <a href="sayfa.php?id=2" target="_blank"><b>Üyelik sözleşmesini </b></a><span> okudum ve onaylıyorum.</span></label></div></div>

<input type="hidden" name="tarih" value="<?php echo date("j-m-Y"); ?>">
<input name="durum" value="Aktif" type="hidden">

        </div>
      

      <div class="w3-container w3-border-top w3-padding-16 w3-light-grey">
      <button class="btn btn-primary" type="submit" formaction="uyelik.php" style="width:100%">Ücretsiz Üye Ol</button>
      </div>
      </form>
    </div>
  </div>
</div>


</body>

</html>